<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * File       : 004_members.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/18/18
 * Time: 5:34 PM
 */

class Migration_Members extends CI_Migration
{
    public function up()
    {
        $members = [
            'member_id'               =>  ['type' => 'INT',             'constraint' => '11',  'unsigned' => TRUE,  'auto_increment' => TRUE],
            'church_id'               =>  ['type' => 'INT',             'constraint' => '11',  'unsigned' => TRUE],
            'title'                   =>  ['type' => 'ENUM("rev","pastor","deacon","deaconess","brother","sister","prophet","evang","apostle","none")', 'default'=>'brother'],
            'surname'                 =>  ['type' => 'VARCHAR' ,        'constraint' => '150' ],
            'first_name'              =>  ['type' => 'VARCHAR',         'constraint' => '150'],
            'birth_date'              =>  ['type' => 'DATE'],
            'gender'                  =>  ['type' => 'ENUM("male","female","not-specified")','default'=>'not-specified'],
            'home_phone'              =>  ['type' => 'VARCHAR' ,        'constraint' => '30'],
            'cell_phone'              =>  ['type' => 'VARCHAR',         'constraint' => '30'],
            'work_phone'              =>  ['type' => 'VARCHAR' ,        'constraint' => '30'],
            'email_address'           =>  ['type' => 'VARCHAR'  ,        'constraint' => '200'],
            'country'                 =>  ['type' => 'INT',             'constraint' => '11',  'unsigned'  => TRUE],
            'state'                   =>  ['type' => 'INT',             'constraint' => '11',  'unsigned'  => TRUE],
            'city'                    =>  ['type' => 'INT',             'constraint' => '11',  'unsigned'  => TRUE],
            'home_address'            =>  ['type' => 'VARCHAR' ,        'constraint' => '255'],
            'nearest_landmark'        =>  ['type' => 'VARCHAR' ,        'constraint' => '255'],
            'marital_status'          =>  ['type' => 'ENUM("married","single","divorced","widowed")','default'=>'single'],
            'profession'              =>  ['type' => 'VARCHAR',         'constraint' => '150'],
            'first_day_in_church'     =>  ['type' => 'DATE'],
            'invited_by'              =>  ['type' => 'VARCHAR' ,        'constraint' => '200'],
            'prayer_request'          =>  ['type' => 'VARCHAR',         'constraint' => '255'],
            'visit_time'              =>  ['type' => 'VARCHAR',         'constraint' => '255'],
            'group_assigned'          =>  ['type' => 'INT',             'constraint'  => '11', 'unsigned' => TRUE ],
            'bible_study_status'      =>  ['type' => 'ENUM("pending","enrolled","graduated")','default'=>'pending'],
            'is_new_convert'          =>  ['type' => 'ENUM("yes","no")'],
            'is_baptised'             =>  ['type' => 'ENUM("yes","no")'],
            'member_picture'          =>  ['type' => 'VARCHAR',         'constraint' => '255'],
            'mem_lat'                 =>  ['type' => 'VARCHAR',        'constraint' => '100',  'default' => '0'],
            'mem_long'                =>  ['type' => 'VARCHAR',         'constraint' => '100', 'default' => '0'],
            'created_by'    		  =>  ['type' => 'INT',             'constraint' =>'11',   'unsigned'=> TRUE],
            'created_at'    		  =>  ['type' => 'TIMESTAMP'],
            'updated_at'    		  =>  ['type' => 'TIMESTAMP']
        ];
        $this->dbforge->add_field($members);
        $this->dbforge->add_key('member_id',TRUE);
        $this->dbforge->add_key('email_address', TRUE);
        $this->dbforge->create_table('grow_members');
    }

    public function down(){
        $this->dbforge->drop_table('grow_members');
    }
}
