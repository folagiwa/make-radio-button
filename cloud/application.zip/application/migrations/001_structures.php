<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * File       : 001_structures.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/18/18
 * Time: 5:04 PM
 */

class Migration_Structures extends CI_Migration
{
    public function up()
    {

        $signup = [
            'id'      	        => ['type' => 'INT',     'constraint' => '11',  'unsigned' => TRUE,  'auto_increment' => TRUE],
            'user_id'      	    => ['type' => 'INT',     'constraint' => '11',  'unsigned' => TRUE],
            'church_id'         => ['type' => 'INT',     'constraint' => '11',   'unsigned' => TRUE],
            'church_name'       => ['type' => 'VARCHAR', 'constraint' => '100'],
            'first_name'        => ['type' => 'VARCHAR', 'constraint' => '150'],
            'surname'           => ['type' => 'VARCHAR', 'constraint' => '150'],
            'email_address'     => ['type' => 'VARCHAR', 'constraint' => '150' ],
            'password'          => ['type' => 'VARCHAR', 'constraint' => '255'],
            'phone_number'      => ['type' =>'VARCHAR',  'constraint' => '30'],
            'church_website'    => ['type' => 'VARCHAR', 'constraint' => '255'],
            'created_by'        => ['type' =>'INT',      'constraint' => '11',  'unsigned'=> TRUE],
            'created_at'        => ['type' =>'DATETIME'],
            'updated_at'        => ['type' =>'TIMESTAMP']
        ];
        $this->dbforge->add_field($signup);
        $this->dbforge->add_key('id',TRUE);
        $this->dbforge->create_table('grow_signup');

        $users = [
            'user_id'        => ['type' => 'INT',       'constraint' => '11', 'unsigned' => TRUE, 'auto_increment' => TRUE],
            'church_id'      => ['type' => 'INT',       'constraint' => '11',  'unsigned' => TRUE ],
            'member_id'      => ['type' => 'INT',       'constraint' => '11'],
            'username'       => ['type' => 'VARCHAR',   'constraint' => '255'],
            'password'       => ['type' => 'VARCHAR',   'constraint' => '255'],
            'active'         => ['type' => 'ENUM("1","0")', 'default'=> '0' ],
            'is_admin'       => ['type' => 'ENUM("1","0")', 'default'=>'0'],
            'user_type'      => ['type' => 'ENUM("member","fellowship","leader")'],
            'random_key'     => ['type' => 'VARCHAR',   'constraint' => '255'],
            'user_roles'     => ['type' => 'VARCHAR',   'constraint' =>'255'],
            'created_by'     => ['type' =>'INT',        'constraint' =>'11', 'unsigned'=> TRUE],
            'created_at'     => ['type' =>'DATETIME'],
            'updated_at'     => ['type' =>'TIMESTAMP']

        ];
        $this->dbforge->add_field($users);
        $this->dbforge->add_key('user_id',TRUE);
        $this->dbforge->create_table('grow_users');

        $grow_churches = [
            'church_id'         => ['type' => 'INT',        'constraint' => '11',       'unsigned' => TRUE,     'auto_increment' => TRUE],
            'church_name'       => ['type' => 'VARCHAR'  ,  'constraint' => '100'],
            'church_pastor'     => ['type' => 'INT'      ,  'constraint' => '11',       'unsigned' => TRUE],
            'church_admin'      => ['type' => 'INT'      ,  'constraint' => '11',       'unsigned' => TRUE],
            'church_email'      => ['type' => 'VARCHAR'  ,  'constraint' => '100'],
            'authorization_code'=> ['type' => 'VARCHAR'  ,  'constraint' => '150'],
            'reference'         => ['type' => 'VARCHAR'  ,  'constraint' => '150'],
            'church_website'    => ['type' => 'VARCHAR'  ,  'constraint' => '150'],
            'paid_at'           => ['type' => 'DATETIME'],
            'church_country'    => ['type' => 'INT'     ,   'constraint' => '5'],
            'church_state'      => ['type' => 'INT'     ,   'constraint' => '11' ],
            'church_city'       => ['type' => 'INT'     ,   'constraint' => '11'],
            'church_address'    => ['type' => 'VARCHAR' ,   'constraint' => '255'],
            'church_phone'      => ['type' => 'VARCHAR' ,   'constraint' => '50'],
            'church_desc'       => ['type' => 'VARCHAR' ,   'constraint' => '255'],
            'church_gps'        => ['type' => 'VARCHAR' ,   'constraint' => '155'],
            'created_by'        => ['type' => 'INT',          'constraint' =>'11',      'unsigned'=> TRUE],
            'created_at'        => ['type' => 'DATETIME'],
            'updated_at'        => ['type' => 'TIMESTAMP']
        ];

        $this->dbforge->add_field($grow_churches);
        $this->dbforge->add_key('church_id',TRUE);
        $this->dbforge->create_table('grow_churches');

        $payment_log  = [
            'log_id'         => ['type' => 'INT',        'constraint' => '11', 'unsigned' => TRUE, 'auto_increment' => TRUE],
            'church_id'      => ['type' => 'INT'  ,      'constraint' => '7',  'unsigned' => TRUE],
            'paid_at'        => ['type' => 'DATETIME'],
            'expiry_date'    => ['type' => 'DATETIME'],
            'reference'      => ['type' => 'INT',        'constraint' => '11',    'unsigned' => TRUE],
            'created_at'     => ['type' =>'TIMESTAMP'],
            'updated_at'     => ['type' =>'TIMESTAMP']

        ];
        $this->dbforge->add_field($payment_log);
        $this->dbforge->add_key('log_id',TRUE);
        $this->dbforge->create_table('grow_payment_log');

    }
    public function down()
    {
        $this->dbforge->drop_table('grow_signup');
        $this->dbforge->drop_table('grow_users');
        $this->dbforge->drop_table('grow_churches');
        $this->dbforge->drop_table('grow_payment_log');

    }

}