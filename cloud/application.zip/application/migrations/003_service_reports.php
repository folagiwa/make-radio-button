<?php
/**
 * File       : 003_service_reports.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/18/18
 * Time: 5:24 PM
 */

class Migration_Service_reports extends CI_Migration{

    public function up(){
        $service_reports = [
            'service_id'        => ['type' => 'INT',                        'constraint' => '11',   'unsigned' => TRUE,     'auto_increment' => TRUE],
            'church_id'         => ['type' => 'INT',                        'constraint' => '11',   'unsigned' => TRUE],
            'service_date'      => ['type' => 'DATE'],
            'service_type'      => ['type' => 'ENUM("weekend","midweek")'],
            'attendance_kids'   => ['type' => 'INT',                        'constraint' =>'7',      'unsigned' => TRUE],
            'attendance_teens'  => ['type' => 'INT',                        'constraint' =>'7',      'unsigned' => TRUE],
            'attendance_adults' => ['type' => 'INT',                        'constraint' =>'7',      'unsigned' => TRUE],
            'first_timers'      => ['type' => 'INT',                        'constraint' =>'7',      'unsigned' => TRUE],
            'new_converts'      => ['type' => 'INT',                        'constraint' =>'11' ,    'unsigned' => TRUE],
            'offering'          => ['type' => 'DOUBLE(12,2)'],
            'tithe'             => ['type' => 'DOUBLE(12,2)'],
            'seed'              => ['type' => 'DOUBLE(12,2)'],
            'thanksgiving'      => ['type' => 'DOUBLE(12,2)'],
            'remarks'           => ['type' => 'INT',                        'constraint' =>'7',      'unsigned' => TRUE],
            'created_by'        => ['type' => 'INT',                        'constraint' =>'11',     'unsigned' => TRUE],
            'created_at'        => ['type' => 'TIMESTAMP'],
            'updated_at'        => ['type' => 'TIMESTAMP']

        ];

        $this->dbforge->add_field($service_reports);
        $this->dbforge->add_key('service_id',TRUE);
        $this->dbforge->create_table('grow_service_reports');


    }

    public function down(){

        $this->dbforge->drop_table('grow_service_reports');
    }
}