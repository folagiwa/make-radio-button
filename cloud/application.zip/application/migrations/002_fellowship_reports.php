<?php
/**
 * File       : 002_fellowship_reports
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/18/18
 * Time: 5:20 PM
 */

class Migration_Fellowship_reports extends CI_Migration{

    public function up(){

        $fellowship_reports = [
            'report_id'     => ['type' => 'INT',            'constraint' => '11', 'unsigned'  => TRUE, 'auto_increment' => TRUE],
            'cell_id'       => ['type' => 'INT',            'constraint' => '7',  'unsigned'  => TRUE],
            'church_id'     => ['type' => 'INT',            'constraint' => '5',  'unsigned'  => TRUE],
            'zone_id'       => ['type' => 'INT',            'constraint' => '3',  'unsigned'  => TRUE],
            'activity_date' => ['type' => 'DATE'],
            'activity_type' => ['type' => 'ENUM("prayer_planning","biblestudy","outreach","fellowship","others ")'],
            'attendance'    => ['type' => 'INT'  ,          'constraint' => '7', 'unsigned' => TRUE],
            'first_timers'  => ['type' => 'INT',            'constraint' => '7', 'unsigned' => TRUE],
            'new_converts'  => ['type' => 'INT',            'constraint' => '7', 'unsigned' => TRUE],
            'offering'      => ['type' => 'DOUBLE(12,2)'],
            'created_by'    => ['type' => 'INT',            'constraint' =>'11',   'unsigned'=> TRUE],
            'created_at'    => ['type' => 'TIMESTAMP'],
            'updated_at'    => ['type' => 'TIMESTAMP']

        ];
        $this->dbforge->add_field($fellowship_reports);
        $this->dbforge->add_key('report_id',TRUE);
        $this->dbforge->create_table('grow_fellowship_reports');


        $tags = [
            'tag_id'     => ['type' => 'INT',     'constraint' => '11',  'unsigned' => TRUE,  'auto_increment' => TRUE],
            'church_id'  => ['type' => 'INT',     'constraint' => '11',  'unsigned' => TRUE],
            'tag_name'   => ['type' => 'VARCHAR' ,'constraint' => '150'],
            'tag_type'   => ['type' => 'ENUM("fellowship","service_department","teens","kids","adult")'],
            'member_id'  => ['type' => 'INT',     'constraint' => '11',  'unsigned' => TRUE],
            'tag_email'  => ['type' => 'VARCHAR', 'constraint' => '100' ],
            'created_by' => ['type' => 'INT',     'constraint' => '11',    'unsigned'=> TRUE],
            'created_at' => ['type' => 'TIMESTAMP'],
            'updated_at' => ['type' => 'TIMESTAMP']

        ];
        $this->dbforge->add_field($tags);
        $this->dbforge->add_key('tag_id',TRUE);
        $this->dbforge->create_table('grow_tags');
    }

    public function down(){
        $this->dbforge->drop_table('grow_fellowship_reports');
        $this->dbforge->drop_table('grow_tags');
    }

}


