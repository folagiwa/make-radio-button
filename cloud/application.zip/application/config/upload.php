<?php
/**
 * File       : upload.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 10/11/18
 * Time: 12:58
 */

$config['upload_path'] = './files/photos';
$config['allowed_types'] = 'gif|jpg|png|docx|jpeg|JPG|JPEG';
$config['max_size']     = '2000';
$config['max_width'] = '1280';
$config['max_height'] = '960';

//IMAGE PROCESSING


