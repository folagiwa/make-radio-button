<?php defined('BASEPATH') OR exit('No direct script access allowed.');

$config['protocol']     = 'mail';
$config['charset']      = 'utf-8';
$config['wordwrap']     = TRUE;
$config['smtp_host']    = 'smtp.loveworld360.com';
$config['smtp_user']    = 'folakegiwa@loveworld360.com';
$config['smtp_pass']    = 'soundmind';
$config['smtp_port']    = '25';
$config['mailtype']     = 'html';
$config['sender_email'] = 'admin@loveworld360.com';
$config['sender_name']  = 'Grow Software Assistant';


