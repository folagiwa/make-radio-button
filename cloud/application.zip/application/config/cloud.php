<?php
/**
 * File       : cloud.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 10/2/18
 * Time: 9:40 AM
 */

/*
 * Google Map key
 */
$config['api_key']          = 'AIzaSyC1QVdvtqDYqew8Csoi4VGAynhRYUqtr3E';
//$config['api_key']          = 'AIzaSyB3Ngh7RXcQefs3b0JEUkDeRLnfHYisw9o';
//$config['api_key']        = 'AIzaSyCs-VnuXUUBcBKPzPr30_vaSVlLej0zW7A';
$config['marker']           = 'https://loveworldims.org/assets/js/locationpicker.jquery.js';