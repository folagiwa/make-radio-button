<?php
/**
 * File       : general_helper
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/4/18
 * Time: 3:42 PM
 */
if (!function_exists('dump')) {
    function dump ($var, $label = 'Dump', $echo = TRUE)
    {
        // Store dump in variable
        ob_start();
        var_dump($var);
        $output = ob_get_clean();

        // Add formatting
        $output = preg_replace("/\]\=\>\n(\s+)/m", "] => ", $output);
        $output = '<pre style="background: #FFFEEF; color: #000; border: 1px dotted #000; padding: 10px; margin: 10px 0; text-align: left;">' . $label . ' => ' . $output . '</pre>';

        // Output
        if ($echo == TRUE) {
            echo $output;
        }
        else {
            return $output;
        }
    }
}


if(!function_exists('alert_error_msg')){
    function alert_error_msg($message,$link,$label){
        $html = '<div class="alert alert-danger">';
        $html.='<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>';

        $html.='<h4><i class="fa fa-ban"></i><strong>'.lang('error').'</strong></h4>';
        $html.="<p>$message</p>";
        $html.='<p><a class="btn btn-inverse btn-sm" href="'.$link.'">'.$label.'</a></p>';
        $html.='</div>';

        return $html;
    }
}

if(!function_exists('alert_success')){
    function alert_success($info){
        $html = '';
        $html.='<div class="alert alert-success">';
        $html.='<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>';
        $html.='<strong><i class="fa fa-check"></i>'.lang('success').'</strong>'.$info;
        $html.='</div>';

        return $html;
    }
}

if(!function_exists('alert_info')){
    function alert_info($info){
        $html = '';
        $html.='<div class="alert alert-info">';
        $html.='<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>';
        $html.='<strong><i class="fa fa-info-circle"></i> '.lang('info').'</strong>'.$info;
        $html.='</div>';

        return $html;
    }
}

if(!function_exists('alert_warning')){
    function alert_warning($info){
        $html = '';
        $html.='<div class="alert alert-danger">';
        $html.='<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>';
        $html.='<strong><i class="fa fa-bell-o"></i>'.lang('warning').'</strong>'.$info;
        $html.='</div>';

        return $html;
    }
}

if (!function_exists('dump_exit')) {
    function dump_exit($var, $label = 'Dump', $echo = TRUE) {
        dump ($var, $label, $echo);
        exit;
    }
}

if(!function_exists('time_diff')) {
    function time_diff($date)
    {

        $datetime1 = date_create($date);
        $datetime2 = date_create('now');
        $interval = date_diff($datetime1, $datetime2);


        $min=$interval->format('%i');
        $sec=$interval->format('%s');
        $hour=$interval->format('%h');
        $mon=$interval->format('%m');
        $day=$interval->format('%d');
        $year=$interval->format('%y');

        if($interval->format('%i%h%d%m%y')=="00000")
        {

            return $sec.' '.lang('second_ago');

        }

        else if($interval->format('%h%d%m%y')=="0000"){
            return ($min > 1) ? $min.' '.lang('minute_ago'): $min.' '.lang('minute_ago');
        }


        else if($interval->format('%d%m%y')=="000"){
            return ($hour >1)? $hour.' '.lang('hour_ago'): $hour.' '.lang('hour_ago');
        }


        else if($interval->format('%m%y')=="00"){
            return ($day >1)? $day.' ' .lang('day_ago'):$day.' '.' day ago';
        }

        else if($interval->format('%y')=="0"){
            return ($mon >1)? $mon.' '.lang('month_ago'): $mon.' '.' month ago';
        }

        else{
            return ($year >1) ? $year.' '.lang('year_ago'): $year.' '.' year ago';
        }

    }
}

//detect the languague of the user and load if it exist
//find out the default language of the browser
if(!function_exists('detect_language')) {
    function detect_language() {
        $detect = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'],0,2);  //en-US
        //check if the directory exist
        $directory = 'application/language/'.$detect.'/';

        //if it exist, then load it as his default language
        $lang = (is_dir($directory))? $detect : 'en';

        return $lang;
    }
}




/*
 * Author: Felix Anyanwu
 */

if(!function_exists('random_val')){
    function random_val(){
        $value = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890';

        return substr(str_shuffle($value), 0, 5);
    }
}


if(!function_exists('add_js')){
    function add_js($file='')
    {
        $str = '';
        $ci = &get_instance();
        $header_js  = $ci->config->item('header_js');

        if(empty($file)){
            return;
        }

        if(is_array($file)){
            if(!is_array($file) && count($file) <= 0){
                return;
            }
            foreach($file AS $item){
                $header_js[] = $item;
            }
            $ci->config->set_item('header_js',$header_js);
        }else{
            $str = $file;
            $header_js[] = $str;
            $ci->config->set_item('header_js',$header_js);
        }
    }
}

//Dynamically add CSS files to header page
if(!function_exists('add_css')){
    function add_css($file='')
    {
        $str = '';
        $ci = &get_instance();
        $header_css = $ci->config->item('header_css');

        if(empty($file)){
            return;
        }

        if(is_array($file)){
            if(!is_array($file) && count($file) <= 0){
                return;
            }
            foreach($file AS $item){
                $header_css[] = $item;
            }
            $ci->config->set_item('header_css',$header_css);
        }else{
            $str = $file;
            $header_css[] = $str;
            $ci->config->set_item('header_css',$header_css);
        }
    }
}

if(!function_exists('put_headers')){
    function put_headers()
    {
        $str = '';
        $ci = &get_instance();
        $header_css = $ci->config->item('header_css');
        $header_js  = $ci->config->item('header_js');


        foreach($header_css AS $item){
            $str .= '<link rel="stylesheet" href="'.base_url().'assets/css/'.$item.'" type="text/css" />'."\n";
        }

        foreach($header_js AS $item){
            $str .= '<script type="text/javascript" src="'.base_url().'assets/js/'.$item.'"></script>'."\n";
        }

        return $str;
    }
}


# function create menu generates bs menu from an array
# @param $menu array
# @return str $nav
if(!function_exists('create_menus')) {
    function create_menus($menu) {
        $nav = '';
        foreach ($menu as $key => $val) {
            if(is_array($val)) {
                $nav .= '<li class="navigation__sub"><a href="#"><i class="'.$val['icon'].'"></i> '.$key.'<i class="fa fa-caret-right pull-right"></i> </a><ul>';
                if(array_key_exists('icon', $val)){
                    array_pop($val);
                }

                //print_r($val);
                foreach($val as $k=>$v){
                    $nav .= '<li class="'.active_link($k).'"><a href="'.site_url($k).'">'.$v.'</a></li>';
                }

                $nav .= '</ul></li>';

            } else {
                $nav.='<li class="'.active_link($key).'"><a href="'.site_url($key).'"><i class="'.$val['icon'].'"></i>'.$key.'</a></li>';

            }

        }
        return $nav;
    }

}



if(! function_exists('active_link')){

    function active_link($link){
        $ci =& get_instance();
        $class = $ci->router->fetch_class();
        $class .= '/';
        $class .= $ci->router->fetch_method();

        return ($class === $link) ? ' class="navigation__active"' : '';
    }

}


if(!function_exists('cloud_encode')){
    function cloud_encode($raw){//string to be encoded
        $CI =&get_instance();
        $CI->load->library('cloud_encode_lib');

        $enc = $CI->cloud_encode_lib->encode($raw);

        return $enc;
    }
}

if(!function_exists('cloud_decode')){
    function cloud_decode($encoded_string){
        $CI =&get_instance();
        $CI->load->library('cloud_encode_lib');

        $dec = $CI->cloud_encode_lib->decode($encoded_string);

        return $dec;
    }
}

if(!function_exists('church_link')){
    function church_link($url){
        $http = (ENVIRONMENT == 'development') ? 'http://' : 'https://';
        $a = str_replace(['http://','http://www.','https://','https://www.'], $http.$url.'.', base_url());

        return $a;
    }
}

if(!function_exists('extract_domain')){
    function extract_domain(){
        return explode('.',$_SERVER['HTTP_HOST'], 2)[0];
    }
}

if(!function_exists('subdomain_exists')){
    function subdomain_exists(){
        $env = (ENVIRONMENT == 'development') ? 1 : 2;
        if(count(explode('.', $_SERVER['HTTP_HOST'])) > $env){

            $subdomain = extract_domain();
            $CI = &get_instance();
            $check = $CI->db->get_where('grow_churches', ['church_website'=>$subdomain]);
            if($check->result()){
                return true;
            } else{
                return false;
            }

        } else {
            return false;
        }

    }
}


if(!function_exists('member_info')){
    function member_info(){
        $CI =&get_instance();
        $id = $CI->session->logged_in['member_id'];
        $a = $CI->db->get_where('grow_members',['member_id'=>$id]);

        return ($a->result_array()) ? $a->result_array()[0] : [];
    }
}

if(!function_exists('member_name')){
    function member_name($member_id){
        $mems = explode(',',$member_id);
        if(count($mems)==2){
            $full='';
            foreach ($mems as $member){
                $q = ask_db('title, surname, other_names, email_address','grow_members',(['member_id'=>$member]));
                $full .= isset($q[0])? $q[0]['title'].' '.$q[0]['other_names'].' '.$q[0]['surname'].' & ':lang('no_record').' & ';
            }
            $full_name = substr($full,0,-2);
        } else {
            $q = ask_db('title, surname, other_names, email_address','grow_members',(['member_id'=>$member_id]));
            $full_name = isset($q[0])? $q[0]['title'].' '.$q[0]['other_names'].' '.$q[0]['surname']:lang('no_record');
        }


        return $full_name;
    }
}


if(!function_exists('new_account_mail')){
    function new_account_mail($full_name, $email, $password, $random, $send_credentials = TRUE){
        if($send_credentials === FALSE){
            return TRUE;
        }
        //SET THE DATA NEEDED TO SEND THE EMAIL
        $CI =&get_instance();
        $CI->load->library('email');
        //$CI->load->library('scriptures_lib');


       $scope = $_SESSION['logged_in']['church_id'];
        //$tabs = $scope.'_id';
        //$tab = ($scope !='super')? $_SESSION['logged_in'][$tabs]:'';

        if($scope =='church'){
            $s = church_name('church_id');
        } else {
           // $s = (ENVIRONMENT!='teens')?'Church Management System Admin':'BLW Teens Ministry';
            //do nothing
        }

        $data['full_name'] = $full_name;
        $data['random']    = $random;
        $data['email']     = $email;
        $data['password']  = $password;
        $data['scripture'] = $CI->scriptures_lib->new_leader();
        $subject           = lang('new_account_email');

        $content           = $CI->load->view('email/new_user_account', $data, TRUE);

        $sender_email      = ($_SESSION['logged_in']['church_id'] == 'church') ? 'no-reply@loveworld360.com' : $_SESSION['logged_in']['username'];

        //send the mails
        $CI->email->reply_to($sender_email);
        //$CI->email->from($sender_email,$s);
        $CI->email->from('no-reply@loveworld360.com');
        $CI->email->to($email);
        $CI->email->bcc('folakegiwa@loveworld360.com');
        $CI->email->subject($subject);
        $CI->email->message($content);

        // echo $content;
        if($CI->email->send()){

            return TRUE;
        } else {
            return FALSE;
        };
        $CI->email->clear();

    }
}

if(!function_exists('church_name')){
    function church_name($church_id){
        $q = ask_db('church_name','grow_churches',['church_id'=>"'$church_id'"]);
        $church = (!empty($q))? $q[0]['church_name']: not_available();
        return $church;
    }
}


if(!function_exists('make_form')){
    function make_form($form_data)
    {
        $CI =&get_instance();
        if (!is_array($form_data)) {
            exit('expecting array to make form');
        }
        $fdata = '';
        foreach ($form_data as $key => $value) {
            if ($value['type']=='hidden'){
                $fdata .= '<input name = "'. $value['name'].'" type="hidden"';
                $fdata .= 'value="'.$value['value'].'">';

            } else {

                $fdata .= '<div class="form-group">';
                if(array_key_exists('label', $value)){
                    $fdata .= '<label>'. $value['label']. '</label>';
                }
                $fdata .= '<input ';
                foreach($value as $k=>$v){
                    $fdata .= $k.'="'.$v.'" ';
                }
                $fdata .= '>';
                $fdata .= '<i class="form-group_bar"></i>';
                $fdata .= '</div>';
            }

        }
        return $fdata;



    }


}


if(!function_exists('make_radio')){
    function make_radio($data_radio, $default, $title = NULL)
    {
        //create placeholder and append container
        $html = '<div class="row"><div class="form-group col-sm-9">';
        //check for the supplied argument
        //append to holder during iteration
        if (is_array($data_radio)) {
            $html .='<div class="control-label col-sm-6">'.$title.'</div>';
            //run foreach statement
            //create foreach loop for radio input using array
            $html .='<div class="radio col-sm-6">';
            foreach ($data_radio as $key => $val) {

                $html .= '<div class="col-sm-12">';
                $html .= '<input type="radio"  name="'.$val['name'].'" id="'.$val['id'].'" value="' .$val['value'].'"';
                $html .= ($val['value']==$default) ? 'checked':'';
                $html .='>  <label for="' . $val['id'] . '">' . $val['label'] . '</label>';
                $html .='</div>';

            }$html .='</div>';
        } else {
            echo 'make radio expects an array';
        }
        $html .= '</div></div>';
        return $html;
    }
}



if(!function_exists('make_drop')) {
    function make_drop($post_field_name,$field_name, $arr, $op_value, $op_label,$selected = NULL,$hint = '')
    {
        $html = '';
        $CI =&get_instance();

        if (!is_array($arr)) {
            $html .= '<option value="">No data was found for '.$field_name.'</option>';
            return $html;
        } else {
            $html .= '<div class="form-group"><label class="" for="' . $op_value . '">' . str_replace('_', ' ', $field_name);
            $html .= '<span class="required">*</span>';
            if($hint !='') {
                $html .= '<span class="help-block">'.$hint.'</span>';
            }
            $html .= '</label><div class="">';
            $html .= form_error($field_name);
            $html .= '<select id="' . $op_value . '" data-placeholder="Select" required="required" class="select2 form-control" name="' . $post_field_name . '">';
            $html .= '<option value="">'.lang('select').' '.$field_name.'</option>';
            foreach($arr as $key => $value){


                $html .= '<option value = "';

                $html .= $value[$op_value].'"';
                if ($value[$op_value] == $selected) {
                    $html .=' selected="selected"';
                }
                $html .= '>';

                if(!is_array($op_label)) {
                    $html .= $value[$op_label];
                }

                elseif (is_array($op_label)) {
                    foreach ($op_label as $lab){
                        $html .= ' '.$value[$lab];
                    }
                }
                $html .= '</option>';

            }

            $html .= '</select>';
            $html .= '</div></div>';

            return $html;
        }
    }
}

/*
 * Credit: Her majesty, Hon Folake Giwa
 * @github: github.com/folake.giwa
 */
if(!function_exists('make_radio')){
    function make_radio($data_radio, $default, $title = NULL)
    {
        //create placeholder and append container
        $html = '<div class="row"><div class="form-group col-sm-9">';
        //check for the supplied argument
        //append to holder during iteration
        if (is_array($data_radio)) {
            $html .='<div class="control-label col-sm-6">'.$title.'</div>';
            //run foreach statement
            //create foreach loop for radio input using array
            $html .='<div class="radio col-sm-6">';
            foreach ($data_radio as $key => $val) {

                $html .= '<div class="col-sm-12">';
                $html .= '<input type="radio"  name="'.$val['name'].'" id="'.$val['id'].'" value="' .$val['value'].'"';
                $html .= ($val['value']==$default) ? 'checked':'';
                $html .='>  <label for="' . $val['id'] . '">' . $val['label'] . '</label>';
                $html .='</div>';

            }$html .='</div>';
        } else {
            echo 'make radio expects an array';
        }
        $html .= '</div></div>';
        return $html;
    }
}

//Prepare select statement when dealing with ambiguous fields
if(!function_exists('db_fields')){
    function db_fields($fields,$table){
        $amb = ['created_at','updated_at','church_id','created_by'];
        $t = (is_array($table)) ? $table: explode(',',$table);

        $prep_table = (count($t)==1) ? $t[0]:'';
        $f = (is_array($fields))? $fields: explode(',',$fields);

        $str ='';
        foreach ($f as $val){
            if(in_array($val,$amb)){
                $str .= ($prep_table !='')? $prep_table.'.'.$val.',': $val.',';
            } else {
                $str .= $val.',';
            }
        }
        $select = 'SELECT '.substr($str,0,-1);
        return $select;

    }
}

/*
 * @db_where, returns the where part to be used in the SQL statement
 * @param mixed $where, can be an array or a string, where condition
 * @param str $scope_table, table to be used for filtering the scope
 * @return str for the where part of the SQl query
 */
if(!function_exists('db_where')){
    function db_where($where,$table)
    {

        //ambiguous fields that may exist in other tables
        $amb = ['created_at', 'updated_at', 'church_id', 'created_by'];

        //table is converted to an array, if not already an array
        $t = (is_array($table)) ? $table : explode(',', $table);

        //if the array of table has only one element, we will use it to prepend field names
        $prep_table = (count($t) == 1) ? $t[0] . '.' : '';


        //SET the filters to be used
//        $filter = '';
//        if($scope =='super'){
//            $filter = '';
//        } else if($scope !='') {
//
//            //for any scope, we'll load data based on that scope
//            $s = $scope.'_id';
//            $filter = ($scope_table !='')? $scope_table.'.'.$s.' = '.$_SESSION['logged_in'][$s]: $s.' = '.$_SESSION['logged_in'][$s];
//        }

        $str = '';
        $s = '';

        //where clause is converted to array, if not already an array
        $condition = (!is_array($where) && $where != '') ? explode(',', $where) : $where;


        if (!empty($condition)) {
            foreach ($condition as $key => $val) {
                if (is_numeric($key)) {

                    //for arrays with numberic keys, use them as they are
                    $str .= $val . ' AND ';
                } else {

                    //for associative arrays, compare key to value, add table name if ambigous field, ie key = valie
                    $str .= (in_array($key, $amb)) ? $prep_table . $key . ' = ' . $val . ' AND ' : $key . ' = ' . $val . ' AND ';

                }
            }

            //remove the last ' AND ' from the resulting string
            $s .= substr($str, 0, -4);
        }

//        //if we have a filter set from the scope, add it to the where clause
//        if($s !='' && $s!= ' '){
//            $where_string = ($filter !='')? $s. ' AND '.$filter: $s;
//        } else {
//            $where_string = ($scope !='')? $filter:'';
//        }

        return $s;
    }
}

//returns a text area
if(!function_exists('make_text')){
    function make_text($text){
        $html ='';
        if (is_array($text)){
            foreach ($text as $key => $data){
                $html .='<div class="form-group"><label class="form-control-lg" for="elastic-textarea" style="
    padding: .5rem 0rem;""">'.$data['placeholder'].'</label>';
                $html .= '<div class="form-group"><textarea class="form-control textarea-autosize text-counter" style="overflow: hidden; overflow-wrap: break-word; height: 60px;"';
                $html .= 'id="'.$data['id'] .'"' .'name="' .$data['name'] .'"' .'></textarea>';
                $html .= '<div class="text-count-wrapper"><div class="text-count-message" style="display: inline;">';
                $html .= $data['remaining'];
                $html .= '<span class="text-count"></span></div><div class="text-count-overflow-wrapper" style="display: none;"></div></div>';
                $html .= '</div></div>';
            }

        } else {
            echo 'Function expects an array';
        }
        return $html;
    }
}

//Produces a widget with bullet items in a row
//@param $data array ['label'=>'label goes here','time'=>'sub heading, small size, used for time lapse']

if(!function_exists('latest_records')){
    function latest_records($data, $title='Latest Records'){

        $html = '<div class="card-body"><section class="widget" id="shares-widget" data-widgster-load="">';
        $html .= "<header><h5><span class='label label-primary'>$title</span>";
        $html .='</h5><div class="widget-controls"><a data-widgster="load" title="Reload" href="#">';
        $html .='<a data-widgster="close" title="Close" href="#"><strong class="text-gray-light"> ';
        $html .='</strong></a></div></header>';
        $html .='<div class="body no-padding"><div class="list-group list-group-lg">';
        if(is_array($data) && count($data)>=1){
            foreach($data as $k=>$v) {
                $arr = ['text-danger','text-info','text-success','text-warning'];
                $p = array_rand($arr,1);
                $html .='<a href="#" class="list-group-item pl-0 pr-0">';
                $html .='<span class="thumb-sm pull-left mr"><i class="fa fa-check mr-3"></i></span>';
                $html .='<i class="fa fa-circle pull-right '.$arr[$p].' mt-sm"></i>';
                $html .='<h5 class="no-margin">'.$v['label'].'</h5>';
                $html .='<small class="text-muted ml-4">'.$v['time'].'</small></a>';
            }
            $html .='</div></div></section></div>';

        } else {
            $arr = ['text-danger','text-info','text-success','text-warning'];
            $p = array_rand($arr,1);

            $html .='<a href="#" class="list-group-item">';
            $html .='<span class="thumb-sm pull-left mr"><i class="fa fa-check"></i></span>';
            $html .='<i class="fa fa-circle pull-right '.$arr[$p].' mt-sm"></i>';
            $html .='<h5 class="no-margin">'.lang('no_record').'</h5>';
            $html .='</a>';
            $html .='</div></div></section></div>';
        }

        return $html;
    }
}

/*
 * COMPOUND SELECT
 * returns multi-dimensional array, each record set on each row
 * @param $fields mixed, fields to be selected from tables. Accepts string or indexed array
 * @param $table string or indexed array
 * @param $where
 *
 */
if(!function_exists('ask_db')){
    function ask_db($fields,$tables,$where='', $group = '', $order = '',$sort ='',$limit =''){
        $CI =&get_instance();//get an instance of ci object


        $select         = db_fields($fields,$tables);
        $wh_str         = db_where($where,$tables);
        $prep_where     = ($wh_str !='')? 'WHERE '.$wh_str:'';





        $t = (is_array($tables))? $tables : explode(',',$tables);
        $tab = '';
        foreach ($t as $val){
            $tab .= $val.','; //append each item in table to $tab string
        }

        $table   = substr($tab,'0','-1');//remove the last comma

        $group_by = ($group !='')?'GROUP BY '.$group: '';
        $sort_or  = ($sort !='ASC' )?'DESC' : 'ASC';
        $order_by = ($order !='' )?'ORDER BY '.$order.' '. $sort_or : '';



        if($limit !='' && is_int($limit)){
            $query = $CI->db->query("$select FROM $table $prep_where $group_by $order_by LIMIT $limit");
        } else {
            $query = $CI->db->query("$select FROM $table $prep_where $group_by $order_by");
        }

        if(is_object($query)){
            $q     = $query->result_array();//if it returns an object, give us the result as an array
            return $q;
        } else {
            return;
        }


    }

}

/*
 * @function Count the rows in a table
 * @param $key; what we are counting
 * @param $table; from which table
 * @param $where, where clause, can be a full string or array
 * @param $group by; field to group by
 * @return int total count or 0 if no record found
 * count_db('member_id','grow_members')
 * ['begin'=>$this->input->post('begin'), 'end'=>$this->input-post('end')]
 *
 */

if(!function_exists('count_db')){

    function count_db($key,$table,$where=NULL,$group=NULL){

        //assign CI super object
        $CI =&get_instance();

        $wh_str         = db_where($where,$table);
        $prep_where     = ($wh_str !='')? 'WHERE '.$wh_str:'';

        //prepare the DB query
        if($group != NULL){
            $query  = "SELECT COUNT($key) as total FROM $table $prep_where group by $group";
        } else {
            $query  = "SELECT COUNT($key) as total FROM $table $prep_where";
        }

        $q      = $CI->db->query($query); //execute

        //return the count if there was result, else return 0
        if(is_object($q)){
            //if we are grouping, we require number of rows
            if($group!=NULL || $group !=''){
                $count = $q->num_rows();
            } else {//if we are not grouping, we expect only one row, we return the value in that row
                $count  = $q->row('total');
            }

            if ($count!= NULL){//lets return count if there is a value
                return $count;
            } else {
                return 0;//return zero of there is no value
            }

        } else  {
            return 0;
        }

    }

}

if(!function_exists('pick_month')){
    function pick_month ($dates){
        // counts the seconds from Jan 1970 - don't touch
        $sec = strtotime($dates);

        // pick what you want
        $dates = date("F", $sec);

        // print final date and time
        echo $dates;
    }
}

/*
 * SUM DB sums a field in a table
 * @param $sum str the field that we are adding - just one field
 * @param $table from which we are counting - just one table
 * @param $where str or array, where condition
 * @return int, formatted number, 900, 1.2K for thousands, 1.2M for millions, 1.4B for billions, 2.1T for trillions
 *
 */
if(!function_exists('sum_db')){
    function sum_db($sum,$table,$where,$group=NULL,$short = TRUE){
        $filter ='';
        $str = '';

        if(is_array($where)){
            end($where);
            $lastKey = key($where);//returns last element key
            foreach ($where as $keys => $value){
                if(is_numeric($keys)){

                    if($keys != $lastKey){
                        $str .= $value .' AND ';
                    } else {
                        $str .= $value.' AND ';
                    }
                }
                elseif($keys != $lastKey) {
                    $str .= $keys .'='.$value. ' AND ';
                }else {
                    $str .= $keys .'='.$value. ' AND ';
                }
            }
            $prep = 'WHERE '.$str;

            if($filter !=''){
                $prep .= $filter;
                $prep_where = $prep;

            } else {
                $prep_where = substr($prep,0,'-4');
            }
        }

        elseif($where !='') {
            $prep_where = 'WHERE '. $where;
            if($filter !=''){
                $prep_where .= ' AND '.$filter;
            }
        } elseif ($where == ''){
            $prep_where = 'WHERE '. $where;
            if($filter !=''){
                $prep_where .= $filter;
            }
        }


        if($group != NULL){

            $query = raw_db("SELECT SUM($sum) AS total FROM $table $prep_where GROUP BY $group");
        } else {
            $query = raw_db("SELECT SUM($sum) AS total FROM $table $prep_where");
        }


        if(is_array($query) && array_key_exists(0,$query)){
            if ($short != TRUE){
                $result = short_number($query[0]['total'],2);

            }else {

                $result = floor($query[0]['total']);
            }

            return $result;
        } else {
            return 0;
        }
    }
}

/*
 * EXECUTE RAW SQL FROM ANYWHERE
 * accepts standard mysql queries
 * RETURNS ARRAY OF RESULT SET
 */
if(!function_exists('raw_db')){
    function raw_db($raw){
        $CI =&get_instance();
        $query = $CI->db->query($raw);
        if(is_object($query)){
            $q     = $query->result_array();
            return $q;
        } else {
            return;
        }
    }
}


/*
 * @param $n int
 * @return nicely formatted number 1K, 100K, 1M, 100M, 1B, 100B, 1T, 100T
 */
function short_number( $n, $precision = 1 ) {
    if ($n >= 0 && $n < 1000) {
        // 0 - 999
        $n_format = number_format($n, $precision);
        $suffix = '';
    } else if ($n >= 1000 && $n < 1000000) {
        // 1k -999k
        $n_format = number_format($n / 1000, $precision);
        $suffix = 'K';
    } else if ($n >= 1000000 && $n < 1000000000) {
        // 0.9m-850m
        $n_format = number_format($n / 1000000, $precision);
        $suffix = 'M';
    } else if ($n >= 1000000000 && $n < 1000000000000) {
        // 0.9b-850b
        $n_format = number_format($n / 1000000000, $precision);
        $suffix = 'B';
    } else  {
        // 0.9t+
        $n_format = number_format($n / 1000000000000, $precision);
        $suffix = 'T';
    }
    // Remove unecessary zeroes after decimal. "1.0" -> "1"; "1.00" -> "1"
    // Intentionally does not affect partials, eg "1.50" -> "1.50"
    if ( $precision > 0 ) {
        $dotzero = '.' . str_repeat( '0', $precision );
        $n_format = str_replace( $dotzero, '', $n_format );
    }
    return $n_format . $suffix;
}
