<?php
/**
 * Created by PhpStorm.
 * User: grow
 * Date: 08/10/2018
 * Time: 6:04 PM
 */

if(!function_exists('tabbed_feed')){
    function tabbed_feed($data){

        $html    = '<div class="tab-container">';

        $html_a   = '<ul class="nav nav-tabs nav-fill" role="tablist">';

        if(is_array($data) && count($data) > 0){
            foreach($data as $key => $val){
                $active = isset($val['active'])?$val['active']:'';
                $html_a   .= '<li class="nav-item">';
                $html_a   .= '<a class="nav-link '.$active.'" data-toggle="tab" href="#'.$val['id'].'" role="tab">'.$val['label'].'</a>';
                $html_a   .= '</li>';
            }
        }
        $html_a   .= '</ul>';

        if(is_array($data) && count($data) > 0){
            $html_b   = '<div class="tab-content">';
            foreach($data as $k => $v){
                $active = isset($v['active'])?$v['active']:'';
                $html_b   .= '<div class="tab-pane '.$active.' fade show" id="'.$v['id'].'" role="tabpanel">';
                $html_b   .= $v['content'];
                $html_b   .= '</div>';
            }
            $html_b .= '</div>';
        }

        $html_c = '</div>';

        return $html . $html_a . $html_b . $html_c;

    }
}

if(!function_exists('tabs_dash')){
    function tabs_dash($data){
        $html 	  = '';
        $html 	 .= '<div class="row quick-stats">';
        if(is_array($data)){
            foreach($data as $key=>$val){
                $html	.= '<div class="col-sm-6 col-md-3"><div class="quick-stats__item"><div class="quick-stats__info">';
                $html .= '<h2>' .$val['total_value'] .'</h2>';
                $html .= '<small>' .$val['id'] .'</small></div>';
                $html .= '<div class="quick-stats__chart peity-bar">' .$val['content'] .'</div></div></div>';
            }
            $html .= '</div>';
        } else{
            echo 'function expects an array';
        }
        return $html;
    }
}

if(!function_exists('report_stats_sec')){
    function report_stats_sec($data){
        $html   = '';
        $html  .= '<div class="listview listview--striped">';
        if(is_array($data)){
            foreach($data as $key=>$val){
                $html   .= '<div class="listview__item">';
                $html   .= '<div class="widget-past-days__info">';
                $html   .= '<small>' .$val['title'] .'</small>';
                $html   .= '<h3>' .$val['figure'] .'</h3></div>';
                $html   .= ' <div class="widget-past-days__chart hidden-sm">';
                $html   .= '<div class="peity-bar">' .$val['content'] .'</div>';
                $html   .= '</div></div>';
            }
            $html   .= '</div>';
        } else {
            echo 'function expects an array';
        }
        return $html;

    }
}

if(!function_exists('members_pix_list')){
    function members_pix_list($data){
        $html   = '';
        if(is_array($data)){
            foreach($data as $key=>$val){
                $html   .= '<a data-toggle="tooltip" title=""';
                $html   .= 'href="' .$val['mem_link'] .'"';
                $html   .= 'data-original-title=';
                $html   .= '"' .$val['mem_name'] .'">';
                $html   .= '<img class="avatar-img" src="' .$val['mem_source'] .'" alt=""></a>';
            }
        } else {
            echo 'function expects an array';
        }
        return $html;
    }
}

if(!function_exists('church_contact')){
    function church_contact($data){
        $html   = '';
        $html  .= '<div class="card-body">';
        if(isset($data)){
            foreach($data as $key=>$val){
                $html   .= '<h4 class="card-title">' .$val['church_name'] .' ' .lang('contact_info') .'</h4>';
                $html   .= '<h6 class="card-subtitle">' .lang('get_back_to_you') .'</h6>';
                $html   .= '<ul class="icon-list">';
                $html   .= '<li><i class="zmdi zmdi-phone"></i>' .$val['church_phone'] .'</li>';
                $html   .= '<li><i class="zmdi zmdi-email"></i>' .$val['church_email'] .'</li>';
                $html   .= '<li><i class="zmdi zmdi-facebook-box"></i>' .$val['church_fb'] .'</li>';
                $html   .= '<li><i class="zmdi zmdi-twitter"></i>' .$val['church_tw'] .'</li>';
                $html   .= '<li><i class="zmdi zmdi-pin"></i><address>' .$val['church_address'] .'</address></li>';
                $html   .= '</ul>';
            }
        } else {
            echo 'function expects an array';
        }
        $html   .= '</div>';
        return $html;
    }
}
