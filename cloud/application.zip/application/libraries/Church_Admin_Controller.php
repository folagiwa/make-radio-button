<?php
/**
 * File       : Church_Admin_Controller.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/10/18
 * Time: 10:35 AM
 */

class Church_Admin_Controller extends MY_Controller {

    function __construct()
    {
        parent::__construct();
        $this->lang->load('menu',$this->session->language);
        if(!$this->session->logged_in){
            redirect(base_url());
        }
    }

//    public function index(){
//        $data['title']= 'Dashboard';
//        $data['sub_title']= 'You are logged in as ';
//        $data['content'] = $this->load->view('partials/blank',$data, TRUE);
//        $data['links'] = create_menus($this->menu_items());
//        $this->load->view('partials/master',$data);
//    }

    public function menu_items() {
        //return array for creation of menu items
        $menu = [
            //'Dashboard'
//            $this->lang->line('dashboard')=>['icon'=>'fa fa-tachometer'],

            $this->lang->line('organization')=>[

                'organization/church_units'=>$this->lang->line('church_units'),
                'organization/unit_leaders'=>$this->lang->line('unit_leaders'),
                'organization/new_unit'=>$this->lang->line('new_unit'),
                'icon'=>'fa fa-th'
            ],

//            $this->lang->line('church_growth')=>[
//                'church_growth/attendance'=>$this->lang->line('attendance'),
//                'church_growth/financial'=>$this->lang->line('financial'),
//                'church_growth/new_converts'=>$this->lang->line('new_converts'),
//                'church_growth/first_timers'=>$this->lang->line('first_timers'),
//                'icon'=>'fa fa-tree'
//            ],
//
//            $this->lang->line('fellowship')=>[
//                'fellowship/overview'=>$this->lang->line('overview'),
//                'fellowship/fellowship_reports'=>$this->lang->line('fellowship_reports'),
//                'fellowship/manage_group'=>$this->lang->line('manage_group'),
//                'fellowship/cell_outline'=>$this->lang->line('fellowship_outline'),
//                'fellowship/group_leaders'=>$this->lang->line('group_leaders'),
//                'fellowship/growth_history'=>$this->lang->line('growth_history'),
//                'fellowship/members_missing_church'=>$this->lang->line('members_missing_church'),
//                'fellowship/members_missing_cell_meeting'=>$this->lang->line('members_missing_cell_meeting'),
//                'icon'=>'fa fa-th'
//            ],

            $this->lang->line('first_timers')=>[
                //'first_timers/overview'=>$this->lang->line('overview'),
                'church/first_timers/add_first_timer'=>$this->lang->line('add_first_timers'),
                'church/first_timers/first_timers'=>$this->lang->line('manage_first_timers'),
                'icon'=>'fa fa-user-plus'
            ],

            $this->lang->line('members')=>[
//                'members/overview'=>$this->lang->line('overview'),
                'church/members/add_member'=>$this->lang->line('new_member'),
                'church/members/members'=>$this->lang->line('member_list'),
                'church/members/import_members'=>$this->lang->line('import_members'),
                'members/birthdays'=>$this->lang->line('birthdays'),
//                'members/member_profile'=>$this->lang->line('member_profile'),
//                'members/growth_summary'=>$this->lang->line('growth_summary'),
//                'members/growth_report'=>$this->lang->line('growth_report'),
                'icon'=>'fa fa-male'
            ],

            $this->lang->line('service_report')=>[
//                'church/service_report/overview'=>$this->lang->line('overview'),
//                'church/service_report/submit_reports'=>$this->lang->line('submit_reports'),
                'church/service_report/service_reports'=>$this->lang->line('service_reports'),
                'icon'=>'fa fa-area-chart'
            ],

//            $this->lang->line('partnership')=>[
//                'partnership/overview'=>$this->lang->
//                'partnership/manage_birthday_greetings'line('overview'),
//                'partnership/reports'=>$this->lang->line('reports'),
//                'partnership/administrators'=>$this->lang->line('administrators'),
//                'partnership/pledges'=>$this->lang->line('pledges'),
//                'partnership/pledge_redeem_rate'=>$this->lang->line('pledge_redeem_rate'),=>$this->lang->line('manage_birthday_greetings'),
//                'partnership/individual_report'=>$this->lang->line('individual_report'),
//                'partnership/partnership_report_arms'=>$this->lang->line('partnership_report_arms'),
//                'partnership/consistent_partners'=>$this->lang->line('consistent_partners'),
//                'partnership/annual_report'=>$this->lang->line('annual_report'),
//                'icon'=>'fa fa-money'
//            ],

//            $this->lang->line('outreaches')=>[
//                'outreaches/index'=>$this->lang->line('overview'),
//                'outreaches/events'=>$this->lang->line('events'),
//                'outreaches/manage_souls'=>$this->lang->line('manage_souls'),
//                'outreaches/import_souls'=>$this->lang->line('import_souls'),
//                'outreaches/media_feedback'=>$this->lang->line('media_feedback'),
//                'outreaches/impact_report'=>$this->lang->line('impact_report'),
//                'icon'=>'fa fa-bullhorn'
//            ],
//
            $this->lang->line('giving')=>[
//                'giving/index'=>$this->lang->line('overview'),
                'church/giving/new_giving'         =>$this->lang->line('records'),
                'church/giving/new_giving_category'=>$this->lang->line('categories'),
//                'giving/pledges'=>$this->lang->line('pledges'),
//                'giving/administrators'=>$this->lang->line('administrators'),
//                'giving/reminders'=>$this->lang->line('reminders'),
//                'giving/member_not_giving'=>$this->lang->line('member_not_giving'),
//                'giving/giving_reports'=>$this->lang->line('giving_reports'),
                'icon'                      =>'fa fa-credit-card'
            ],

//            $this->lang->line('messaging') => [
//                'messaging/index' => $this->lang->line('overview'),
//                'messaging/manage_messages' => $this->lang->line('manage_messages'),
//                'messaging/system_log' => $this->lang->line('system_log'),
//                'icon' => 'fa fa-inbox'
//            ],

//            $this->lang->line('reports')=>[
//                'reports/index' =>$this->lang->line('overview'),
//                'reports/monthly_report'=>$this->lang->line('monthly_report'),
//                'reports/quarterly_report'=>$this->lang->line('quaterly_report'),
//                'reports/mid_year_report'=>$this->lang->line('mid_year_report'),
//                'reports/annual_report'=>$this->lang->line('annual_report'),
//                'reports/custom_report'=>$this->lang->line('custom_report'),
//                'icon'=>'fa fa-file'
//            ],
            $this->lang->line('accounts')=>[
                'accounts/settings'=>$this->lang->line('settings'),
                'accounts/users'=>$this->lang->line('users'),
                'accounts/profile'=>$this->lang->line('profile'),
                'icon'=>'fa fa-folder-open-o'
            ],
//            $this->lang->line('sign_out')=>[
//                'accounts/logout'=>$this->lang->line('logout'),
//                'icon'=>'mdi zmdi-flash-off zmdi-hc-fw'
//            ]


        ];
        return $menu;
    }

}