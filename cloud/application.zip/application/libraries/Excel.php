<?php
/**
 * File       : Excel.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 10/11/18
 * Time: 13:43
 */
if (!defined('BASEPATH')) exit('No direct script access allowed');

require_once APPPATH."/third_party/PHPExcel.php";

class Excel extends PHPExcel {

    public function __construct()
    {
        parent::__construct();
    }
}