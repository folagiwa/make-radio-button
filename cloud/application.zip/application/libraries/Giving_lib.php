<?php
/**
 * ------------------------------------------------------- *
 * File         : Giving_lib.php.v.1.0
 * Created for  : PROJECT GROW.
 * @Author      : Segun Aruleba
 * @Email       : segunaruleba@loveworld360.com
 * @Kingschat   : +2348121724280
 * Date         : 7/17/17
 * Time         : 3:47 PM
 * ------------------------------------------------------- *
 */

class Giving_lib extends Common_lib {

    protected $CI;
    protected $church;
    protected $template;

    public function __construct()

    {
        parent::__construct();
        $this->CI =& get_instance();
        $this->CI->load->library('form_validation');
        $this->CI->load->library('email');
        $this->CI->load->library('mails_lib');
        $this->CI->load->library('table');
        $this->CI->load->model('members_model');
        $this->CI->load->model('countries_model');
        $this->CI->load->model('giving_records_model');
        $this->CI->load->model('giving_categories_model');
        //$this->CI->load->model('giving_pledges_model');
        $this->CI->load->model('churches_model');
        $this->church = $_SESSION['logged_in']['church_id'];
        //$this->template = ['table_open' => '<table id="datatable-table" class="table table-hover table-striped datatable-table">'];
        $this->template = ['table_open' => '<table id="data-table" class="table table-striped table-hover DataTable">'];



    }
    //convert usd to any currency
    public function convert_usd_to_any($amount, $to){
        // usd to ghs is usd * rate
        $q    = ask_db('exchange_rate','grow_currencies',["currency_code"=>"'$to'"]);
        $rate = $q[0]['exchange_rate'];
        $res  = $amount * $rate;

        return $res;

    }

    //convert any currency to usd
    public function convert_any_to_usd($amount, $from){
        $q    = ask_db('exchange_rate','grow_currencies',["currency_code"=>"'$from'"]);
        $rate = $q[0]['exchange_rate'];
        $res  = $amount / $rate;
        return $res;
    }


    public function convert_any_to_any($amount,$from,$to){
        //convert from to usd
        $usd = $this->convert_any_to_usd($amount,$from);
        $to = $this->convert_usd_to_any($usd,$to);

        return $to;
    }



    public function new_giving ($legend,$links,$action){


        //doing an update if id is passed
        if($this->CI->uri->segment(4)){
            $record_raw = $this->CI->uri->segment(4);
            $record_id = cloud_encode($record_raw);

            //check DB to see if record exists, if it does keep as an array called $regions
            $records_id = $this->CI->giving_records_model->get($record_id);

            if($records_id){

                $cat_id         = $records_id['giving_cat_id'];

                $q1             = ask_db('category_name','grow_giving_categories',"giving_cat_id = $cat_id");
                $q2             = ask_db('giving_name','grow_giving',"giving_id = $cat_id");
                $update         = (isset($q1[0]['category_name']))? $q1[0]['category_name'] : $q2[0]['giving_name'];

                //$update = $this->CI->giving_categories_model->fields(['giving_cat_id','category_name'])->where(['church_id'=> $this->church])->get_all();
                //$update  = $this->CI->giving_categories_model->cat($cat_id);

                $data['title']  = $update ." :: ".$this->CI->lang->line('update_record');

            } else {

                $data['title'] = $this->CI->lang->line('no_record') ." :: ".$this->CI->lang->line('new_record');
            }
        }

        else {

            $data['title'] = $this->CI->lang->line('giving') ." :: ".$this->CI->lang->line('new_record');
        }


        if($this->CI->input->post('record_id')){

            $this->CI->giving_records_model->from_form(NULL,NULL,array('record_id'))->update();
            $this->CI->session->set_userdata('success','Your giving record was successfully updated');

            $from        = $this->CI->input->post('currency_id');
            $local       = $_SESSION['currency'];
            $mbc         = $this->CI->config->item('mbc');
            $amount      = $this->CI->input->post('giving_amount');

            $local_equiv = ($from == $local)?$amount :$this->convert_any_to_any($amount,$from,$local);
            $mbc_equiv   = ($from == $mbc)? $amount :$this->convert_any_to_any($amount,$from,$mbc);


            $data = ['mbc_equiv'=> $mbc_equiv,'local_equiv'=>$local_equiv];
            $this->CI->db->where('record_id', $this->CI->input->post('record_id'));
            $this->CI->db->update('grow_giving_records',$data);

            $record_id = TRUE;

        } else {



            $record_id = $this->CI->giving_records_model->from_form()->insert();


            if ($record_id != '') {
                $this->CI->session->set_userdata('success', lang('save_success'));
                $currency = $this->CI->input->post('currency');
                if ($currency != '') {
                    $from = $this->CI->input->post('currency_id');
                    $local = $_SESSION['currency'];
                    $mbc = $this->CI->config->item('mbc');
                    $amount = $this->CI->input->post('giving_amount');

                    $local_equiv = ($from == $local) ? $amount : $this->convert_any_to_any($amount, $from, $local);
                    $mbc_equiv = ($from == $mbc) ? $amount : $this->convert_any_to_any($amount, $from, $mbc);


                    $data = ['mbc_equiv' => $mbc_equiv, 'local_equiv' => $local_equiv];
                    $this->CI->db->where('record_id', $record_id);
                    $this->CI->db->update('grow_giving_records', $data);


                }

            }
        }



        if($record_id === FALSE)
        {
            $giving_record_info = (!isset($records_id))? '':$records_id ;
            //$church_id    = $this->CI->session->userdata('church_id');
            $data['giving_record_info'] = $giving_record_info;
            $data['members']            = $this->CI->members_model->fields(['member_id','title','surname','first_name'])->where(['church_id'=> $this->church])->get_all();
            $data['giving_category']    = $this->CI->giving_categories_model->fields(['category_name','giving_cat_id'])->get_all();
            $data['currency_id']        = $this->CI->countries_model->fields(['currency_code', 'currency_name'])->get_all();
            $data['legend']             = $legend;
            $data['links']              = $links;
            $data['action']             = $action;
            $data['title']              = lang('giving_record_list');
            $data['table_title']        = lang('new_giving_record') .lang('');
            $data['sub_title']          = lang('giving_record_list');
            $data['table_content']      = $this->giving_records();
            $data['latest']             = latest_records($this->latest_giving_records());
            $data['form_content']       = $this->CI->load->view('giving/new_giving', $data, TRUE);
            $data['scripts']            = $this->CI->load->view('partials/footer_form_blank', $data, TRUE);
            $data['scripts']           .= $this->CI->load->view('partials/footer_tables', $data, TRUE);
            $data['handle']             = $this->CI->load->view('partials/form_blank_tab', $data, TRUE);
            $this->CI->load->view('partials/master', $data);
        }
        else //insert was successful, redirect to list of regions
        {

            redirect($action,'refresh');
        }



    }//end function

    public function latest_giving_records(){
        $arr = $this->fetch_giving_records('5');
        if(is_array($arr)){
            $help = [];
            foreach ($arr as $key=>$v){
                $info = $v['title'].' '.$v['first_name'].' '.$v['surname'].' :: '.$v['category_name'].' :: '.$v['currency_id'].' '.$v['giving_amount'];
                $help[] = ['label'=>$info,'time'=>time_diff($v['updated_at'])];
            }
            return $help;
            //dump($help);
        }
    }

    public function fetch_giving_records($limit=''){
        $fields_all  = ['giving_name as category_name','record_id','record_date','grow_giving_records.giving_cat_id','giving_amount','giving_citation','title','first_name','surname','grow_members.member_id','grow_members.church_id','currency_id','grow_giving_records.updated_at'];
        $field_loc   = ['record_id','record_date','grow_giving_records.giving_cat_id','giving_amount','giving_citation','category_name','title','first_name','surname','grow_members.member_id','grow_members.church_id','currency_id','grow_giving_records.updated_at'];

        $tables_loc  = 'grow_giving_records,grow_members,grow_giving_categories';
        $tables_all  = 'grow_giving_records,grow_members,grow_giving';

        $where_loc   = ['grow_giving_records.member_id'=>'grow_members.member_id','grow_giving_records.giving_cat_id' =>'grow_giving_categories.giving_cat_id'];
        $where_all   = ['grow_giving_records.member_id'=>'grow_members.member_id','grow_giving_records.giving_cat_id' =>'giving_id'];

        $report_loc  = ask_db($field_loc,$tables_loc,$where_loc,'','grow_giving_records.updated_at','DESC','','grow_giving_records',$limit);
        $reports_all = ask_db($fields_all,$tables_all,$where_all,'','grow_giving_records.updated_at','DESC','','grow_giving_records', $limit);

        $reports = (is_array($reports_all) && is_array($report_loc))? array_merge($report_loc, $reports_all):'';

        return $reports;
    }

    public function giving_records(){
        $reports = $this->fetch_giving_records();
        $this->CI->table->set_template($this->template);
        $headers =[
            'givers'             => ['data'=>lang('full_name'),'class'      =>''],
            'Date_range'         => ['data'=>lang('record_date'),'class' =>''],
            'specific_project'   => ['data'=>lang('giving_purpose'),'class'  =>''],
            'created_by'         => ['data'=>lang('giving_amount'),'class'  =>''],
            'manage'             => ['data'=>lang('manage'),'class'      =>''],
        ];
        $this->CI->table->set_heading($headers);
        if(is_array($reports)) {
            foreach ($reports as  $row) {
                //append html string with ids for update and delete
                $manage  = anchor("giving/new_giving/".$row['record_id'] ,'<i class="fa fa-pencil-square-o"></i>');
                $manage .= ' :: ';
                $manage .= anchor("giving/delete_giving_record/".$row['record_id'], '<i class="fa fa-times"></i>');
                $amount  = $row['currency_id'].' '.$row['giving_amount'];
                $giver   = anchor("members/member/".($row['member_id']), $row['title'] .' '. $row['first_name'] .' '. $row['surname']);
                //assign actual values in table cells
                $data = [
                    'givers'            => ['data' => $giver,                          'class' => ''],
                    'Date_range'        => ['data' => $row['record_date'],             'class'  => ''],
                    'Specific_project'  => ['data' => $row['category_name'],           'class'  => ''],
                    'created_by'        => ['data' => $amount,                         'class'  => ''],
                    'manage'            => ['data' => $manage,                         'class'  => ''],
                ];

                //add each item in loop as a table row
                $this->CI->table->add_row($data);
            }
        } else {
            //show empty record if we did not get any data
            $no_recs =      [

                'givers'           => ['data'=>lang('no_record'),'class'=>''],
                'Date_range'       => ['data'=>lang('no_record'),'class'=>''],
                'specific_project' => ['data'=>lang('no_record'),'class'=>''],
                'created_by'       => ['data'=>lang('no_record'),'class'=>''],
                'manage'           => ['data'=>lang('no_record'),'class'=>''],
            ];

            $this->CI->table->add_row($no_recs);

        }
        return $this->CI->table->generate();

    }

    /*public function fetch_giving_list(){
        return $this->giving_records('giving_list');
    }*/

    public function new_giving_category($legend,$links,$action){

        //doing an update if id is passed
        if($this->CI->uri->segment(4)){
            $giving_cat_id = $this->CI->uri->segment(4);

            //check DB to see if record exists, if it does keep as an array called $regions
            $record_id = $this->CI->giving_categories_model->get($giving_cat_id);
            if($record_id){

                $data['title']  = $record_id['category_name'] ." :: ".$this->CI->lang->line('update_record');

            } else {

                $data['title'] = $this->CI->lang->line('no_record') ." :: ".$this->CI->lang->line('new_record');
            }
        }

        //doing an insert by default
        else {

            $data['title'] = $this->CI->lang->line('giving') ." :: ".$this->CI->lang->line('new_record');
        }

        //if we have an ID, it is an update
        if($this->CI->input->post('giving_cat_id')){
            $this->CI->giving_categories_model->from_form(NULL,NULL,array('giving_cat_id'))->update();
            $this->CI->session->set_userdata('info',lang('update_success'));
            $giving_cat_id = TRUE;
        } else {

            //we are doing an insert by default when this controller is evoked
            $giving_cat_id = $this->CI->giving_categories_model->from_form()->insert();
            if($giving_cat_id){
                $this->CI->session->set_userdata('info',lang('save_success'));
            }


        }


        if($giving_cat_id === FALSE)
        {

            $data['members'] = $this->CI->members_model->fields(['member_id','title','surname','first_name'])->where(['church_id'=> $this->church])->get_all();

            $mem_info = (!isset($record_id))? '':$record_id ;
            $data['giving_cat'] = $mem_info;
            $data['legend'] = $legend;
            $data['action'] = $action;
            $data['links'] = $links;
            $data['sub_title']          = lang('giving_record_list');
            //$data['latest'] = latest_records($this->latest_giving_category());
            $data['form_content'] = $this->CI->load->view('giving/new_giving_category', $data,TRUE);
            $data['handle'] = $this->CI->load->view('partials/blank_form',$data,TRUE);
            $this->CI->load->view('partials/master', $data);
        }
        else //insert was successful, redirect to list of regions
        {

            redirect($action,'refresh');

        }


    }








}
