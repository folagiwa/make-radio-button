<?php
/**
 * File       : Peoples_lib.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 10/2/18
 * Time: 21:56
 */

Class People_lib
{

    protected $CI;
    protected $church;
    protected $member;
    protected $template;
    protected $loc;
    protected $use;
    protected $is_admin;

    public function __construct()
    {
        $this->CI =& get_instance();
        $this->CI->load->model('members_model');
        $this->CI->load->library('form_validation');
        $this->CI->load->model('countries_model');
        $this->CI->load->model('cities_model');
        $this->CI->load->model('states_model');
        $this->CI->load->model('tags_model');
        $this->CI->load->library('table');
        $this->church = $_SESSION['logged_in']['church_id'];
        $this->member = $_SESSION['logged_in']['member_id'];
        $this->template = ['table_open' => '<table id="datatable-table" class="table table-striped table-hover datatable-table">'];
        $this->use = ($this->CI->uri->segment(2) == 'first_timers')?'first_timers':'members';
        $this->loc      = ($this->is_admin == 1)? '':'church';


    }




    public function new_member($legend, $links, $action, $success_page) {
        $d_c = ask_db('church_state,church_country,church_city','grow_churches',['church_id'=>$this->church]); //default country
        $dc = isset($d_c['0']['church_country'])?$d_c['0']['church_country']: [];
        $ds = isset($d_c['0']['church_state'])? $d_c['0']['church_state']:[];
        if(!is_array($ds)){
            $cd =  $this->CI->cities_model->where(['state_id'=>$ds])->get_all();
        } else {
            $cd = [];
        }
        //doing an update if id is passed
        if($this->CI->uri->segment(4))
        {
            $member    = $this->CI->uri->segment(4);

            $mem       = cloud_decode($member);
            $mem_info    = $this->CI->members_model->get($mem);

            $data['title'] = (is_array($mem_info))? $mem_info['title'].' '.$mem_info['surname'].' '.$mem_info['first_name']." :: ".lang('update_record'): lang('no_record') ." :: ".lang('new_record');

            $country = ['country_id'=>$mem_info['country']];
            $state =['state_id'=>$mem_info['state']];
            $st = $this->CI->states_model->where($country)->get_all();
            $city =$this->CI->cities_model->where($st)->get_all();

        } //update member profile here
        elseif($this->CI->uri->segment(3) == 'edit_profile'){
            $mem_info = $this->CI->members_model->get($this->member);
            $country = ['country_id'=>$mem_info['country']];
            $state =['state_id'=>$mem_info['state']];
            $st = $this->CI->states_model->where($country)->get_all();
            $city =$this->CI->cities_model->where($st)->get_all();
            $data['title'] = $mem_info['title'].' '.$mem_info['surname'].' '.$mem_info['first_name']." :: ".lang('update_profile');

            //Insert new record
        } else  {
            $uri = $this->CI->uri->segment(2);
            $data['title'] = ($uri == 'members') ? lang('member') ." :: ".lang('new_record') : lang('first_timers') ." :: ".lang('new_record');
            $mem_info = '';
        }
            //$mem_info = '';


        //if we have an ID, it is an update
        if($this->CI->input->post('member_id')) {
            $this->CI->members_model->from_form(NULL,NULL, array('member_id'))->update();
            $this->CI->session->set_userdata('info', lang('update_success'));

            $data = [
                'member_id'    =>$this->CI->input->post('member_id'),
                'tag_id'      =>$this->CI->input->post('group_assigned'),
                'church_id'    =>$this->CI->input->post('church_id'),
                'created_by'   =>$this->CI->input->post('created_by'),
                'created_at'   =>date('Y-m-d h:i:s')
            ];

            $this->CI->db->where('member_id',$this->CI->input->post('member_id'));
            $this->CI->db->update('grow_fellowship_members',$data);

            $data_user = [
                'username' =>$this->CI->input->post('email_address')
            ];
            $this->CI->db->where('member_id',$this->CI->input->post('member_id'));
            $this->CI->db->update('grow_users',$data_user);
            //$member_id = TRUE;


            if ($_FILES['member_picture']['name'] != '') {

                $cust = cloud_encode($this->CI->input->post('member_id'));
                $ext = pathinfo($_FILES['member_picture']['name'], PATHINFO_EXTENSION);

                $allowed = ['jpg', 'jpeg', 'png', 'gif'];

                //upload only valid files
                if (in_array($ext, $allowed)) {
                    $filename = 'member_photos/' . $cust . '.' . $ext;
                    $file_name = $cust . '.' . $ext;
                    $temp = $_FILES['member_picture']['tmp_name'];

                    $data_o = ['member_picture' => $file_name];
                    $this->CI->db->where('member_id', $this->CI->input->post('member_id'));
                    $this->CI->db->update('grow_members', $data_o);

                    $this->CI->load->library('s3');
                    $this->CI->s3->putObjectFile($temp, "loveworldgrow", $filename, S3::ACL_PUBLIC_READ);
                }

            }
            $member_id = TRUE;

        } else {
            //we are doing an insert by default when this controller is evoked, @return id.

            $member_id = $this->CI->members_model->from_form()->insert();

            if ($member_id) {

                if (($this->CI->input->post('group_assigned') == 0)) {
                    $data = [
                        'member_id' => $member_id,
                        'tag_id' => $this->CI->input->post('group_assigned'),
                        'church_id' => $this->CI->input->post('church_id'),
                        'created_by' => $this->CI->input->post('created_by'),
                        'created_at' => date('Y-m-d')
                    ];
                    //add him to the cell
                    $this->CI->db->insert('grow_fellowship_members', $data);
                }


//              $structure = [
//                  'church_id'     =>$this->CI->input->post('church_id'),
//              ];
//
//
//              $send = ($this->CI->input->post('send_email') == 'yes') ? TRUE: FALSE;
//
//              if ($_FILES['member_picture']['name'] !='') {
//
//                  $cust = cloud_encode($this->CI->input->post('member_id'));
//                  $ext = pathinfo($_FILES['member_picture']['name'], PATHINFO_EXTENSION);
//
//                  $allowed = ['jpg', 'jpeg', 'png', 'gif'];
//
//                  //upload only valid files
//                  if (in_array($ext, $allowed)) {
//                      $filename = 'member_photos/' . $cust . '.' . $ext;
//                      $file_name = $cust . '.' . $ext;
//                      $temp = $_FILES['member_picture']['tmp_name'];
//
//                      $data_o = ['member_picture' => $file_name];
//                      $this->CI->db->where('member_id', $this->CI->input->post('member_id'));
//                      $this->CI->db->update('grow_members', $data_o);
//
//                      $this->CI->load->library('s3');
//                      $this->CI->s3->putObjectFile($temp, "loveworldgrow", $filename, S3::ACL_PUBLIC_READ);
//                  }
//              }
//              $this->CI->users_lib->create_new_user($structure,$member_id,'1',$user_type ='member',$send);
//              $this->CI->session->set_userdata('info',lang('save_success'));
//          } elseif ($this->CI->input->post()) {
//              $m = lang('mem_error').' : '.$this->CI->input->post('email_address');
//              $this->CI->session->set_userdata('error',$m);
//          }
//
//        }
                 }
        }

                if ($member_id === FALSE) {
                    $data['data_drop'] = $this->CI->countries_model->fields(['country_id', 'country_name'])->get_all();
                    $data['states'] = (isset($state)) ? $state : $this->CI->states_model->where(['country_id' => $dc])->get_all();
                    $data['cities'] = (isset($city)) ? $city : $cd;
                    $data['dc'] = $dc;
                    $data['ds'] = $ds;
                    $data['member_info'] = (isset($mem_info)) ? $mem_info : '';
                    $data['legend'] = $legend;
                    $data['action'] = $action;
                    $data['links'] = $links;
                    $data['form_content'] = $this->CI->load->view('people/new_member', $data, TRUE);
                    $data['scripts'] = $this->CI->load->view('partials/footer_blank', $data, TRUE);
                    $data['handle'] = $this->CI->load->view('partials/blank_form_options', $data, TRUE);
                    $this->CI->load->view('partials/master', $data);
                } else {
                    //insert was successful, redirect to list of regions
                    $this->CI->session->set_userdata('info', lang('save_success'));

                    redirect($success_page, 'refresh');
                }

            }



    public function members($limit=''){
        $fields = ['member_id,title,surname,first_name,marital_status,gender,service_date,home_address,nearest_landmark,first_day_in_church,is_new_convert,prayer_request,birth_date,invited_by,email_address,group_assigned,mobile_phone,profession,grow_members.church_id,grow_members.created_by'];
        $table = 'grow_members,grow_service_reports';
        $where = [];
        if($this->CI->uri->segment('2') == 'first_timers'){

            $where+=["first_day_in_church <>'grow_service_reports.service_date'",$this->church];
        }
        $q = ask_db($fields,$table,$where,'','grow_members.updated_at','DESC',$limit);

        return $q;

    }

    public function member_list($links)
    {
        $arr = $this->members();

        $this->CI->table->set_template($this->template);

        $header = [
            'full_name'         => ['data' => lang('full_name'),            'class' => ''],
            'mobile_phone'      => ['data' => lang('mobile_phone'),         'class' => 'hidden-xs'],
            'gender'            => ['data' => lang('gender'),               'class' => 'hidden-xs'],
            'marital_status'    => ['data' => lang('marital_status'),       'class' => 'hidden'],
            'occupation'        => ['data' => lang('profession'),           'class' => 'hidden'],//hide @mobile
        ];
        // $this->CI->table->set_heading($header);

        if ($this->CI->uri->segment(2) == 'first_timers') {
            $header += [
                //'group_assigned'        => ['data' => lang('group_assign'),             'class' => 'hidden-xs hidden-sm'],
                'first_day_in_church'   => ['data' => lang('first_day_in_church'),      'class' => ''],
                'prayer_request'        => ['data' => lang('prayer_request'),           'class' => 'hidden'],
                //'nearest_landmark'      => ['data' => lang('nearest_landmark'),         'class' => 'hidden'],
               // 'date_of_birth'         => ['data' => lang('birth_date'),               'class' => 'hidden'],
                'home_address'          => ['data' => lang('home_address'),             'class' => 'hidden']
            ];
        }

            $header += [
                'manage' => ['data' => lang('manage'), 'class' => 'hidden-xs hidden-sm']
                   ];
            $this->CI->table->set_heading($header);

        if (is_array($arr)) {
            foreach($arr as $key=>$val) {
                $enc = cloud_encode($val['member_id']);
                $p = $this->is_admin;
                if ($this->CI->uri->segment(2) == 'first_timers') {

                    $manage = anchor("church/first_timers/add_first_timer/" . $enc, '<i class="fa fa-pencil-square-o"></i>');
                    $manage .= ' :: ';
                    $manage .= anchor("/$this->use/delete_first_timer/" . $enc, '<i class="fa fa-times"></i>');

                    $data_items = [
                        'full_name'             => ['data' => anchor("$p/first_timers/first_timers/" . $enc, $val['title'] . ' ' . $val['surname'] . ' ' . $val['first_name']), 'class' => ''],
                        'mobile_phone'          => ['data' => $val['mobile_phone'],                 'class' => 'hidden-xs'],
                        'gender'                => ['data' => $val['gender'],                       'class' => 'hidden-xs'],
                        'marital_status'        => ['data' => $val['marital_status'],               'class' => 'hidden'],
                        'occupation'            => ['data' => $val['profession'],                   'class' => 'hidden'],
                    ];

                } else {
                    $t = base_url('church/members/add_member/');

                    $manage = anchor($t . $enc, '<i class="fa fa-pencil-square-o"></i>');
                    $manage .= ' :: ';
                    $manage .= ' :: ';
                    $manage .= anchor("#", '<i class="fa fa-times"></i>', ['data-toggle' => "modal", 'data-target' => "#f_records", 'data-id' => $enc]);
                    $manage .= ' :: ';

                    $full_name = $val['title'] . ' ' . $val['surname'] . ' ' . $val['first_name'];

                    $data_items = [
                        'full_name'         => ['data' => anchor("church/members/members/" . $enc, $full_name), 'class' => ''],
                        'work_phone'        => ['data' => $val['mobile_phone'], 'class' => ''],
                        'gender'            => ['data' => $val['gender'], 'class' => ''],
                        'marital_status'    => ['data' => $val['marital_status'], 'class' => ''],
                        'occupation'        => ['data' => $val['profession'], 'class' => 'hidden'],

                    ];

                }

                if ($this->CI->uri->segment(2) == 'first_timers') {

                    $data_items += [
                       // 'group_assigned'        => ['data' => ($val['group_assigned']),         'class' => 'hidden-xs'],
                        'first_day_in_church'   => ['data' => $val['first_day_in_church'],      'class' => ''],
                        'prayer_request'        => ['data' => $val['prayer_request'],           'class' => 'hidden'],
                       // 'date_of_birth'         => ['data' => $val['birth_date'],               'class' => 'hidden'],
                       // 'nearest_landmark'      => ['data' => $val['nearest_landmark'],         'class' => 'hidden'],
                        'home_address'          => ['data' => $val['home_address'],             'class' => 'hidden']

                    ];
                }
                $data_items += [
                    'manage' => ['data' => $manage, 'class' => 'hidden-xs hidden-sm']
                ];
                $this->CI->table->add_row($data_items);
            }
        } else {
            $no_recs = [
                'church_name'       => ['data' => lang('no_record'), 'class' => ''],
                'group_assigned'    => ['data' => lang('no_record'), 'class' => ''],
            ];

//            if ($this->CI->uri->segment(2) == 'first_timers') {
//                $no_recs += [
//                    'follow_ups'    => ['data' => lang('no_record'), 'class' => ''],
//                    'fs_status'     => ['data' => lang('no_record'), 'class' => ''],
//                    'email_address' => ['data' => lang('no_record'), 'class' => 'hidden-xs hidden-sm']
//                ];
//                $this->CI->table->add_row($no_recs);
//            }
        }
        $r = $this->CI->table->generate();
        if ($this->CI->uri->segment(2) == 'first_timers') {
            $data['title'] = lang('first_timers') . " :: " . lang('list');
        } else {
            $data['title'] = lang('members') . " :: " . lang('list');
        }

        $data['links'] = $links;
        $data['content'] = $r;
        //$data['links']  = $this->links;
        $data['scripts'] = $this->CI->load->view('partials/footer_tables',$data,TRUE);
        $data['handle'] = $this->CI->load->view('partials/tables', $data, TRUE);
        $data['handle'] =$this->CI->load->view('partials/blank',$data,TRUE);
        $this->CI->load->view('partials/master',$data);
    }




//            foreach($arr as $key=>$val){
//
//                $manage =   anchor("/members/members/".cloud_encode($val['member_id']), '<i class="fa fa-pencil-square-o"></i>');
//                $manage .=  ' :: ';
//                $manage .=  anchor("/members/delete_member/" . $val['member_id'], '<i class="fa fa-times"></i>');
//
//                $full_name = $val['title'].' '.$val['surname'].' '.$val['first_name'];
//                $data = [
//                    'full_name'         => ['data'=>anchor("$this->church/members/members/".cloud_encode($val['member_id']),$full_name),'class'=>''],
//                    'work_phone'        => ['data'=>$val['mobile_phone'],'class'=>''],
//                    'gender'            => ['data'=>$val['gender'],'class'=>''],
//                    'marital_status'    =>['data'=>$val['marital_status'],'class'=>''],
//                    'manage'            => [$manage]
//
//                ];
//                $this->CI->table->add_row($data);
//            }
//        } else{
//
//            $no_recs = [
//                'full_name'         => ['data'=>lang('no_recs'),    'class'=>''],
//                'work_phone'        => ['data'=>lang('no_recs'),    'class'=>''],
//                'gender'            => ['data'=>lang('no_recs'),    'class'=>''],
//                'marital_status'    => ['data'=>lang('no_recs'),    'class'=>''],
//                'manage'            => ['data'=>lang('no_recs'),  'class' => '']
//
//
//            ];
//            $this->CI->table->add_row($no_recs);
//
//        }
//        $data['title']      = lang('member_list') ."::".lang('list');
//        $data['links']      = $links;
//        $data['content']    = $this->CI->table->generate();
//        $data['scripts']    = $this->CI->load->view('partials/footer_tables',$data,TRUE);
//        $data['handle'] =$this->CI->load->view('partials/blank',$data,TRUE);
//        $this->CI->load->view('partials/master',$data);

//    }


    //FALSE MEANS EMAIL EXISTS
    public function email_exists($email){
        if(filter_var($email, FILTER_VALIDATE_EMAIL)){ //if we have a valid email, check if it exists
            $sn_email = str_replace("'",'',$email);
            $q = ask_db('email_address','grow_members',['email_address'=>"'$sn_email'"]);
            return isset($q[0])? FALSE : TRUE; //if it exist, return false else return true
        } else if($email=== NULL || $email =='') { //catch empty strings as well

            return TRUE; //True means go ahead
        } else {
            return FALSE;
        }

    }

    public function phone_exists($phone){

        if(!empty($phone) && (filter_var($phone,FILTER_VALIDATE_INT))){

            $q = ask_db('home_phone','grow_members',['home_phone'=>"'$phone'"]);
            if (isset($q[0])){
                return FALSE;
            }elseif (filter_var($phone,FILTER_VALIDATE_INT)){ //if it does not exist and its a valid number
                return TRUE;
            }else if(!filter_var($phone, FILTER_VALIDATE_INT)){
                return FALSE;
            }

        } else {
            $str = 'provisional';
            return $str;
        }

    }

    public function check_date($date){
        //checkdate checks for valid date(month,day,year) returns true or false
        if (preg_match('#^(\d{4})-(\d{2})-(\d{2})$#', $date, $matches) && checkdate($matches[2], $matches[3], $matches[1])) {
            return TRUE;
        }else {
            return FALSE;
        }
    }

    /**
     * @param $legend
     * @param $links
     * @param $action
     */
    public function import_members($legend, $links, $action)
    {

        set_time_limit(0);
        $type = $this->CI->uri->segment(3);
        $des = $this->CI->uri->segment(2);
        $a = '';
        $b='';
        if ($this->CI->input->post())

        {
            $q = ask_db('church_country, church_state, church_city','grow_churches',"church_id= $this->church");
            $country = $q[0]['church_country'];
            $state   = $q[0]['church_state'];
            $city    = $q[0]['church_city'];

            //$cells = $this->get_cells_in_city($city);
            //$membs = $this->get_members_in_city($city);


            //load the excel library
            $this->CI->load->library('excel');
            //Path of files were you want to upload on localhost (C:/xampp/htdocs/ProjectName/uploads/excel/)
            $configUpload['upload_path'] = FCPATH.'files/excel/';
            $configUpload['allowed_types'] = 'xlsx';
            $configUpload['max_size'] = '5000';
            $this->CI->load->library('upload', $configUpload);


            $this->CI->upload->do_upload('file_name');
            $upload_data = $this->CI->upload->data(); //Returns array of containing all of the data related to the file you uploaded.
            $file_name = $upload_data['file_name']; //uploded file name
            $extension=$upload_data['file_ext'];    // uploded file extension

            //$objReader =PHPExcel_IOFactory::createReader('Excel5');     //For excel 2003
            $objReader= PHPExcel_IOFactory::createReader('Excel2007');	// For excel 2007
            //Set to read only
            $objReader->setReadDataOnly(true);
            //Load excel file
            $objPHPExcel   = $objReader->load(FCPATH.'files/excel/'.$file_name);
            $totalrows     = $objPHPExcel->setActiveSheetIndex(0)->getHighestRow();   //Count Numbe of rows avalable in excel
            $objWorksheet  = $objPHPExcel->setActiveSheetIndex(0);
            //loop from first data untill last data

            $up_error = [];
            for($i=2;$i<=$totalrows;$i++)

            {
                $s = !empty($cells)? array_rand($cells):'1';
                $m = !empty($membs)? array_rand($membs):'1';
                $tag_id = ($type === 'import_first_timers' && isset($cells[$s]))? $cells[$s]['cell_id']:'0';//assign first timers to cells radomly
                $mem_id = ($type === 'import_first_timers' && isset($membs[$m]))? $membs[$m]['member_id']:'';//assign first timers to members radomly

                $title             = $objWorksheet->getCellByColumnAndRow(0,$i)->getValue();
                $surname           = $objWorksheet->getCellByColumnAndRow(1,$i)->getValue();
                $first_name        = $objWorksheet->getCellByColumnAndRow(2,$i)->getValue(); //Excel Column 1
                $birth_date        = $objWorksheet->getCellByColumnAndRow(3,$i)->getValue(); //Excel Column 2
                $gender            = $objWorksheet->getCellByColumnAndRow(4,$i)->getValue(); //Excel Column 3
                $home_phone        = $objWorksheet->getCellByColumnAndRow(5,$i)->getValue(); //Excel Column 4
                $cell_phone        = $objWorksheet->getCellByColumnAndRow(5,$i)->getValue(); //Excel Column 4
                $work_phone        = $objWorksheet->getCellByColumnAndRow(5,$i)->getValue(); //Excel Column 4

                $email_address     = $objWorksheet->getCellByColumnAndRow(6,$i)->getValue(); //Excel Column 4
                $home_address      = $objWorksheet->getCellByColumnAndRow(7,$i)->getValue(); //Excel Column 4
                $marital_status    = $objWorksheet->getCellByColumnAndRow(8,$i)->getValue(); //Excel Column 4
                //$fs_status         = $objWorksheet->getCellByColumnAndRow(9,$i)->getValue(); //Excel Column 4
                $is_baptised       = $objWorksheet->getCellByColumnAndRow(10,$i)->getValue(); //Excel Column 4
                $city_id           = $objWorksheet->getCellByColumnAndRow(11,$i)->getValue(); //Excel Column 4

                $first_day_in_church  = $objWorksheet->getCellByColumnAndRow(12,$i)->getValue(); //Excel Column 4
                $prayer_request       = $objWorksheet->getCellByColumnAndRow(13,$i)->getValue(); //Excel Column 4
                //$ft_source            = $objWorksheet->getCellByColumnAndRow(14,$i)->getValue(); //Excel Column 4
                $nearest_landmark     = $objWorksheet->getCellByColumnAndRow(15,$i)->getValue(); //Excel Column 4
                $is_new_convert       = $objWorksheet->getCellByColumnAndRow(16,$i)->getValue(); //Excel Column 4


                $member_city = (isset($city_id) && is_integer($city_id))? $city_id : $city;
                $temp = $surname.$first_name.$i.'@noemail.org';



                $data_member =[

                    'title'              => $title,
                    'surname'            => $surname,
                    'first_name'        => $first_name,
                    'gender'             => $gender,

                    'home_phone'         => $home_phone,
                    'cell_phone'         => $cell_phone,
                    'work_phone'         => $work_phone,
                    //'email_address'    => $email_address,
                    'birth_date'         => $birth_date,

                    'home_address'       => $home_address,
                    'marital_status'     => $marital_status,
                    //'fs_status'        => $fs_status,
                    'is_baptised'        => $is_baptised,


                    'first_day_in_church' =>  $first_day_in_church,
                    'prayer_request'      =>  $prayer_request,
                    //'ft_source'         =>  $ft_source,
                    'nearest_landmark'    =>  $nearest_landmark,
                    'is_new_convert'      =>  $is_new_convert,
                    'group_assigned'      =>  $tag_id,
                   // 'follow_up_by'      =>  $mem_id,

                    'church_id'  => $this->CI->input->post('church_id'),
                    'created_by' => $this->CI->input->post('created_by'),
                    'created_at' => date("Y-m-d H:i:s"),
                    'country'    => $country,
                    'state'      => $state,
                    'city'       => $member_city
                ];





                if ((isset($email_address)||isset($cell_phone)) && isset($birth_date) && isset($surname) && isset($first_name)) {

//
//                    $data_member += [
//                        'phone_kingschat'    => $phone_kingschat,
//                        'email_address'      => $email_address,
//                        'birth_date'         => $birth_date
//                    ];

                    $str = $title .' '.$first_name.' '.$surname;

                    if($this->email_exists($email_address) === FALSE){ //false means exist
                        if($email_address === NULL){
                            $up_error[$str]['email']= $temp.' '.lang('invalid_email');
                        } else {

                            $up_error[$str]['email']= $email_address.' email address is invalid';
                        }


                        $b++;

                    } else if ($this->phone_exists($cell_phone)===FALSE) {
                        if($cell_phone === NULL){
                            $up_error[$str]['phone']= $cell_phone.' was empty';
                        } else {
                            $up_error[$str]['phone']= $cell_phone.' already exists in database';
                        }

                        $b++;

                    } else if ($this->check_date($birth_date)===FALSE){
                        $up_error[$str]['birth_date'] = $birth_date.' '.lang('invalid_date_of_birth');
                        $b++;

                    } else {

                        if($email_address === NULL){

                            $data_member += ['email_address'      => $temp ];

                        } else {
                            $data_member += ['email_address'      => $email_address ];
                        }


                        $this->CI->db->insert('grow_members',$data_member);
                        $member_id = $this->CI->db->insert_id();

                        $structure = [
                            'church_id'     =>$this->CI->input->post('church_id'),
                        ];

                        $a = (int) $a + 1;

                        if($type === 'import_members'){//there must be a valid email to send a mail
                            $send = ($this->CI->input->post('send_email') == 'yes') ? TRUE: FALSE;
                            $this->CI->mail_lib->new_user($structure,$member_id,'0',$user_type ='member',$send);

                        }


//                        if($type === 'import_first_timers'){
//
//                            $data = [
//                                'member_id'           =>$member_id,
//                                'group_assigned'      =>$tag_id,
//                                'church_id'           =>$this->CI->input->post('church_id'),
//                                'created_by'          =>$this->CI->input->post('created_by'),
//                                'created_at'          =>date('Y-m-d')
//                            ];
//
//                            $this->CI->db->insert('grow_cell_members',$data);
//                        }


                    }

                } else {

                    $b++;
                }
                //dump($data_member);
                //dump($a);
            };


            //dump($up_error);
            unlink('././files/excel/'.$file_name); //File Deleted After uploading in database .
            //$path = ($this->is_admin != '1')? 'go':'church';

            $status = [];
            if(count($up_error)>0 || $totalrows > 1){
                $in = count($up_error);
                //$status['invalid'] = $in ;
                $status['invalid']     = $b ;
                $status['success']     = $a;

                $this->CI->session->set_userdata('errors',$up_error);
                $this->CI->session->set_userdata('status',$status);
            }

            redirect("$des/$type",'refresh');


        }


        else {
            $tem = ($type == 'import_members')? 'member_template.xlsx': ' ';

            $data['legend']       = $legend.' '.'<a href ="../../files/'.$tem.'" data="1" target="_blank"><i class="fa fa-download" aria-hidden="true"></i> '.lang('download_template').'</a>';
            $data['multi']        = TRUE;
            $data['title']        = ($type == 'import_members')? lang('import_members'):lang('no_file');
            $data['action']       = $action;
            $data['links']        = $links;
            $data['form_content'] = $this->CI->load->view('people/import_members',$data, TRUE);
            $data['handle']       = $this->CI->load->view('partials/blank_form',$data, TRUE);
            $this->CI->load->view('partials/master', $data);
        }
    }


}