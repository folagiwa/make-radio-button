<?php
/**
 * File       : Users_lib.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/20/18
 * Time: 1:05 PM
 */

class Mails_lib {

    protected $CI;

    public function __construct()

    {
        $this->CI =& get_instance();
        $this->CI->load->library('email');

    }



    public function new_user($full_name, $email, $web, $random){

        $data['full_name']      = $full_name;
        $data['random']         = cloud_encode($random);
        $data['web']            = $web;
        $content = $this->CI->load->view('email/new_account', $data, TRUE);

        $result = $this->CI->email
            ->from('admin@growcloud.org', 'Grow Cloud Team')
            ->reply_to('folakegiwa@loveworld360.com')    // Optional, an account where a human being reads.
            ->to($email, $full_name)
            ->subject('Welcome to Grow Cloud')
            ->message($content)
            ->send();

        return ($result) ? TRUE : FALSE;

    }

    public function welcome_user($full_name,$email){
        $data['full_name']      = $full_name;
        $data['web']            = extract_domain();
        $data['email_address']  = $email;
        $content = $this->CI->load->view('email/welcome_mail', $data, TRUE);

        $result = $this->CI->email
            ->from('admin@growcloud.org', 'Grow Cloud Team')
            ->reply_to('folakegiwa@loveworld360.com')    // Optional, an account where a human being reads.
            ->to($email, $full_name)
            ->subject('Welcome to Grow Cloud')
            ->message($content)
            ->send();

        return ($result) ? TRUE : FALSE;
    }
}