<?php
/**
 * File       : Users_lib.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/20/18
 * Time: 1:05 PM
 */

class Payment_lib {

    protected $CI;
    protected $gold_fee             = 3000000; //Premium fee in Kobo (NGN 100)
    protected $trial_span           = 2592000; //Number of seconds in 30 days
    protected $standard_span        = 3600;
    protected $paystack_key         = "sk_test_92f21b7ec661339d124b2149b093b16756674cef";
    protected $church;

    public function __construct()

    {

        $this->CI =& get_instance();

    }

    private function paystack($email, $plan){
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://api.paystack.co/transaction/initialize",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => json_encode([
                'plan'=>$plan,
                'email'=>$email
            ]),
            CURLOPT_HTTPHEADER => [
                "authorization: Bearer " . PAYSTACK_KEY, //replace this with your own test key
                "content-type: application/json",
                "cache-control: no-cache"
            ],
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        if($err){
            // there was an error contacting the Paystack API
            die('Curl returned error: ' . $err);
        }

        $tranx = json_decode($response, true);



        if(!$tranx['status']){
            // there was an error from the API
            print_r('API returned error: ' . $tranx['message']);
        }

// comment out this line if you want to redirect the user to the payment page
//        print_r($tranx);


// redirect to page so User can pay
// uncomment this line to allow the user redirect to the payment page
header('Location: ' . $tranx['data']['authorization_url']);
    }

    public function payWithPaystack($sub, $email){

        if($sub == 'standard'){
            $plan = PAYSTACK_STANDARD;
        } else if($sub == 'gold'){
            $plan = PAYSTACK_GOLD;
        }

        $_SESSION['sub_type'] = $sub;
            $this->paystack($email, $plan);
    }

    public function verifyPayment(){

        $curl = curl_init();
        $reference = isset($_GET['reference']) ? $_GET['reference'] : '';
        if(!$reference){
            die('No reference supplied');
        }

        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://api.paystack.co/transaction/verify/" . rawurlencode($reference),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                "accept: application/json",
                "authorization: Bearer " . PAYSTACK_KEY,
                "cache-control: no-cache"
            ],
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        if($err){
            // there was an error contacting the Paystack API
            die('Curl returned error: ' . $err);
        }

        $tranx = json_decode($response);

        if(!$tranx->status){
            // there was an error from the API
            die('API returned error: ' . $tranx->message);
        }

        if('success' == $tranx->data->status){

            $reference = $tranx->data->reference;
            $auth_code = $tranx->data->authorization->authorization_code;
            $paid_at = $tranx->data->paid_at;


                $ins = [
                    'authorization_code' => $auth_code,
                    'reference'             => $reference,
                    'paid_at'               => $paid_at
                ];

                $this->CI->db->where(['church_id'=>$_SESSION['church_id']]);
                $a = $this->CI->db->update('grow_churches', $ins);

                if($a){
                    $mail = $_SESSION['mail'];
                    $f = $this->CI->mails_lib->new_user($mail['name'], $mail['email'], $mail['web'], $mail['random']);
                    if($f){
                        redirect(base_url('welcome/success'));
                    }


                }


            // transaction was successful...
            // please check other things like whether you already gave value for this ref
            // if the email matches the customer who owns the product etc
            // Give value
        }
    }

    public function check_subscription(){
        $church_id  = $this->church;
        $fields     = ['church_id', 'church_name', 'church_email','subscription','reference_code','authorization_code','created_at'];

        $q          = ask_db($fields,'grow_churches',['church_id' => $church_id]);
        if($q){
            $church = $q[0];

            if($church['subscription_type'] == 'trial'){

                $stat   = $this->trial_status($church);
                if(!$stat){
                    // TODO: Redirect to payment page
                    $this->CI->load->view('partials/expired');
                }

            } else if($church['subscription_type'] == 'standard') {
                //TODO: Check premium subscription here
                $stat   = $this->standard_status($church);
                if(!$stat){
                    // TODO: Redirect to payment page
                    dump('Premium subscription expired');
                }

            }else if($church['subscription_type'] == 'gold'){
                $stat = $this->gold_status($church);
                if(!$stat){
                    //TODO: Redirect to payment page
                }
            }
        }
    }

    public function trial_status($church){
        $start      = strtotime($church['created_at']);
        $countdown  = time() - $start;

        return ($countdown >= $this->trial_span) ? FALSE : TRUE;
    }

    public function standard_status($church){
        $start      = strtotime($church['paid_at']);
        $countdown  = time() - $start;

        return ($countdown >= $this->standard_span) ? FALSE : TRUE;
    }

    public function gold_status($church){
        $start      = strtotime($church['paid_at']);
        $countdown  = time() - $start;

        return ($countdown >= $this->gold_fee) ? FALSE : TRUE;
    }



}