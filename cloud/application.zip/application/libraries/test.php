<?php
/**
 * File       : test
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/21/18
 * Time: 11:26 AM
 */
?>


<!DOCTYPE html>
<html>
<head>
    <title>Grow :: First Timer :: Add New record</title>


    <style>
        /* Displays the map drop down suggestions for location maps */
        .pac-container {
    z-index: 999999;
        }
    </style>



        <link href="https://loveworldims.org/assets/css/application_t.min.css" rel="stylesheet">
<!--    <link href="--><?//=$path;?><!--css/themes/bg.css" rel="stylesheet">-->
    <link href="https://loveworldims.org/assets/css/scopes/zone.css" rel="stylesheet">

    <link href="https://loveworldims.org/assets/css/speech.css" rel="stylesheet">


    <link rel="shortcut icon" href="img/favicon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="New generation church management software">
    <meta name="author" content="Internet Multimedia">




    <script src="https://loveworldims.org/assets/lib/jquery/dist/jquery.min.js"></script>
    <script src="https://loveworldims.org/assets/lib/jquery-pjax/jquery.pjax.js"></script>
    <script src="https://loveworldims.org/assets/lib/bootstrap-sass/assets/javascripts/bootstrap.min.js"></script>
    <script src="https://loveworldims.org/assets/lib/widgster/widgster.js"></script>
    <script src="https://loveworldims.org/assets/lib/underscore/underscore.js"></script>

    <script src="https://loveworldims.org/assets/js/app.js"></script>
    <script src="https://loveworldims.org/assets/js/settings.js"></script>



    <meta charset="utf-8">
    <script>
        /* yeah we need this empty stylesheet here. It's cool chrome & chromium fix
         chrome fix https://code.google.com/p/chromium/issues/detail?id=167083
         https://code.google.com/p/chromium/issues/detail?id=332189
         */

    </script>







</head>
<body>
<div class="logo">

    <img src="https://loveworldims.org/assets/img/logo_grow.png">
</div>


<nav id="sidebar" class="sidebar nav-collapse collapse">

    <ul id="side-nav" class="side-nav">

        <li class="">
            <a href="https://loveworldims.org/church/dashboard"><i class="fa fa-home"></i> <span class="name">Dashboard</span></a>
        </li>

        <li class="panel"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#side-nav" href="#Growth_trend"><i class="fa fa-area-chart"></i>Growth trend</a>
<ul id = "Growth_trend"class="panel-collapse collapse ">
<li><a href="https://loveworldims.org/church/growth_trend/attendance">Attendance</a></li>
<li><a href="https://loveworldims.org/church/growth_trend/first_timers">First Timers</a></li>

</ul></li>
<li class="panel"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#side-nav" href="#Organization"><i class="fa fa-cube"></i>Organization</a>
<ul id = "Organization"class="panel-collapse collapse ">
<li><a href="https://loveworldims.org/church/organization/churches">Churches</a></li>
<li><a href="https://loveworldims.org/church/organization/new_church">Create a new church</a></li>
<li><a href="https://loveworldims.org/church/organization/group_profile">Group profile</a></li>
<li><a href="https://loveworldims.org/church/organization/groups">Groups</a></li>
<li><a href="https://loveworldims.org/church/organization/new_group">Create a new group</a></li>
<li><a href="https://loveworldims.org/church/organization/create_admin">Assign a new admin</a></li>
<li><a href="https://loveworldims.org/church/organization/new_teens_church">New Teens Church</a></li>
<li><a href="https://loveworldims.org/church/organization/new_childrens_church">New Children's Church</a></li>
<li><a href="https://loveworldims.org/church/organization/new_outreach_fellowship">New Outreach Fellowship</a></li>
<li><a href="https://loveworldims.org/church/organization/system_usage">System Usage</a></li>
<li><a href="https://loveworldims.org/church/organization/new_youth_church"></a></li>

</ul></li>
<li class="panel"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#side-nav" href="#Service_Report"><i class="fa fa-bar-chart"></i>Service Report</a>
<ul id = "Service_Report"class="panel-collapse collapse ">
<li><a href="https://loveworldims.org/church/service_report/submit_service_report">Submit Service Report</a></li>
<li><a href="https://loveworldims.org/church/service_report/service_reports">Service reports</a></li>
<li><a href="https://loveworldims.org/church/service_report/reports_pending">Reports Pending</a></li>

</ul></li>
<li class="panel"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#side-nav" href="#Finance"><i class="fa fa-money"></i>Finance</a>
<ul id = "Finance"class="panel-collapse collapse ">
<li><a href="https://loveworldims.org/church/finance/new_inflow">New inflow</a></li>
<li><a href="https://loveworldims.org/church/finance/new_outflow">New outflow</a></li>
<li><a href="https://loveworldims.org/church/finance/txn">Transactions</a></li>
<li><a href="https://loveworldims.org/church/finance/reports">Reports</a></li>

</ul></li>
<li class="panel"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#side-nav" href="#Ministry_materials"><i class="fa fa-play"></i>Ministry materials</a>
<ul id = "Ministry_materials"class="panel-collapse collapse ">
<li><a href="https://loveworldims.org/church/ministry_materials/orders">Orders</a></li>
<li><a href="https://loveworldims.org/church/ministry_materials/sales">Sales</a></li>
<li><a href="https://loveworldims.org/church/ministry_materials/reports">Reports</a></li>

</ul></li>
<li class="panel"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#side-nav" href="#First_Timers"><i class="fa fa-user-plus"></i>First Timers</a>
<ul id = "First_Timers"class="panel-collapse collapse ">
<li><a href="https://loveworldims.org/church/first_timers/add_first_timer">New First timer</a></li>
<li><a href="https://loveworldims.org/church/first_timers/first_timers">First Timers</a></li>
<li><a href="https://loveworldims.org/church/first_timers/prayer_request">Prayer request</a></li>
<li><a href="https://loveworldims.org/church/first_timers/new_follow_up_report">New follow up report</a></li>
<li><a href="https://loveworldims.org/church/first_timers/follow_up_report">Follow up report</a></li>
<li><a href="https://loveworldims.org/church/first_timers/first_timer_reports">First Timer Reports</a></li>
<li><a href="https://loveworldims.org/church/first_timers/new_first_timer_admin">New first timer admin</a></li>
<li><a href="https://loveworldims.org/church/first_timers/import_first_timers">Import First Timers</a></li>

</ul></li>
<li class="panel"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#side-nav" href="#Cell_Ministry"><i class="fa fa-th"></i>Cell Ministry</a>
<ul id = "Cell_Ministry"class="panel-collapse collapse ">
<li><a href="https://loveworldims.org/church/cell_ministry/cells">Cells</a></li>
<li><a href="https://loveworldims.org/church/cell_ministry/create_a_cell">Create a cell</a></li>
<li><a href="https://loveworldims.org/church/cell_ministry/senior_cells">Senior Cells</a></li>
<li><a href="https://loveworldims.org/church/cell_ministry/new_senior_cell">Create a new senior cell</a></li>
<li><a href="https://loveworldims.org/church/cell_ministry/pcfs">PCFs</a></li>
<li><a href="https://loveworldims.org/church/cell_ministry/new_pcf">Create New PCF</a></li>
<li><a href="https://loveworldims.org/church/cell_ministry/soul_winners">Soul winners</a></li>
<li><a href="https://loveworldims.org/church/cell_ministry/submit_cell_report">Submit cell report</a></li>
<li><a href="https://loveworldims.org/church/cell_ministry/cell_reports">Cell Reports</a></li>
<li><a href="https://loveworldims.org/church/cell_ministry/cell_outline">Cell Outlines</a></li>
<li><a href="https://loveworldims.org/church/cell_ministry/new_cell_outline">Upload cell outline</a></li>
<li><a href="https://loveworldims.org/church/cell_ministry/report_summary">Report Summary</a></li>
<li><a href="https://loveworldims.org/church/cell_ministry/new_pfcc_admin">New PFCC admin</a></li>
<li><a href="https://loveworldims.org/church/cell_ministry/new_bsc">New Bible Study Class</a></li>
<li><a href="https://loveworldims.org/church/cell_ministry/bscs">Bible Study Classes</a></li>

</ul></li>
<li class="panel"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#side-nav" href="#Foundation_School"><i class="fa fa-graduation-cap"></i>Foundation School</a>
<ul id = "Foundation_School"class="panel-collapse collapse ">
<li><a href="https://loveworldims.org/church/foundation_school/mark_fs_register">Mark foundation school register</a></li>
<li><a href="https://loveworldims.org/church/foundation_school/fs_class_history">Class History</a></li>
<li><a href="https://loveworldims.org/church/foundation_school/awaiting_graduation">Awaiting graduation</a></li>
<li><a href="https://loveworldims.org/church/foundation_school/new_fs_admin">New foundation school admin</a></li>
<li><a href="https://loveworldims.org/church/foundation_school/fs_report">Foundation school report</a></li>
<li><a href="https://loveworldims.org/church/foundation_school/enrolled_students">Enrolled Students</a></li>

</ul></li>
<li class="panel"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#side-nav" href="#Members"><i class="fa fa-pagelines"></i>Members</a>
<ul id = "Members"class="panel-collapse collapse ">
<li><a href="https://loveworldims.org/church/members/new_member">Add a member</a></li>
<li><a href="https://loveworldims.org/church/members/members">Members</a></li>
<li><a href="https://loveworldims.org/church/members/birthdays">Birthdays</a></li>
<li><a href="https://loveworldims.org/church/members/leaders">Leaders</a></li>
<li><a href="https://loveworldims.org/church/members/import_members">Import Members</a></li>
<li><a href="https://loveworldims.org/church/members/distribution_by_city">Distribution by City</a></li>
<li><a href="https://loveworldims.org/church/members/search_member">Search Member</a></li>

</ul></li>
<li class="panel"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#side-nav" href="#Partnership"><i class="fa fa-money"></i>Partnership</a>
<ul id = "Partnership"class="panel-collapse collapse ">
<li><a href="https://loveworldims.org/church/partnership/new_partnership_record">Add partnership record</a></li>
<li><a href="https://loveworldims.org/church/partnership/partnership_records">Partnership records</a></li>
<li><a href="https://loveworldims.org/church/partnership/new_partnership_pledge">Add partnership pledge</a></li>
<li><a href="https://loveworldims.org/church/partnership/partnership_pledges">Partnership pledges</a></li>
<li><a href="https://loveworldims.org/church/partnership/new_partnership_admin">Add partnership admin</a></li>
<li><a href="https://loveworldims.org/church/partnership/partnership_admins">Partnership admins</a></li>
<li><a href="https://loveworldims.org/church/partnership/consistent_partners">Consistent Partners</a></li>
<li><a href="https://loveworldims.org/church/partnership/not_partnering">Members yet to partner</a></li>
<li><a href="https://loveworldims.org/church/partnership/partnership_reports">Partnership reports</a></li>
<li><a href="https://loveworldims.org/church/partnership/top_partners">Top partners</a></li>

</ul></li>
<li class="panel"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#side-nav" href="#Local_Projects"><i class="fa fa-credit-card"></i>Local Projects</a>
<ul id = "Local_Projects"class="panel-collapse collapse ">
<li><a href="https://loveworldims.org/church/giving/records">Records</a></li>
<li><a href="https://loveworldims.org/church/giving/new_record">Add New record</a></li>
<li><a href="https://loveworldims.org/church/giving/new_giving_category">Create New giving category</a></li>
<li><a href="https://loveworldims.org/church/giving/not_giving">Members yet to give</a></li>
<li><a href="https://loveworldims.org/church/giving/consistent_givers">Consistent givers</a></li>
<li><a href="https://loveworldims.org/church/giving/giving_reports">Giving Reports</a></li>

</ul></li>
<li class="panel"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#side-nav" href="#Messaging"><i class="fa fa-clipboard"></i>Messaging</a>
<ul id = "Messaging"class="panel-collapse collapse ">
<li><a href="https://loveworldims.org/church/messaging/send_email">Send email</a></li>

</ul></li>
<li class="panel"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#side-nav" href="#Outreach"><i class="fa fa-bullhorn"></i>Outreach</a>
<ul id = "Outreach"class="panel-collapse collapse ">
<li><a href="https://loveworldims.org/church/outreach/new_event">Schedule an Event</a></li>
<li><a href="https://loveworldims.org/church/outreach/all_events">All Events</a></li>
<li><a href="https://loveworldims.org/church/outreach/manage_souls">Manage Souls</a></li>
<li><a href="https://loveworldims.org/church/outreach/new_contact">Add a soul</a></li>
<li><a href="https://loveworldims.org/church/outreach/import_souls">Import Souls</a></li>
<li><a href="https://loveworldims.org/church/outreach/email_contacts">Email contacts</a></li>

</ul></li>
<li class="panel"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#side-nav" href="#Profile"><i class="fa fa-suitcase"></i>Profile</a>
<ul id = "Profile"class="panel-collapse collapse ">
<li><a href="https://loveworldims.org/church/profile/my_profile">My profile</a></li>
<li><a href="https://loveworldims.org/church/profile/edit_profile">Edit Profile</a></li>

</ul></li>
<li class="panel"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#side-nav" href="#Location"><i class="fa fa-map-marker"></i>Location</a>
<ul id = "Location"class="panel-collapse collapse ">
<li><a href="https://loveworldims.org/church/location/add_new_country">Add a Country</a></li>
<li><a href="https://loveworldims.org/church/location/new_state">Add a state</a></li>
<li><a href="https://loveworldims.org/church/location/new_city">Add a city</a></li>

</ul></li>
<li class="panel"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#side-nav" href="#List_of_Accounts"><i class="fa fa-user"></i>List of Accounts</a>
<ul id = "List_of_Accounts"class="panel-collapse collapse ">
<li><a href="https://loveworldims.org/church/accounts/preferences">Set your preferences</a></li>
<li><a href="https://loveworldims.org/church/accounts/grant_privilege">Grant privilege</a></li>
<li><a href="https://loveworldims.org/church/accounts/users">Users</a></li>

</ul></li>


        <li class="">
            <a href="https://loveworldims.org/Grow/logout"><i class="fa fa-sign-out"></i> <span class="name">Sign out</span></a>
        </li>

    </ul>


   <!---->
<!--<h5 class="sidebar-nav-title">Vision 400</h5>-->
<!--<!-- A place for sidebar notifications & alerts -->
<!--<div class="sidebar-alerts">-->
<!--    <div class="alert fade in">-->
<!--        <a href="#" class="close" data-dismiss="alert" aria-hidden="true">&times;</a>-->
<!--        <span class="text-white fw-semi-bold">Attendance target </span> <br>-->
<!--        <div class="progress progress-xs mt-xs mb-0">-->
<!--            <div class="progress-bar progress-bar-gray-light" style="width: 36%"></div>-->
<!--        </div>-->
<!--        <small>Progress so far ...35%</small>-->
<!--    </div>-->
<!--    <div class="alert fade in">-->
<!--        <a href="#" class="close" data-dismiss="alert" aria-hidden="true">&times;</a>-->
<!--        <span class="text-white fw-semi-bold">Personal targets</span> <br>-->
<!--        <div class="progress progress-xs mt-xs mb-0">-->
<!--            <div class="progress-bar progress-bar-danger" style="width: 23%"></div>-->
<!--        </div>-->
<!--        <small>Completed ...23%</small>-->
<!--    </div>-->
<!---->
<!--</div>-->


</nav>




<div class="wrap">
    <header class="page-header">
        <div class="navbar">
            <ul class="nav navbar-nav navbar-right pull-right">
                <li class="visible-phone-landscape">
                    <a href="#" id="search-toggle">
                        <i class="fa fa-th"></i>
                    </a>
                </li>
                <li class="divider"></li>
                <li class="hidden-xs">
                    <a href="https://loveworldims.org/church/members/follow_up_list" id="settings"
                       title="Settings"
                       data-toggle="popover"
                       data-placement="bottom">
                        <i class="fa fa-users text-white"></i>
                    </a>
                </li>
                
                <li class="hidden-xs">
                    <a href="https://loveworldims.org/church/accounts/feedback" id="settings"
                       title="Settings"
                       data-toggle="popover"
                       data-placement="bottom">
                        <i class="fa fa-comments text-white"></i>
                    </a>
                </li>
                <li class="hidden-xs">
                    <a href="https://loveworldims.org/church/accounts/preferences" id="settings"
                       title="Settings"
                       data-toggle="popover"
                       data-placement="bottom">
                        <i class="glyphicon glyphicon-cog text-white"></i>
                    </a>
                </li>
                <li class="hidden-xs dropdown">
                    <a href="#" title="Account" id="account"
                       class="dropdown-toggle"
                       data-toggle="dropdown">
                        <i class="glyphicon glyphicon-user text-white"></i>
                    </a>
                    <ul id="account-menu" class="dropdown-menu account" role="menu">
                        <li role="presentation" class="account-picture">
                            Pastor Ofunne Segun Samuel                        </li>
                        <li role="presentation">
                            <a href="https://loveworldims.org/church/profile/edit_profile" class="link">
                                <i class="fa fa-user"></i>
                                Edit Profile                            </a>
                        </li>
                        <li role="presentation">
                            <a href="https://loveworldims.org/church/finance/my_partnership" class="link">
                                <i class="fa fa-money"></i>
                               My partnership                            </a>
                        </li>
                        <li role="presentation">
                            <a href="https://loveworldims.org/church/finance/my_giving" class="link">
                                <i class="fa fa-credit-card"></i>
                                My giving                            </a>
                        </li>
                        <li role="presentation">
                            <a href="https://loveworldims.org/church/accounts/reset_password" class="link">
                                <i class="fa fa-key"></i>
                                Change password                            </a>
                        </li>
                    </ul>
                </li>
                <li class="visible-xs">
                    <a href="#"
                       class="btn-navbar"
                       data-toggle="collapse"
                       data-target=".sidebar"
                       title="">
                        <i class="fa fa-bars text-primary"></i>
                    </a>
                </li>
                <li class="hidden-xs"><a href="https://loveworldims.org/Grow/logout"><i class="glyphicon glyphicon-off text-white"></i></a></li>
            </ul>
            <div class="navbar-form pull-right">
               <select id="language" class="selectpicker" data-style="btn-danger btn-sm" data-width="auto" tabindex="1" id="simple-green-select"><option selected="selected"value= "en">EN</option><option value= "fr">FR</option><option value= "zh">ZH</option><option value= "es">ES</option></select>
            </div>

            <form id="search-form" class="navbar-form pull-right " role="search" action="https://loveworldims.org/command/speech" method="post">
                <input type="text" id="command" name ="command" class="speech-input form-control input-transparent" lang="en" placeholder="Command" value="" data-buttonsize="25" data-instant-submit>
                <input type="hidden" name="ex_uri" value="church/first_timers/add_first_timer">

                <script src="https://loveworldims.org/assets/js/speech.js"></script>


            </form>


            <div class="notifications pull-right">
                <div class="alert pull-right">
                    <a href="#" class="close ml-xs" data-dismiss="alert">&times;</a>
                    <i class="fa fa-info-circle mr-xs"></i> You're logged in as<a id="notification-link" href="#"> Pastor Ofunne Segun Samuel</a>!
                </div>
            </div>
        </div>
    </header>
    <script async defer src="https://buttons.github.io/buttons.js"></script>
    <script type="application/javascript">

    $('#language').on('change',function(){
        var lang_id = $(this).val();
        if(lang_id){
            $.ajax({
                    type:'POST',
                    url:"https://loveworldims.org/grow/set_lang",
                    data:'language='+lang_id,
                    success:function(html){
                $('#language').html(html);
                location.reload();
            }
                });
            }
    });
    </script>



<div class="content container">
    <h2 class="page-title">First Timer :: Add New record</span>
        <!--        <small>--><!--</small></h2>-->
        <small class="mt-lg"><ul class="breadcrumb"><li><a href="https://loveworldims.org/church/dashboard">Home</a> <span class="divider"> :: </span></li><li><a href="https://loveworldims.org/church/first_timers">First Timers</a> <span class="divider"> :: </span></li><li class="active">New First timer</li></ul>
</small></h2>
        <div class="row">
            <div class="col-md-7">
                <section class="widget">

                    <div class="body">
                        <form action="https://loveworldims.org/church/first_timers/add_first_timer" class="form-horizontal form-label-left" id="user-form" enctype="multipart/form-data" method="post" accept-charset="utf-8">


            <fieldset>
    <legend class="section">Fill the form to create or update a record. All fields marked * are required. You can enter 0 where field is empty </legend>
                    <script type="text/javascript" src='https://maps.google.com/maps/api/js?key=AIzaSyC1QVdvtqDYqew8Csoi4VGAynhRYUqtr3E&libraries=places'></script>

<script src="https://loveworldims.org/assets/js/locationpicker.jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
<style>
    .select2-container--open .select2-dropdown--below,
    .select2-container--open .select2-dropdown--above{

    color:black;
}
    /* Make Select2 boxes match Bootstrap3 heights: */
    .select2-selection__rendered {
    line-height: 32px !important;
    }

    .select2-selection {
    height: 34px !important;
    }

</style>



<div style="display: none"><div><input name = "member_id" type="hidden"value="""><input type="hidden" name="member_id" value="" class="form-control input-transparent" id="member_id"  />
<br/></div></div><div class="form-group"><label class="control-label col-sm-4" for="country_id">Country<span class="required">*</span></label><div class="col-sm-8"><select id="country_id" data-placeholder="Select" required="required" class="select2 form-control" name="country"><option value="">Select Country</option><option value = "1">Afghanistan</option><option value = "2">Albania</option><option value = "3">Algeria</option><option value = "4">American Samoa</option><option value = "5">Andorra</option><option value = "6">Angola</option><option value = "7">Anguilla</option><option value = "8">Antarctica</option><option value = "10">Argentina</option><option value = "11">Armenia</option><option value = "12">Aruba</option><option value = "13">Australia</option><option value = "14">Austria</option><option value = "15">Azerbaijan</option><option value = "17">Bahrain</option><option value = "18">Bangladesh</option><option value = "19">Barbados</option><option value = "20">Belarus</option><option value = "21">Belgium</option><option value = "22">Belize</option><option value = "23">Benin</option><option value = "24">Bermuda</option><option value = "25">Bhutan</option><option value = "26">Bolivia</option><option value = "28">Botswana</option><option value = "29">Bouvet Island</option><option value = "30">Brazil</option><option value = "31">British Indian Ocean Territory</option><option value = "33">Bulgaria</option><option value = "34">Burkina Faso</option><option value = "35">Burundi</option><option value = "36">Cambodia</option><option value = "37">Cameroon</option><option value = "38">Canada</option><option value = "39">Cape Verde</option><option value = "40">Cayman Islands</option><option value = "41">Central African Republic</option><option value = "42">Chad</option><option value = "43">Chile</option><option value = "44">China</option><option value = "45">Christmas Island</option><option value = "46">Cocos (Keeling) Islands</option><option value = "47">Colombia</option><option value = "48">Comoros</option><option value = "49">Congo</option><option value = "51">Cook Islands</option><option value = "52">Costa Rica</option><option value = "55">Cuba</option><option value = "56">Cyprus</option><option value = "58">Denmark</option><option value = "59">Djibouti</option><option value = "60">Dominica</option><option value = "61">Dominican Republic</option><option value = "62">East Timor</option><option value = "63">Ecuador</option><option value = "64">Egypt</option><option value = "65">El Salvador</option><option value = "66">Equatorial Guinea</option><option value = "67">Eritrea</option><option value = "68">Estonia</option><option value = "69">Ethiopia</option><option value = "70">External Territories of Australia</option><option value = "72">Faroe Islands</option><option value = "74">Finland</option><option value = "75">France</option><option value = "76">French Guiana</option><option value = "77">French Polynesia</option><option value = "78">French Southern Territories</option><option value = "79">Gabon</option><option value = "81">Georgia</option><option value = "82">Germany</option><option value = "83">Ghana</option><option value = "84">Gibraltar</option><option value = "85">Greece</option><option value = "86">Greenland</option><option value = "87">Grenada</option><option value = "89">Guam (USA)</option><option value = "90">Guatemala</option><option value = "91">Guernsey and Alderney</option><option value = "92">Guinea</option><option value = "93">Guinea-Bissau</option><option value = "94">Guyana</option><option value = "95">Haiti</option><option value = "96">Heard Island and McDonald Islands</option><option value = "97">Honduras</option><option value = "98">Hong Kong</option><option value = "99">Hungary</option><option value = "100">Iceland</option><option value = "101">India</option><option value = "102">Indonesia</option><option value = "103">Iran</option><option value = "104">Iraq</option><option value = "105">Ireland</option><option value = "106">Israel</option><option value = "107">Italy</option><option value = "108">Jamaica</option><option value = "109">Japan</option><option value = "110">Jersey</option><option value = "111">Jordan</option><option value = "112">Kazakhstan</option><option value = "113">Kenya</option><option value = "114">Kiribati</option><option value = "115">Korea North</option><option value = "116">Korea South</option><option value = "117">Kuwait</option><option value = "118">Kyrgyzstan</option><option value = "119">Laos</option><option value = "120">Latvia</option><option value = "121">Lebanon</option><option value = "122">Lesotho</option><option value = "123">Liberia</option><option value = "124">Libya</option><option value = "125">Liechtenstein</option><option value = "126">Lithuania</option><option value = "127">Luxembourg</option><option value = "128">Macau</option><option value = "129">Macedonia</option><option value = "130">Madagascar</option><option value = "131">Malawi</option><option value = "132">Malaysia</option><option value = "133">Maldives</option><option value = "134">Mali</option><option value = "135">Malta</option><option value = "136">Isle of Man</option><option value = "137">Marshall Islands</option><option value = "138">Martinique</option><option value = "139">Mauritania</option><option value = "140">Mauritius</option><option value = "141">Mayotte</option><option value = "142">Mexico</option><option value = "143">Micronesia</option><option value = "144">Moldova</option><option value = "145">Monaco</option><option value = "146">Mongolia</option><option value = "147">Montserrat</option><option value = "148">Morocco</option><option value = "149">Mozambique</option><option value = "150">Myanmar</option><option value = "151">Namibia</option><option value = "152">Nauru</option><option value = "153">Nepal</option><option value = "154">Netherlands Antilles</option><option value = "155">The Netherlands</option><option value = "156">New Caledonia</option><option value = "157">New Zealand</option><option value = "158">Nicaragua</option><option value = "159">Niger</option><option value = "160" selected="selected">Nigeria</option><option value = "161">Niue</option><option value = "162">Norfolk Island</option><option value = "163">Northern Mariana Islands</option><option value = "164">Norway</option><option value = "165">Oman</option><option value = "166">Pakistan</option><option value = "167">Palau</option><option value = "168">Palestinian Territories</option><option value = "169">Panama</option><option value = "170">Papua New Guinea</option><option value = "171">Paraguay</option><option value = "172">Peru</option><option value = "173">Philippines</option><option value = "174">Pitcairn Island</option><option value = "175">Poland</option><option value = "176">Portugal</option><option value = "177">Puerto Rico</option><option value = "178">Qatar</option><option value = "179">Reunion</option><option value = "180">Romania</option><option value = "181">Russia</option><option value = "182">Rwanda</option><option value = "183">Saint Helena</option><option value = "184">Saint Kitts And Nevis</option><option value = "185">Saint Lucia</option><option value = "186">Saint Pierre and Miquelon</option><option value = "187">Saint Vincent And The Grenadines</option><option value = "188">Samoa</option><option value = "189">San Marino</option><option value = "190">Sao Tome and Principe</option><option value = "191">Saudi Arabia</option><option value = "192">Senegal</option><option value = "193">Serbia</option><option value = "194">Seychelles</option><option value = "195">Sierra Leone</option><option value = "196">Singapore</option><option value = "197">Slovakia</option><option value = "198">Slovenia</option><option value = "199">Smaller Territories of the UK</option><option value = "200">Solomon Islands</option><option value = "201">Somalia</option><option value = "202">South Africa</option><option value = "203">South Georgia Island</option><option value = "204">South Sudan</option><option value = "205">Spain</option><option value = "206">Sri Lanka</option><option value = "207">Sudan</option><option value = "208">Suriname</option><option value = "209">Svalbard And Jan Mayen Islands</option><option value = "210">Swaziland</option><option value = "211">Sweden</option><option value = "212">Switzerland</option><option value = "213">Syria</option><option value = "214">Taiwan</option><option value = "215">Tajikistan</option><option value = "216">Tanzania</option><option value = "217">Thailand</option><option value = "218">Togo</option><option value = "219">Tokelau</option><option value = "220">Tonga</option><option value = "221">Trinidad And Tobago</option><option value = "222">Tunisia</option><option value = "223">Turkey</option><option value = "224">Turkmenistan</option><option value = "225">Turks And Caicos Islands</option><option value = "226">Tuvalu</option><option value = "227">Uganda</option><option value = "228">Ukraine</option><option value = "229">United Arab Emirates</option><option value = "230">United Kingdom</option><option value = "231">United States Of America</option><option value = "232">United States Minor Outlying Islands</option><option value = "233">Uruguay</option><option value = "234">Uzbekistan</option><option value = "235">Vanuatu</option><option value = "236">Vatican City State (Holy See)</option><option value = "237">Venezuela</option><option value = "238">Vietnam</option><option value = "239">Virgin Islands (British)</option><option value = "240">Virgin Islands (USA)</option><option value = "241">Wallis And Futuna Islands</option><option value = "242">Western Sahara</option><option value = "243">Yemen</option><option value = "244">Bosnia And Herzegovina</option><option value = "245">Zambia</option><option value = "246">Zimbabwe</option><option value = "247">West Indies</option><option value = "248">Curacao</option></select></div></div><div class="form-group"><label class="control-label col-sm-4" for="state_id">State<span class="required">*</span></label><div class="col-sm-8"><select id="state_id" data-placeholder="Select" required="required" class="select2 form-control" name="state"><option value="">Select State</option><option value = "2647">Abia</option><option value = "2648">Abuja FCT</option><option value = "2649">Adamawa</option><option value = "2650">Akwa Ibom</option><option value = "2651">Anambra</option><option value = "2652">Bauchi</option><option value = "2653">Bayelsa</option><option value = "2654">Benue</option><option value = "2655">Borno</option><option value = "2656">Cross River</option><option value = "2657">Delta</option><option value = "2658">Ebonyi</option><option value = "2659">Edo</option><option value = "2660">Ekiti</option><option value = "2661">Enugu</option><option value = "2662">Gombe</option><option value = "2663">Imo</option><option value = "2664">Jigawa</option><option value = "2665">Kaduna</option><option value = "2666">Kano</option><option value = "2667">Katsina</option><option value = "2668">Kebbi</option><option value = "2669">Kogi</option><option value = "2670">Kwara</option><option value = "2671" selected="selected">Lagos</option><option value = "2672">Nassarawa</option><option value = "2673">Niger</option><option value = "2674">Ogun</option><option value = "2675">Ondo</option><option value = "2676">Osun</option><option value = "2677">Oyo</option><option value = "2678">Plateau</option><option value = "2679">Rivers</option><option value = "2680">Sokoto</option><option value = "2681">Taraba</option><option value = "2682">Yobe</option><option value = "2683">Zamfara</option></select></div></div><div class="form-group"><label class="control-label col-sm-4" for="city_id">City/ Town/ Village<span class="required">*</span><span class="help-block"><a href="https://loveworldims.org/church/location/new_city">Add your city if it is not available</a></span></label><div class="col-sm-8"><select id="city_id" data-placeholder="Select" required="required" class="select2 form-control" name="city"><option value="">Select City/ Town/ Village</option><option value = "30978">Apapa</option><option value = "30979">Badagri</option><option value = "30980">Epe</option><option value = "30981">Ibeju</option><option value = "30982">Iganmi</option><option value = "30983">Ikeja</option><option value = "30984">Ikorodu</option><option value = "30985">Lagos</option><option value = "30986">Ojo</option><option value = "30987">Surulere</option><option value = "47579">Ojota</option><option value = "47580">Berger</option><option value = "47581">Oregun</option><option value = "47582">ogba</option><option value = "47583">Ojodu</option><option value = "47584">Olowora</option><option value = "47585">Yaba</option><option value = "47586">Ibafo</option><option value = "47587">Ibeju - Lekki</option><option value = "47588">Alausa</option><option value = "47589">Aguda - Ogba</option><option value = "47590">Surulere</option><option value = "47591">Iju - Ishaga</option><option value = "47592">Ikorodu</option><option value = "47593">Amuwo - Odofin</option><option value = "47594">Aguda - Surulere</option><option value = "47595">Mushin</option><option value = "47596">Ojo</option><option value = "47597">Badagry</option><option value = "47598">Ojokoro</option><option value = "47599">Oshodi</option><option value = "47600">Agbado</option><option value = "47601">Apapa</option><option value = "47602">Lekki</option><option value = "47603">Bariga</option><option value = "47604">Victoria Island</option><option value = "47605">Isheri</option><option value = "47606">Somolu</option><option value = "47607">Ikoyi</option><option value = "47608">Epe</option><option value = "47609">Dopemu</option><option value = "47610">Anthony Village</option><option value = "47611">Magodo</option><option value = "47612">Maryland</option><option value = "47613">Mile 12</option><option value = "47614">Obalende</option><option value = "47615">Oke - Ira</option><option value = "47616">Palm groove</option><option value = "47617">Shangisha</option><option value = "47618">Sabo - Alagbole</option><option value = "47619">Omole Phase 1</option><option value = "47620">Oworonshoki</option><option value = "47621">Ajah</option><option value = "47622">Egbeda</option><option value = "47623">Agege</option><option value = "47624">Pen Cinema</option><option value = "47625">Open</option><option value = "47626">Opebi</option><option value = "47627">Sango</option><option value = "47628">Ota</option><option value = "47629">Allen Avenue</option><option value = "47630">Adeniyi Jones</option><option value = "47631">Agidingbi</option><option value = "47632">Abule Egba</option><option value = "47633">Iyana Ipaja</option><option value = "47634">Ipaja</option><option value = "47635">Ketu</option><option value = "47636">Alapere</option><option value = "47637">Mile 2</option><option value = "47638">College Road</option><option value = "47639">Gbagada</option><option value = "47640">Ikosi</option><option value = "47641">Ikotun</option><option value = "47642">Mowe</option><option value = "47643">Haruna</option><option value = "47644">Festac Town</option><option value = "47646">MOWE</option><option value = "47647">Ifako-Ijaiye</option><option value = "47648">Isolo</option><option value = "47650">Afromedia</option><option value = "47651">Iba Ijanikin</option><option value = "47652">Ajegunle</option><option value = "47653">Egbe</option><option value = "47654">Ijedodo</option><option value = "47655">Ijagemo</option><option value = "47656">Isheri Osun</option><option value = "47657">Isheri olofin</option><option value = "47659">FAGBILE/IJEGUN</option><option value = "47661">Ipaja</option><option value = "47662">Igando</option><option value = "47663">Igando</option><option value = "47721">Ikeja</option><option value = "47724">Agbado-Ijaiye</option></select></div></div><div class="form-group"><label class="control-label col-sm-4" for="val">Title<span class="required">*</span></label><div class="col-sm-8"><select id="val" data-placeholder="Select" required="required" class="select2 form-control" name="title"><option value="">Select Title</option><option value = "Rev">Reverend</option><option value = "Pastor">Pastor</option><option value = "Deacon">Deacon</option><option value = "Deaconess">Deaconess</option><option value = "Brother">Brother</option><option value = "Sister">Sister</option><option value = "Elder">Elder</option><option value = "Evangelist">Evangelist</option></select></div></div><div class="form-group"><label class="control-label col-sm-4"for="surname">Surname<span class="required">*</span></label><div class="col-sm-8"><input type="text" name="surname" value="" label="Surname" class="form-control input-transparent" id="surname" required="required"  />
<br/></div></div><div class="form-group"><label class="control-label col-sm-4"for="other_names">Othername<span class="required">*</span></label><div class="col-sm-8"><input type="text" name="other_names" value="" label="Othername" class="form-control input-transparent" id="other_names" required="required"  />
<br/></div></div><div class="form-group"><label class="control-label col-sm-4"for="birth_date">Date of birth<span class="required">*</span></label><div class="col-sm-8"><input type="text" name="birth_date" value="" label="Date of birth" class="form-control input-transparent date-picker" id="birth_date" required="required"  />
<br/></div></div><div class="row"><div class="form-group col-sm-9"><div class="control-label col-sm-6">Gender</div><div class="radio col-sm-6"><div class="col-sm-12"><input type="radio"  name="gender" id="gender" value="male">  <label for="gender">Male</label></div><div class="col-sm-12"><input type="radio"  name="gender" id="gender" value="female">  <label for="gender">Female</label></div></div></div></div><div class="form-group"><label class="control-label col-sm-4" for="val">Marital status<span class="required">*</span></label><div class="col-sm-8"><select id="val" data-placeholder="Select" required="required" class="select2 form-control" name="marital_status"><option value="">Select Marital status</option><option value = "single">Single</option><option value = "married">Married</option><option value = "widowed">Widowed</option></select></div></div><div class="form-group"><label class="control-label col-sm-4"for="mask-int-phone">Kingschat/Mobile number<span class="required">*</span><span class="help-block">Enter mobile number if not yet on kingschat. If Juvinile, enter guardian phone</span></label><div class="col-sm-8"><input type="text" name="phone_kingschat" value="" id="mask-int-phone" label="Kingschat/Mobile number" class="form-control input-transparent" required="required" hint="Enter mobile number if not yet on kingschat. If Juvinile, enter guardian phone"  />
<br/></div></div><div class="form-group"><label class="control-label col-sm-4"for="email_address">Email address<span class="required">*</span></label><div class="col-sm-8"><input type="text" name="email_address" value="" label="Email address" class="form-control input-transparent" id="email_address" required="required"  />
<br/></div></div><div class="form-group"><label class="control-label col-sm-4" for="val">Foundation school<span class="required">*</span></label><div class="col-sm-8"><select id="val" data-placeholder="Select" required="required" class="select2 form-control" name="fs_status"><option value="">Select Foundation school</option><option value = "pending">Pending</option><option value = "enrolled">Enrolled</option><option value = "graduated">Graduated</option></select></div></div><div class="form-group"><label class="control-label col-sm-4" for="cell_id">Cell assigned<span class="required">*</span></label><div class="col-sm-8"><select id="cell_id" data-placeholder="Select" required="required" class="select2 form-control" name="cell_assigned"><option value="">Select Cell assigned</option><option value = "0" selected="selected"> Assign later  </option></select></div></div><div class="form-group"><label class="control-label col-sm-4" for="val">Profession<span class="required">*</span></label><div class="col-sm-8"><select name="profession" class="select2 form-control" id="" data-placeholder="Select"><optgroup label="Healthcare Practitioners and Technical Occupations"><option value="chiropractor">Chiropractor</option><option value="dentist">Dentist</option><option value="dietitian">Dietitian or Nutritionist</option><option value="optometrist">Optometrist</option><option value="pharmacist">Pharmacist</option><option value="physician">Physician</option><option value="physician_assistant">Physician Assistant</option><option value="podiatrist">Podiatrist</option><option value="registered_nurse">Registered Nurse</option><option value="therapist">Therapist</option><option value="veterinarian">Veterinarian</option><option value="health_technologist">Health Technologist or Technician</option><option value="other_health">Other Healthcare Practitioners and Technical Occupation</option><option value="chemist">Chemist</option><option value="doctor">Doctor</option><option value="nurse">Nurse</option></optgroup><optgroup label="Healthcare_support Occupations"><option value="nursing_sychiatric">Nursing, Psychiatric, or Home Health Aide</option><option value="occupational_physical">Occupational and Physical Therapist Assistant or Aide</option><option value="other_healthcare">Other Healthcare Support Occupation</option><option value="environmentalist">Environmentalist</option><option value="industrial_chemist">Industrial Chemist</option><option value="midwife">Nurse/midwife</option></optgroup><optgroup label="Business, Executive, Management, and Financial Occupations"><option value="chief_executive">Chief Executive</option><option value="general_operations">General and Operations Manager</option><option value="advertising">Advertising, Marketing, Promotions, Public Relations, and Sales Manager</option><option value="operations_specialties">Operations Specialties Manager (e.g., IT or HR Manager)</option><option value="construction_manager">Construction Manager</option><option value="engineering_manager">Engineering Manager</option><option value="accountant"></option><option value="business_operations">Business Operations or Financial Specialist</option><option value="business_owner"> Business Owner</option><option value="other_business">Other Business, Executive, Management, Financial Occupation</option><option value="accounting_officer">Accounting Officer</option><option value="project_manager">Project Manager</option><option value="banking">Banker</option><option value="journalist">Broadcast Journalist</option><option value="business_analyst">Business Analyst</option><option value="tax_consultant">Tax Consultant</option><option value="business_consultant">Business Consultant</option><option value="business_development">Business Development</option><option value="business_executive">Business Development Executive</option><option value="business_insight">Business Insight Analyst</option><option value="business_man">Business Man</option><option value="business_manager">Business Manager/Entrepreneur/Contractor</option><option value="oil_and_gas">Businessman in the Oil and Gas</option><option value="employee">Employee</option><option value="enterprise_developer">Enterprise Developer</option><option value="hotelier">Hotelier</option><option value="landscaper">Land Scaper</option><option value="real_estate">Real Estate</option><option value="realtor">Realtor</option><option value="retailing">Retailing</option><option value="sales">Sales</option><option value="sales_insurance">Sales /Insurance</option><option value="salesman">Salesman</option><option value="shipping">Shipping/Logistics Professional</option><option value="trader">Trader</option></optgroup><optgroup label="Architecture and Engineering Occupations"><option value="architect">Architect, Surveyor, or Cartographer</option><option value="engineer">Engineer</option><option value="other_architecture">Other Architecture and Engineering Occupation</option></optgroup><optgroup label="Education, Training, and Library Occupations"><option value="postsecondary_teacher">Postsecondary Teacher (e.g., College Professor)</option><option value="primary">Primary, Secondary, or Special Education School Teacher</option><option value="other_teacher">Other Teacher or Instructor</option><option value="other_education">Other Education, Training, and Library Occupation</option><option value="student">Student/ Business</option><option value="education_consultant">Economist/Consultant</option><option value="educationist">Educationist,Writer</option><option value="educator">Educator</option><option value="french_professor">French professor and translator</option><option value="lecturer">Lecturer</option><option value="student">Student/ Business</option><option value="teacher">Teacher/teaching</option></optgroup><optgroup label="Other Professional Occupations"><option value="arts_design">Arts, Design, Entertainment, Sports, and Media Occupations</option><option value="computer_specialist">Computer Specialist, Mathematical Science</option><option value="counselor">Counselor, Social Worker, or Other Community and Social Service Specialist</option><option value="lawyer">Lawyer</option><option value="life_scientist">Life Scientist (e.g., Animal, Food, Soil, or Biological Scientist, Zoologist)</option><option value="physical_scientist">Physical Scientist (e.g., Astronomer, Physicist, Chemist, Hydrologist)</option><option value="religious_worker">Religious Worker (e.g., Clergy, Director of Religious Activities or Education)</option><option value="social_scientist">Social Scientist and Related Worker</option><option value="other_professional">Other Professional Occupation</option><option value="unemployed">unemployed</option><option value="clergy">Clergy</option><option value="corper">Corper</option><option value="sales_rep">Sales Rep</option><option value="office_assitant"></option><option value="missionary">Missionary</option><option value="none">None</option><option value="politician">Politician</option><option value="unemployed">unemployed</option></optgroup><optgroup label="Office and Administrative Support Occupations"><option value="supervisor">Supervisor of Administrative Support Workers</option><option value="financial_clerk">Financial Clerk</option><option value="secretary">Secretary or Administrative Assistant</option><option value="material_recording">Material Recording, Scheduling, and Dispatching Worker</option><option value="other_office">Other Office and Administrative Support Occupation</option><option value="manager">Manager</option><option value="administrator">Manager & Administrator</option><option value="sales_manager">Sales Manager</option></optgroup><optgroup label="Services Occupations"><option value="protective_service">Protective Service (e.g., Fire Fighting, Police Officer, Correctional Officer)</option><option value="chef">Chef or Head Cook</option><option value="cook">Cook or Food Preparation Worker</option><option value="food">Food and Beverage Serving Worker (e.g., Bartender, Waiter, Waitress)</option><option value="building">Building and Grounds Cleaning and Maintenance, Painter</option><option value="personal_care">Personal Care and Service (e.g., Hairdresser, Flight Attendant, Concierge)</option><option value="sales_supervisor">Sales Supervisor, Retail Sales</option><option value="retail_sales">Retail Sales Worker</option><option value="insurance">Insurance Sales Agent</option><option value="sales_rep">Sales Rep</option><option value="real_estate">Real Estate</option><option value="other_services">Other Services Occupation</option><option value="caterer">Caterer</option><option value="cleaning_service">Cleaning services</option><option value="cruise_sales">Cruise Sales Manager / Flight Dispatcher</option><option value="customer_service">Customer Service</option><option value="customs">Customs Clearing Agent &Maritime Consultant</option><option value="event_planner">Event Planner / Business /Actor</option><option value="research">Research Consulting</option><option value="sales_consultant">Sales consultant</option><option value="travel_agent">Travel Agent</option><option value="travel_consultant">Travel Consultant</option></optgroup><optgroup label="Farming, Fishing, and Forestry"><option value="construction">Construction Engineer/Builder</option><option value="agriculture">Farming, Fishing, and Forestry</option><option value="installation">Installation, Maintenance, and Repair</option><option value="production">Production Occupations</option><option value="repair">Other Agriculture, Maintenance, Repair, and Skilled Crafts Occupation</option><option value="farmer">Farmer & agro/livestock consultant</option></optgroup><optgroup label="Transportation Occupations"><option value="aircraft">Aircraft Pilot or Flight Engineer</option><option value="motor_operator">Motor Vehicle Operator (e.g., Ambulance, Bus, Taxi, or Truck Driver)</option><option value="other_transport">Other Transportation Occupation</option></optgroup><optgroup label="Other Occupation"><option value="military">Military</option><option value="homemaker">Homemaker</option><option value="other_occupations">Other Occupation</option><option value="makeup">Makeup Artist</option><option value="fashion">Fashion Designer</option><option value="not_applicable">Not Applicable</option><option value="corporate_business">Corporate Business</option><option value="geologist">Geologist</option><option value="industrialist"></option><option value="urban_planning">Urban or Town Planning</option><option value="worker">Worker</option></optgroup><optgroup label="Administration - General, Confidential"><option value="administration">Administration - General, Confidential</option><option value="human_resources">Human Resource Practitioner</option><option value="operations_management">Operations Management</option><option value="performance">Performance Management</option><option value="quality">Quality Management</option><option value="legal">Legal</option><option value="hospitality">Hospitality Management</option><option value="administration_inventory">Administration/Inventory Management</option><option value="administrator">Manager & Administrator</option><option value="personnel_manager">Personnel Manager</option><option value="corporate"></option><option value="finance_manager">Finance Manager</option><option value="church_admin">Church Admin and Organization Manager</option><option value="church_staff">Church Staff</option><option value="civil_servant">Civil Servant</option><option value="communication_expert">Communication Expert (International Development)</option><option value="engineering_management">Engineering, Management</option><option value="executive_assistant">Executive Assistant</option><option value="first_timer">First Timers Ministry</option><option value="foundation_school">Foundation School</option><option value="ftm_operation">FTM Operations Manager</option><option value="fund_administrator">Fund Administrator</option><option value="head_of_operations">Head Of Operations </option><option value="hr_professional">HR Professional</option><option value="human_resources">Human Resource Practitioner</option><option value="leadership_dev">Leadership Development Officer</option><option value="ministry_director">Ministry Director/LMP TEACHING</option><option value="ngk_staff">NGK staff</option><option value="operations">Operations</option><option value="operations_manager">Operations manager</option><option value="pastor">Pastor</option><option value="pfcc_manager">PFCC Manager</option><option value="project_manager">Project Manager</option><option value="sales_executive">Sales Executive</option><option value="facility_manager">Sound Engineer/ Facility Manager</option><option value="lwpm_staff">Loveword publishing staff</option><option value="ce_staff">BLW Staff</option><option value="blw_voluntary">Voluntary Staff BLW</option></optgroup><optgroup label="Preproduction - Art & Design"><option value="media">Preproduction - Art & Design</option><option value="scripting">Preproduction - Scripting</option><option value="video_production">Production – Video Production</option><option value="audio_production">Production – Audio & Sound Production</option><option value="lighting">Production - Lighting</option><option value="still_photo">Production – Still Photography</option><option value="editorial">Production – Editorial</option><option value="motion_graph">Post Production – Motion Graphics</option><option value="transmission">Transmissions – Broadcast</option><option value="quality_control">Quality Control</option><option value="asset">Media Asset Management </option><option value="camera">Camera Operator</option><option value="cinematographer">Cinematographer</option><option value="film_maker">Film Maker</option><option value="media_professional">Media Professional and Film Maker</option><option value="motion_graphics">Motion Graphics Artist</option><option value="multimedia_director">Multimedia Director</option><option value="photographer">Photographer</option><option value="press">Press</option><option value="screen_writer">Screen Writer/ Director/Producer</option></optgroup><optgroup label="Information Technology"><option value="mobile_app">Mobile Application Development</option><option value="desktop_intranet">Desktop and Intranet Applications Development</option><option value="database">Database Application Development</option><option value="server_admin">Server Administration</option><option value="system_engineering">Software Engineering</option><option value="hardware_engineering">Hardware Engineering</option><option value="networking">Networking</option><option value="support_system">IT Support System</option><option value="database_manager">Database Manager</option><option value="developer">Developer</option><option value="network_engineer">ICT Network  engineer</option><option value="it_support">Information Tech Support</option><option value="it_sales">Information Technology Sales Professional</option><option value="it_consultant">IT Consultant</option><option value="it_developer">IT Developer</option><option value="it_infrastructure">Investment Banking Professional</option><option value="it_professional">IT Professional/Consultant</option><option value="it_project_manager">IT Project Manager</option><option value="mit">MIT</option><option value="social_media">Social Media Manager</option><option value="software_dev">Software Developer</option><option value="software_tester">Software Tester and SAP ERP Consultant</option><option value="telecomm">Telecomm</option><option value="web_designer">Web developer</option><option value="web_developer">Web Developer, graphics Designer,</option><option value="web_manager">Web Manager</option><option value="web_admin">Website administrator</option></optgroup><optgroup label="Publishing"><option value="script_writer">Script Writing</option><option value="graphics_design">Graphics Designers</option><option value="illustrator">Illustrators/Animators</option><option value="audio_editor">Audio Editor</option></optgroup><optgroup label="Marketing"><option value="partnership">Partnership</option><option value="sales">Sales</option><option value="brand">Brand Communication & Marketing</option><option value="digital_marketing">Digital Marketing</option><option value="logistician">Logistician</option><option value="marketer">Marketer</option><option value="marketing_manager">Marketing manager</option><option value="media_sales">Med sales Rep</option><option value="media_consultant">Media Consultant</option><option value="network_marketing">Network marketing professional.</option></optgroup><optgroup label="Finanace"><option value="cost_management">Cost & Management Accounting</option><option value="treasury">Treasury & Financial Operations</option><option value="book_keeping">Financial Accounting & Book Keeping</option><option value="inventory">Inventory Management</option><option value="payroll">Payroll   Management</option><option value="internal_control">Internal Control & Auditing</option><option value="procurement">Procurement & Supply Chain Management</option><option value="economist">Economist</option><option value="finance">Finanace</option><option value="finance_manager">Finance Manager</option><option value="finance_specialist">Finance Specialist</option><option value="financial_consultant">Finance Consultant</option><option value="investment_banking">Investment Banking Professional</option></optgroup><optgroup label="Security"><option value="physical_security">Physical Security</option><option value="incident_duty">Incident Duty Management</option><option value="fleet">Fleet Management</option><option value="safety_management">Fire, Health & Safety Management</option><option value="cso">CSO</option><option value="military">Military</option><option value="security_agent">Security Agent</option><option value="soldier">Soldier</option></optgroup><optgroup label="Specialist"><option value="pastoral_care">Pastoral Care</option><option value="pfcc">PFCC</option><option value="ft_ministry">First Timer's Ministry</option><option value="foundation_school">Foundation School</option><option value="music_arts">Music & Arts</option><option value="healing_center">Healing Center</option><option value="medical">Medical</option><option value="social_work">Social Work & Teaching</option><option value="consultant">Consultant</option><option value="bible_study">Bible Study Teacher</option><option value="campus_ministry">BLW Campus Ministry</option><option value="hq_staff">BLW HQ Staff Member</option><option value="branding">Brand Strategist and Visual Designer</option><option value="bureau_de_change">Bureau de Change Operator</option><option value="music">Business/Music</option><option value="coach">Coach</option><option value="content_developer">Content Developer</option><option value="contractor">Contractor</option><option value="dancer">Dancer</option><option value="deacon">Deacon</option><option value="driver">Driver</option><option value="electrical_technician">Electrical technician</option><option value="fashion_designer">Fashion designer</option><option value="field_representative">Field Representative</option><option value="furniture_maker">Furniture maker</option><option value="geo_scientist">Geoscientist</option><option value="gis">GIS/REMOTE Sensing Specialist/ Surveyor</option><option value="graphics_designer">Graphic Designer</option><option value="graphics_editor">Graphic Editor</option><option value="hair_dresser">Hair Dresser</option><option value="interior_designer">Interior Designer</option><option value="lawyer">Lawyer</option><option value="legal_practitioner">Legal Practitioner</option><option value="makeup">Makeup Artist</option><option value="minister">Minister</option><option value="model">Model</option><option value="motivation_speaker">Motivation Speaker</option><option value="musician">Musician</option><option value="partnership_relations">Partnership relations</option><option value="actor">Professional Actor/Singer</option><option value="energy_consultant">Renewable Energy Consultant</option><option value="self_employed">Self employed</option><option value="telecomm_consultant">Telecomms Consultant</option></optgroup><optgroup label=""><option value="artisan">Artisan</option><option value="automobile">Automobile Sales Dealer</option><option value="broadcasting">Broadcasting/Project Management</option><option value="baker">Baker</option><option value="engineering_entrepreneur">Engineering Entrepreneur</option><option value="entrepreneur">Enterprenuer</option><option value="music_producer">Music producer</option></optgroup><optgroup label=""><option value="aviator">Aviator</option><option value="civil_engineer">Civil Engineer</option><option value="computer_engineer">Computer Engineer</option><option value="computing_professional">Computing Professional</option><option value="construction">Construction Engineer/Builder</option><option value="cost_engineer">Cost Engineer</option><option value="electrical_engineer">Electrical engineer</option><option value="engineer">Engineer</option><option value="lift_engineer">Lift Engineer</option><option value="missionary_engineer">Missionary Engineer</option><option value="sales_engineer">Sales Engineer</option><option value="software_engineer">Software Engineer</option><option value="sound_engineer"></option><option value="system_engineer">Systems Engineer</option><option value="telecomm_engineer">Telecom Engineer</option></optgroup></select></div></div><div class="form-group"><label class="control-label col-sm-4"for="present_employer">Present Employer</label><div class="col-sm-8"><input type="text" name="present_employer" value="" label="Present Employer" class="form-control input-transparent" id="present_employer"  />
<br/></div></div><div style="display: none"><div><input name = "record_type" type="hidden"value="first_timer""><input type="hidden" name="record_type" value="first_timer" id="record_type"  />
<br/></div></div><div class="form-group"><label class="control-label col-sm-4"for="first_day_in_church">First day in Church<span class="required">*</span></label><div class="col-sm-8"><input type="text" name="first_day_in_church" value="" label="First day in Church" class="form-control input-transparent date-picker" id="first_day_in_church" required="required"  />
<br/></div></div><div class="form-group"> <label class="col-sm-4 control-label" for="default-select">Invited By<span class="required">*</span></label><div class="col-sm-8"><select id ="term" class="member form-control"  name="invited_by"><option value="">Search</option> </select></div></div><div class="form-group"><label class="control-label col-sm-4"for="prayer_request">Prayer request</label><div class="col-sm-8"><input type="text" name="prayer_request" value="" label="Prayer request" class="form-control input-transparent" id="prayer_request"  />
<br/></div></div><div class="form-group"><label class="control-label col-sm-4"for="visit_time">Visiting time<span class="required">*</span></label><div class="col-sm-8"><input type="text" name="visit_time" value="" label="Visiting time" class="form-control input-transparent date-picker" id="visit_time" required="required"  />
<br/></div></div><div class="form-group"><label class="control-label col-sm-4"for="nearest_landmark">Nearest landmark</label><div class="col-sm-8"><input type="text" name="nearest_landmark" value="" label="Nearest landmark" class="form-control input-transparent" id="nearest_landmark"  />
<br/></div></div><div class="row"><div class="form-group col-sm-9"><div class="control-label col-sm-6">Is first timer new convert</div><div class="radio col-sm-6"><div class="col-sm-12"><input type="radio"  name="is_new_convert" id="is_new_convert" value="yes">  <label for="is_new_convert">Yes</label></div><div class="col-sm-12"><input type="radio"  name="is_new_convert" id="is_new_convert" value="no">  <label for="is_new_convert">No</label></div></div></div></div><div class="row"><div class="form-group col-sm-9"><div class="control-label col-sm-6">Is first timer baptised</div><div class="radio col-sm-6"><div class="col-sm-12"><input type="radio"  name="is_baptised" id="is_baptised" value="yes">  <label for="is_baptised">Yes</label></div><div class="col-sm-12"><input type="radio"  name="is_baptised" id="is_baptised" value="no">  <label for="is_baptised">No</label></div></div></div></div><div class="row"><div class="form-group col-sm-9"><div class="control-label col-sm-6">How first timer came to church</div><div class="radio col-sm-6"><div class="col-sm-12"><input type="radio"  name="ft_source" id="ft_source" value="tv">  <label for="ft_source">TV</label></div><div class="col-sm-12"><input type="radio"  name="ft_source" id="ft_source" value="radio">  <label for="ft_source">Radio</label></div><div class="col-sm-12"><input type="radio"  name="ft_source" id="ft_source" value="social_media">  <label for="ft_source">Social Media Manager</label></div><div class="col-sm-12"><input type="radio"  name="ft_source" id="ft_source" value="website">  <label for="ft_source">Website</label></div><div class="col-sm-12"><input type="radio"  name="ft_source" id="ft_source" value="outreach">  <label for="ft_source">Outreach</label></div><div class="col-sm-12"><input type="radio"  name="ft_source" id="ft_source" value="invitation">  <label for="ft_source">Special invitation</label></div><div class="col-sm-12"><input type="radio"  name="ft_source" id="ft_source" value="cell_ministry">  <label for="ft_source">Cell Ministry</label></div><div class="col-sm-12"><input type="radio"  name="ft_source" id="walk_in" value="walk_in">  <label for="walk_in">Walk in</label></div><div class="col-sm-12"><input type="radio"  name="ft_source" id="holy_spirit" value="holy_spirit">  <label for="holy_spirit">Holy Spirit</label></div></div></div></div><div class="form-group"> <label class="col-sm-4 control-label" for="default-select">Follow up by</label><div class="col-sm-8"><select id="follow_up_by" class="form-control select2" name="follow_up_by"><option value="">Search</option> </select></div></div><div class="form-group"><label class="control-label col-sm-4"for="member_picture">Passport picture (275 * 275)px<span class="help-block">Photo must be set at given dimension</span></label><div class="col-sm-8"><input type="file" name="member_picture" value="" label="Passport picture (275 * 275)px" class="form-control input-transparent" id="member_picture" hint="Photo must be set at given dimension"  />
<br/></div></div><input type="hidden"  name="church_id"  value="331"><input type="hidden" name="group_id"   value="70"><input type="hidden" name="zone_id"    value="1"><input type="hidden" name="region_id"  value="1"><input type="hidden" name="created_by" value="1"><input type="hidden" name="created_at" value="2018-09-21 11:26:00"><span class="btn btn-inverse" data-target="#us6-dialog" data-toggle="modal">Set Location</span>
<div class="form-group"><label class="control-label col-sm-4"for="us3-lat">Longitude<span class="required">*</span></label><div class="col-sm-8"><input type="text" name="mem_long" value="0" label="Longitude" class="form-control col-sm-3 input-transparent" id="us3-lat" required="required" readonly="readonly"  />
<br/></div></div><div class="form-group"><label class="control-label col-sm-4"for="us3-lon">Latitude<span class="required">*</span></label><div class="col-sm-8"><input type="text" name="mem_lat" value="0" label="Latitude" class="form-control col-sm-3 input-transparent" id="us3-lon" required="required" readonly="readonly"  />
<br/></div></div><div class="form-group"><label class="col-sm-4 control-label" for="elastic-textarea">Additional Info</label><div class="col-sm-8"><textarea rows="3" class="autogrow form-control transition-height input-transparent" id="elastic-textarea" name="additional_info"></textarea></div></div>


<div id="us6-dialog" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Set your location</h4>
            </div>
            <div class="modal-body">
                <div class="form-horizontal" style="width: 550px">
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Location:</label>

                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="us3-address" />
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Radius:</label>

                        <div class="col-sm-5">
                            <input type="text" class="form-control" id="us3-radius" />
                        </div>
                    </div>

                    <div id="us3" style="width: 100%; height: 400px;"></div>
                    <div class="clearfix">&nbsp;</div>
                    <div class="m-t-small">

                    </div>
                    <div class="clearfix"></div>



                    <script>

                            $('#us3').locationpicker({
                                location: {
    latitude: 0,
                                    longitude: 0                                },
                                radius: 300,
                                inputBinding: {
    latitudeInput: $('#us3-lat'),
                                    longitudeInput: $('#us3-lon'),
                                    radiusInput: $('#us3-radius'),
                                    locationNameInput: $('#us3-address')

                                },
                                enableAutocomplete: true,
                                markerIcon: 'https://loveworldims.org/assets/img/map-marker-2-xl.png'

                            });
                            $('#us6-dialog').on('shown.bs.modal', function () {
                                $('#us3').locationpicker('autosize');
                            });


                    </script>




                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal">Save changes</button>

            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>









<script type="text/javascript">
    $('.member').select2({
            ajax: {
    url: 'https://loveworldims.org//grow/get_member_list',
                dataType: 'json',
                delay: 250,
                processResults: function (data) {
        return {
            results: data
                    };
                },
                cache: true
            }
        });


</script>

<script type="text/javascript">


    $('#country_id').on('change',function(){
        var countryID = $(this).val();
        if(countryID){
            $.ajax({
                    type:'POST',
                    url:"https://loveworldims.org/grow/select_state",
                    data:'church_country='+countryID,
                    success:function(html){
                $('#state_id').html(html);
                $('#city_id').html('<option value="">Select state first</option>');
            }
                });
            }else{
            $('#state_id').html('<option value="">Select country first</option>');
            $('#city_id').html('<option value="">Select state first</option>');
        }
    });

        $('#state_id').on('change',function(){
            var stateID = $(this).val();
            if(stateID){
                $.ajax({
                    type:'POST',
                    url:"https://loveworldims.org/grow/select_city",
                    data:'church_state='+stateID,
                    success:function(html){
                    $('#city_id').html(html);
                }
                });
            }else{
                $('#city_id').html('<option value="">Select state first</option>');
            }
        });


</script>


<script type="text/javascript">

    $(function () {
        $('#visit_time').datetimepicker({
                format: 'LT'
            });
        });

</script>

<script type="text/javascript">
    $('#follow_up_by').select2({

       // placeholder: 'Select an item',
        ajax: {
    url: 'https://loveworldims.org//grow/get_member_list',
            dataType: 'json',
            delay: 250,
            processResults: function (data) {
        return {
            results: data
                };
            },
            cache: true
        }

    });
</script>

<script type="text/javascript">
    $('#invited_by').select2({

       // placeholder: 'Select an item',
        ajax: {
    url: 'https://loveworldims.org//grow/get_member_list',
            dataType: 'json',
            delay: 250,
            processResults: function (data) {
        return {
            results: data
                };
            },
            cache: true
        }

    });
</script>






    </fieldset>



<div class="form-actions">
    <div class="row">
        <div class="col-sm-8 col-sm-offset-4">
            <input type="hidden" name="created_by" value="1">

                            <button id="sub" type="submit" onclick="new_form()" class="btn btn-primary">Save and new</button>
                <button id="subs" type="submit" name="list_page" value="church/members/members" class="btn btn-primary">Save and exit</button>
                        <button type="reset" class="btn btn-default">Cancel</button>
        </div>
    </div>
</div>
</form>
</div>
</section>
</div>
<script>
    function new_form() {
        document.getElementById("subs").value = "";
    }
</script>



            <div class="col-md-5">
                <section class="widget">
                    <header>
                        <h5>
First Timer :: Add New record                        </h5>
                        <div class="widget-controls">
                            <a href="#"><i class="glyphicon glyphicon-cog"></i></a>
                            <a href="#"><i class="fa fa-refresh"></i></a>
                            <a href="#" data-widgster="close"><i class="glyphicon glyphicon-remove"></i></a>
                        </div>
                    </header>
                    <div class="body">
                        <form role="form">
                            <fieldset>
                                <legend>
How it works                                </legend>
                                <p><ul class="text-list">
                                   <li>A member must have gone through foundation school, completion date is required. Approximate date is acceptable</li><li>Date of birth are used for birthday greetings, they are required and must be accurate</li><li>With those credentials, a member can update his basic information, see all giving records</li><li>Passport picture sizes must be adhered to, to avoid unpredictable behaviour. JPG, JPEG and PNG files are accepted</li><li>The location is a requirement, just tap the set location and set coordinates</li>                                </p>
                                <br/>

                            </fieldset>
                        </form>
                    </div>
                </section>
            </div>


<div class="col-md-5"><section class="widget" id="shares-widget" data-widgster-load=""><header><h5><span class="label label-primary"></span> &nbsp;Latest Records</h5><div class="widget-controls"><a data-widgster="load" title="Reload" href="#"><a data-widgster="close" title="Close" href="#"><strong class="text-gray-light"></strong></a></div></header><div class="body no-padding"><div class="list-group list-group-lg"><a href="#" class="list-group-item"><span class="thumb-sm pull-left mr"><i class="fa fa-check"></i></span><i class="fa fa-circle pull-right text-warning mt-sm"></i><h5 class="no-margin">Deacon Eric Edafitite</h5><small class="text-muted">20 Days ago</small></a><a href="#" class="list-group-item"><span class="thumb-sm pull-left mr"><i class="fa fa-check"></i></span><i class="fa fa-circle pull-right text-info mt-sm"></i><h5 class="no-margin">Brother Peter Oliseh</h5><small class="text-muted">3 Months ago</small></a><a href="#" class="list-group-item"><span class="thumb-sm pull-left mr"><i class="fa fa-check"></i></span><i class="fa fa-circle pull-right text-warning mt-sm"></i><h5 class="no-margin">Brother Felix Anyanwu</h5><small class="text-muted">3 Months ago</small></a><a href="#" class="list-group-item"><span class="thumb-sm pull-left mr"><i class="fa fa-check"></i></span><i class="fa fa-circle pull-right text-success mt-sm"></i><h5 class="no-margin">Brother Barnes Lee Teen</h5><small class="text-muted">3 Months ago</small></a><a href="#" class="list-group-item"><span class="thumb-sm pull-left mr"><i class="fa fa-check"></i></span><i class="fa fa-circle pull-right text-info mt-sm"></i><h5 class="no-margin">Pastor Test Test</h5><small class="text-muted">3 Months ago</small></a><a href="#" class="list-group-item"><span class="thumb-sm pull-left mr"><i class="fa fa-check"></i></span><i class="fa fa-circle pull-right text-warning mt-sm"></i><h5 class="no-margin">Brother Felix Tony</h5><small class="text-muted">3 Months ago</small></a><a href="#" class="list-group-item"><span class="thumb-sm pull-left mr"><i class="fa fa-check"></i></span><i class="fa fa-circle pull-right text-info mt-sm"></i><h5 class="no-margin">Sister Helen Ahonsi</h5><small class="text-muted">4 Months ago</small></a><a href="#" class="list-group-item"><span class="thumb-sm pull-left mr"><i class="fa fa-check"></i></span><i class="fa fa-circle pull-right text-success mt-sm"></i><h5 class="no-margin">Brother Dartey Eben</h5><small class="text-muted">4 Months ago</small></a><a href="#" class="list-group-item"><span class="thumb-sm pull-left mr"><i class="fa fa-check"></i></span><i class="fa fa-circle pull-right text-danger mt-sm"></i><h5 class="no-margin">Brother Gbenga Akofe</h5><small class="text-muted">4 Months ago</small></a><a href="#" class="list-group-item"><span class="thumb-sm pull-left mr"><i class="fa fa-check"></i></span><i class="fa fa-circle pull-right text-danger mt-sm"></i><h5 class="no-margin">Pastor Pipo Ero</h5><small class="text-muted">5 Months ago</small></a><a href="#" class="list-group-item"><span class="thumb-sm pull-left mr"><i class="fa fa-check"></i></span><i class="fa fa-circle pull-right text-danger mt-sm"></i><h5 class="no-margin">Sister Yemisi Chikeme</h5><small class="text-muted">5 Months ago</small></a><a href="#" class="list-group-item"><span class="thumb-sm pull-left mr"><i class="fa fa-check"></i></span><i class="fa fa-circle pull-right text-danger mt-sm"></i><h5 class="no-margin">Sister Sokoko Bukky</h5><small class="text-muted">5 Months ago</small></a><a href="#" class="list-group-item"><span class="thumb-sm pull-left mr"><i class="fa fa-check"></i></span><i class="fa fa-circle pull-right text-info mt-sm"></i><h5 class="no-margin">Sister Toun Thomas</h5><small class="text-muted">5 Months ago</small></a></div></div></section></div>


</div>

    </div>
<div class="loader-wrap hiding hide">
    <i class="fa fa-circle-o-notch fa-spin"></i>
</div>




<!-- page specific scripts -->
<!-- page libs -->
<script src="https://loveworldims.org/assets/lib/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
<script src="https://loveworldims.org/assets/lib/select2/select2.min.js"></script>
<script src="https://loveworldims.org/assets/lib/moment/moment.js"></script>
<script src="https://loveworldims.org/assets/lib/eonasdan-bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js"></script>
<script src="https://loveworldims.org/assets/lib/parsleyjs/dist/parsley.min.js"></script>

<script src="https://loveworldims.org/assets/lib/jquery.maskedinput/dist/jquery.maskedinput.min.js"></script>






<!-- page application js -->
<script src="https://loveworldims.org/assets/js/forms-account.js"></script>
<script src="https://loveworldims.org/assets/lib/parsleyjs/dist/i18n/en.js" type=" text/javascript"></script>

<script type="text/javascript">
    $(document).ready(function(){
        $("form").submit(function() {
            $(this).submit(function() {
                return false;
            });
            return true;
        });

    });
</script>


<div class="col-md-12 col-md-9 offset-md-6">
    <footer class="content-footer">
        <span class="align-right">Grow. Spiritually, numerically and financially :: [Zone v1.0.0] Powered by <a href="http://internetmultimediaonline.org" rel="nofollow" target="_blank">IMM</a>. &copy 2018. All rights reserved</span>
    </footer>
</div>


</body>
</html>
