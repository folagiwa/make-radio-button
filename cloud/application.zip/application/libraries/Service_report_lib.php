<?php
/**
 * File:    Service_report_lib
 * @Author: XYZoe
 * @email:  zoechuksimm@loveworld360.com
 * Date:    02/10/2018
 * Time:    15:20
 */

class Service_report_lib extends Common_lib {

    protected $CI;
    protected $church;
    protected $member;
    protected $template;

    public function __construct()
    {
        $this->CI =& get_instance();

        $this->CI->load->model('service_reports_model');
        $this->church = $_SESSION['logged_in']['church_id'];
        $this->member = $_SESSION['logged_in']['member_id'];

        $this->template = ['table_open' => '<table id="data-table" class="table table-striped table-hover DataTable">'];

    }

    public function new_service_report($legend,$links,$action){
        if($this->CI->uri->segment(3)){
            //if there's an ID then tis an update
            $s_id       = cloud_decode($this->CI->uri->segment(3));

            //compare the service_id from the URL to the one at the DB
            $record_id  = $this->CI->service_reports_model->get($s_id);

            //title of the service report
            if($record_id){
                $title  = $this->CI->lang->line('update_service_report');
            }else{
                $title  = $this->CI->lang->line('new_service_report');
            }

        }//if there's no ID then it's a new report
        else{
            $title  = $this->CI->lang->line('new_service_report');
        }

        //now the form proper...if we have a service_id(hidden field) on the form then tis an update
        if($this->CI->input->post('service_id')){
            $this->CI->service_reports_model->from_form(NULL, NULL, ['service_id'])->update();
            $this->CI->session->set_userdata('info',$this->CI->lang->line('update_success'));
            $service_id = TRUE;

            $attendance = $this->CI->input->post('attendance_kids');
            $attendance += $this->CI->input->post('attendance_teens');
            $attendance += $this->CI->input->post('attendance_adults');

            $data       = ['total_attendance'=>$attendance];

            $this->CI->db->where('service_id', $service_id);
            $this->CI->db->update('grow_service_reports', $data);

        }else{
            //tis a new service report if there's no service_id
            $service_id = $this->CI->service_reports_model->from_form()->insert();
            if($service_id){
                $attendance = $this->CI->input->post('attendance_kids');
                $attendance += $this->CI->input->post('attendance_teens');
                $attendance += $this->CI->input->post('attendance_adults');

                $data       = ['total_attendance'=>$attendance];

                $this->CI->db->where('service_id', $service_id);
                $this->CI->db->update('grow_service_reports', $data);

                if($service_id){
                    $this->CI->session->set_userdata('info',$this->CI->lang->line('save_success'));
                }else{
                    $this->CI->session->set_userdata('info',$this->CI->lang->line('save_error'));
                }
            }
        }

        if($service_id === FALSE){
            $recs                   = (!isset($record_id))? '' : $record_id;
            $data['links']          = $links;
            $data['action']         = $action;
            $data['legend']         = lang('service_report_sec');
            $data['title']          = lang('service_report_sec');
            $data['table_title']    = lang('table_service_report') .lang('list');
            $data['sub_title']      = lang('sub_title_write_up');
            $data['table_content']  = $this->service_report_list();
            $data['service_info']   = $recs;
            $data['content']        = $this->CI->load->view('service_reports/new_service_report', $data, TRUE);
            $data['latest']         = latest_records($this->latest_service_reports());
            $data['scripts']        = $this->CI->load->view('partials/footer_form_blank', $data, TRUE);
            $data['scripts']       .= $this->CI->load->view('partials/footer_tables', $data, TRUE);
            $data['handle']         = $this->CI->load->view('partials/form_blank_tab', $data, TRUE);
            $this->CI->load->view('partials/master', $data);
        }else{
            redirect($action, 'refresh');
        }
    }

    public function latest_service_reports(){
        $arr = $this->fetch_service_report_data(5);
        if(is_array($arr)){
            $lists = [];
            foreach ($arr as $key => $val){
                $info = $val['service_type'].' '.($val['service_date']);
                $lists[$val['service_id']] =['label'=>$info,'time'=>time_diff($val['updated_at'])];
            }
        }

        return $lists;
    }

    public function fetch_service_report_data($limit = ''){
        $field  = ['service_id', 'service_date','service_type', 'total_attendance', 'first_timers', 'new_converts','church_id','updated_at'];

        //data tables to select from
        $table  = ['grow_service_reports'];
        $where  = ['church_id'=>$this->church];

        //the fields needed multidimensional array
        $list    = ask_db($field, $table, $where,'','service_date','DESC',$limit);

        return $list;

    }

    public function service_report_list(){
        //service report list
        $lists    = $this->fetch_service_report_data();
        //dump($lists);

        $this->CI->table->set_template($this->template);

        $headers    = [
            'service_date'      => ['data' => lang('service_date'), 'class' => ''],
            'service_type'      => ['data' => lang('service_type'), 'class' => ''],
            'total_attendance'  => ['data' => lang('total_attendance'), 'class' => ''],
            'first_timers'      => ['data' => lang('first_timers'), 'class' => ''],
            'new_converts'      => ['data' => lang('new_converts'), 'class' => ''],
            'manage'            => ['data' => lang('manage'), 'class' => '']
        ];
        $this->CI->table->set_heading($headers);

        if(is_array($lists)){
            foreach ($lists as $key => $val){
                $manage =   anchor("/service_report/submit_service_report/" . cloud_encode($val['service_id']), '<i class="fa fa-pencil-square-o"></i>');
                $manage .=  ' :: ';
                $manage .=  anchor("/reports/delete_report/" . $val['service_id'], '<i class="fa fa-times"></i>');

                $data   = [
                    'service_date'      => ['data' => $val['service_date'],        'class' => ''],
                    'service_type'      => ['data' => $val['service_type'],        'class' => ''],
                    'total_attendance'  => ['data' => $val['total_attendance'],    'class' => ''],
                    'first_timers'      => ['data' => $val['first_timers'],        'class' => ''],
                    'new_converts'      => ['data' => $val['new_converts'],        'class' => ''],
                    'manage'            => [$manage,                               'class' => '']
                ];
                //dump($data);
                $this->CI->table->add_row($data);
            }
        } else{
            $no_recs    = [
                'service_date'      => ['data' => lang('no_record'), 'class' => ''],
                'service_type'      => ['data' => lang('no_record'), 'class' => ''],
                'total_attendance'  => ['data' => lang('no_record'), 'class' => ''],
                'first_timers'      => ['data' => lang('no_record'), 'class' => ''],
                'new_converts'      => ['data' => lang('no_record'), 'class' => ''],
                'manage'            => ['data' => lang('no_record'), 'class' => '']
            ];
            $this->CI->table->add_row($no_recs);
        }
        return $this->CI->table->generate();
    }
}