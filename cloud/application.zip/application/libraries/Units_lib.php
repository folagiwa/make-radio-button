<?php
/**
 * File       : Users_lib.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/20/18
 * Time: 1:05 PM
 */

class Units_lib extends Common_lib {

    protected $CI;

    public function __construct()

    {
        parent::__construct();
        $this->CI =& get_instance();
        $this->CI->load->library('form_validation');
        $this->CI->load->library('table');
        $this->CI->load->model('users_model');
        $this->CI->load->library('email');
        $this->CI->load->library('mails_lib');

    }

    public function fetch($tag){
        $session = $this->CI->session->logged_in;
        $this->CI->table->set_template($this->template);

        $a = ask_db('*', 'grow_tags', ['tag_type'=>"'$tag'", 'church_id'=>$session['church_id']]);
        if($a){
            $this->CI->table->set_heading('UNIT NAME', 'LEADER NAME');
            foreach($a as $val){
                //$type = ucwords(str_replace('_', ' ', $val['tag_type']));
                $b = ask_db('*', 'grow_members',['member_id'=>$val['leader']]);
                if($b){
                    $fullname = $b[0]['title'] . ' ' . $b[0]['first_name'] . ' ' . $b[0]['surname'];
                    $this->CI->table->add_row($val['tag_name'], $fullname);
                }



            }
            return $this->CI->table->generate();
        }
    }

    public function fellowships_table(){
        return $this->fetch('fellowship');


    }

    public function service_departments_table(){
        return $this->fetch('service_department');
    }

    public function adult_groups_table(){
        return $this->fetch('adult');
    }

    public function teens_groups_table(){
        return $this->fetch('teens');
    }

    public function kids_groups_table(){
        return $this->fetch('kids');
    }



}