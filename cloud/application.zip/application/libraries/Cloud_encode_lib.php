<?php
/**
 * File       : Cloud_encode_lib.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/21/18
 * Time: 10:50 AM
 */

if (!defined('BASEPATH')) exit('No direct script access allowed');

class Cloud_encode_lib {

    public function __construct() {

    }

    public function cloud_encode( $string, $action = 'e' ) {
        $secret_key = 'TTBKZXBZekdMMEQrVitBanRZc0V2UT09';
        $secret_iv  = 'TTBKZXBZekdMMEQrVitBanRZc0V2UT09';

        $output = false;
        $encrypt_method = "AES-256-CBC";
        $key = hash( 'sha256', $secret_key );
        $iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );

        if( $action == 'e' ) {
            $output = base64_encode( openssl_encrypt( $string, $encrypt_method, $key, 0, $iv ) );
        }
        else if( $action == 'd' ){
            $output = openssl_decrypt( base64_decode( $string ), $encrypt_method, $key, 0, $iv );
        }

        return $output;
    }

    public function encode($num){
        return $this->cloud_encode($num, 'e' );
    }

    public function decode($str){
        return $this->cloud_encode($str, 'd' );
    }


}

