<?php
/**
 * File       : Common_lib.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 10/13/18
 * Time: 21:40
 */

class Common_lib {
    protected $template;
    protected $CI;
    protected $church;
    protected $member;

    public function __construct()
    {
        $this->CI =& get_instance();

        $this->CI->load->model('members_model');
        $this->CI->load->model('countries_model');
        $this->CI->load->model('cities_model');
        $this->CI->load->model('states_model');
        $this->CI->load->model('tags_model');

        $this->CI->load->library('form_validation');
        $this->CI->load->library('table');

        $this->church = $_SESSION['logged_in']['church_id'];
        $this->member = $_SESSION['logged_in']['member_id'];

        $this->template = ['table_open' => '<table id="data-table" class="table table-striped table-hover DataTable">'];
    }
}