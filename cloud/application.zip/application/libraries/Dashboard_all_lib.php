<?php
/**
 * File:    Dashboard_all_lib
 * @Author: XYZoe
 * @email:  zoechuksimm@loveworld360.com
 * Date:    31/10/2018
 * Time:    18:37
 */

defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_all_lib extends Common_lib{
    protected $church;
    protected $CI;

    public function __construct() {
        $this->church = $_SESSION['logged_in']['church_id'];
        $this->CI =& get_instance();
    }

    public function church_stats($key,$table,$group){
        if($key == 'total_attendance' || $key == 'service_id'){
            $where  = ['church_id'=>$this->church,'service_type'=>"'weekend'"];
        }elseif($key == 'first_timers' || $key == 'new_converts' || $key == 'thanksgiving' || $key == 'tithe' || $key == 'offering' || $key == 'seed') {
            $where  = ['MONTH(service_date)' => 'MONTH(CURDATE())', 'church_id'=>$this->church];
        }else{
            $where  = ['church_id'=>$this->church];
        }

        if($key == 'first_timers' || $key == 'new_converts' || $key == 'thanksgiving' || $key == 'tithe' || $key == 'offering' || $key == 'seed'){
            $stat       = sum_db($key,$table,$where);
            $fine_stat  = number_format($stat);
        }else {
            $stat       = count_db($key,$table,$where,$group);
            $fine_stat  = number_format($stat);
        }
        return $fine_stat;
    }

    public function church_tab_stats($action,$links){

        $total_attendance_sunday    = $this->church_stats('total_attendance','grow_service_reports','total_attendance');
        $total_sunday_service       = $this->church_stats('service_id','grow_service_reports','service_id');
        $average_attendance         = ($total_sunday_service > 0) ? $total_attendance_sunday/$total_sunday_service : 0;

        $content    = '3,4,5';

        $tab_four   = [
            ['id' => lang('number_members'),            'total_value' => $this->church_stats('church_id','grow_churches','church_id'),          'content' => $content],
            ['id' => lang('number_fellowships'),        'total_value' => $this->church_stats('tag_id','grow_fellowship_reports','','tag_id'),   'content' => $content],
            ['id' => lang('number_givers'),             'total_value' => $this->church_stats('member_id','grow_giving_records','','member_id'), 'content' => $content],
            ['id' => lang('average_sunday_attendance'), 'total_value' => $average_attendance,   'content' => $content]
        ];

        $data['links']          = $links;
        $data['action']         = $action;
        $data['title']          = lang('pastor_dashboard');
        $data['serv_title']     = lang('tab_1_title');
        $data['serv_subtitle']  = lang('tab_1_subtitle');
        $data['content']        = $tab_four;
        $data['content_2']      = $this->monthly_service_stats();
        $data['handle']         = $this->CI->load->view('partials/dashboard/dashboard_template', $data, TRUE);
        $data['scripts']        = $this->CI->load->view('partials/dashboard_script',$data,TRUE);
        $this->CI->load->view('partials/master', $data);
    }

    public function monthly_service_stats(){

        $thanksgiving   = $this->church_stats('thanksgiving', 'grow_service_reports', '');
        $seed_giving    = $this->church_stats('seed', 'grow_service_reports', '');
        $others         = [$thanksgiving, $seed_giving];
        $other_givings  = array_sum($others);

        $content        = '3,4,5,12';

        $month_ch_stats = [
            ['title'=> lang('all_first_timers'),  'figure'=> $this->church_stats('first_timers','grow_service_reports',''),      'content'=>$content],
            ['title'=> lang('all_new_converts'),  'figure'=> $this->church_stats('new_converts', 'grow_service_reports', ''),    'content'=>$content],
            ['title'=> lang('total_tithes'),      'figure'=> $this->church_stats('tithe', 'grow_service_reports', ''),           'content'=>$content],
            ['title'=> lang('total_offering'),    'figure'=> $this->church_stats('offering', 'grow_service_reports', ''),        'content'=>$content],
            ['title'=> lang('other_givings'),     'figure'=> $other_givings,    'content'=>$content]
        ];
        return $month_ch_stats;
    }

}