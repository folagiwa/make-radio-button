<?php
/**
 * Created by PhpStorm.
 * User: grow
 * Date: 08/10/2018
 * Time: 1:01 PM
 */
defined('BASEPATH') OR exit('No direct script access allowed');

class Structures_lib extends Common_lib {

    public function __construct(){
        parent::__construct();
        $this->CI =& get_instance();
        $this->CI->load->model('members_model');
        $this->CI->load->library('form_validation');
        $this->CI->load->library('units_lib');
        $this->CI->load->model('countries_model');
        $this->CI->load->model('cities_model');
        $this->CI->load->model('states_model');
        $this->CI->load->model('tags_model');
        $this->church   = $_SESSION['logged_in']['church_id'];
        $this->member   = $_SESSION['logged_in']['member_id'];
    }

    public function church_units($links){
        $tab = [
            ['id'=>'fellowship',        'label'=> lang('fellowship'), 'content'=>$this->CI->units_lib->fellowships_table(),             'active'=> 'active'],
            ['id'=>'service_dept',      'label'=> 'Service Dept',          'content'=>$this->CI->units_lib->service_departments_table()],
            ['id'=>'adult',             'label'=> 'Adult Group',           'content'=>$this->CI->units_lib->adult_groups_table()],
            ['id'=>'teens',             'label'=> 'Teens Group',           'content'=>$this->CI->units_lib->teens_groups_table()],
            ['id'=>'kids',              'label'=> 'Kids Group',            'content'=>$this->CI->units_lib->kids_groups_table()],
        ];
        $data['sub_title'] = '';
        $data['title'] = 'Church Units';
        $data['content'] = tabbed_feed($tab);
        $data['links'] = $links;
        $data['scripts'] = $this->CI->load->view('scripts_includes/table', $data, TRUE);
        $data['handle'] = $this->CI->load->view('partials/table', $data, TRUE);
        $this->CI->load->view('partials/master', $data);
    }



    public function new_unit($legend, $links, $action){
        if($this->CI->input->post()){

            if($this->CI->input->post('tag_id')){

                $upd = $this->CI->tags_model->from_form(NULL,NULL,array('tag_id'))->update();
                if($upd){
                    $this->CI->session->set_userdata('info', 'Record saved successfully');
                    redirect('organization/new_unit');
                } else{
                    $this->CI->session->set_userdata('error', lang('save_error'));
                    redirect('organization/new_unit');
                }
            } else {

                $insert = $this->CI->tags_model->from_form()->insert();
                if($insert){

                    //TODO: Send mail to leader with login credentials
                    $this->CI->session->set_userdata('info', lang('save_success'));
                    redirect('organization/new_unit');
                } else{
                    $this->CI->session->set_userdata('error', lang('save_error'));
                    redirect('organization/new_unit');
                }
            }
        }
        $session = $this->CI->session->logged_in;
        $church_id = $session['church_id'];
        $data['members'] =  $this->CI->members_model->fields(['member_id','title','surname','first_name'])->where(['church_id'=>$church_id])->get_all();

        if($this->CI->uri->segment(4)){
            $unit_id = cloud_decode($this->CI->uri->segment(4));

            $unit = ask_db('','grow_tags',['tag_id'=>$unit_id]);
            if($unit){
                $data['unit_info'] = $unit;
            }

        }
        $data['sub_title'] = 'Please fill the form below. Fields marked with * are required.';
        $data['title'] = 'New Unit';
        $data['legend'] = $legend;
        $data['action'] = $action;
        $data['links'] = $links;
        $data['form_content'] = $this->CI->load->view('church/new_unit', $data, TRUE);
       // $data['scripts'] = $this->CI->load->view('partials/footer_form_blank',$data,TRUE);
        $data['handle'] = $this->CI->load->view('partials/blank_form', $data, TRUE);
        $this->CI->load->view('partials/master', $data);
    }


}