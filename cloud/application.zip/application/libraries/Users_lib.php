<?php
/**
 * File       : Users_lib.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/20/18
 * Time: 1:05 PM
 */

class Users_lib {

    protected $CI;
    protected $member;
    public function __construct()

    {
        $this->CI =& get_instance();
        $this->CI->load->library('form_validation');
        $this->CI->load->model('users_model');
        $this->CI->load->library('email');
        $this->CI->load->library('mails_lib');
        $this->CI->load->library('payment_lib');

    }

    public function index(){

        if($this->CI->session->logged_in){
            $this->dashboard();
        } else {

            if($this->CI->input->post('login')){

                $this->login();

            } else if($this->CI->input->post('register')){

                $this->signup();

            }else if($this->CI->input->post('forgot')){

                $this->forgot_password();

            } else{

                $this->login();
            }

        }
    }

    public function dashboard(){
        redirect(base_url('dashboard'));
    }

    public function signup(){

        if($this->CI->input->post('register')){
            $this->CI->form_validation->set_rules('surname',    'lang:surname', 'trim|required');
            $this->CI->form_validation->set_rules('first_name', 'lang:first_name', 'trim|required');
            $this->CI->form_validation->set_rules('church_name', 'lang:church_name', 'trim|required');
            $this->CI->form_validation->set_rules('email_address', 'lang:email', 'trim|required|valid_email');
            $this->CI->form_validation->set_rules('church_website', 'lang:church_website', 'trim|required');
            $this->CI->form_validation->set_rules('licence', 'lang:auth_license', 'required');

            if($this->CI->form_validation->run() === FALSE)
            {
                redirect(base_url('/welcome/register'));

            } else {

                //TODO SIGNUP
                $sname   = $this->CI->input->post('surname');
                $fname   = $this->CI->input->post('first_name');
                $cname   = $this->CI->input->post('church_name');
                $email   = $this->CI->input->post('email_address');
                $web     = $this->CI->input->post('church_website');
                $sub     = $this->CI->input->post('subscription_type');

                $check = $this->CI->db->get_where('grow_churches', ['church_website'=>$web]);
                if($check->result_array()){
                    $this->CI->session->set_userdata('error', $this->CI->lang->line('url_exists'));
                    redirect(base_url('/welcome/register'));
                } else {
                    $data = [
                        'surname'           => $sname,
                        'first_name'        => $fname,
                        'email_address'     => $email,
                        'created_at'        => date('Y-m-d H:i:s')
                    ];

                    $a = $this->CI->db->insert('grow_members',$data); // ADD TO GROW_MEMBERS
                    //dump($a);

                    if($a){
                        $member_id = $this->CI->db->insert_id();

                        $church_data = [
                            'church_name'      => $cname,
                            'church_admin'     => $member_id,
                            'church_website'   => $web,
                            'subscription_type'=> $sub,
                            'created_by'       => $member_id,
                            'created_at'       => date('Y-m-d H:i:s')
                        ];

                        $b = $this->CI->db->insert('grow_churches',$church_data); // ADD TO GROW CHURCHES

                        if($b){
                            $church_id = $this->CI->db->insert_id();
                            $_SESSION['church_id'] = $church_id;
                            $random = random_val();

                            $user_data = [
                                'church_id'     => $church_id,
                                'member_id'     => $member_id,
                                'username'      => $email,
                                'is_admin'      => '1',
                                'random_key'    => $random,
                                'created_by'    => $member_id,
                                'created_at'    => date('Y-m-d H:i:s')
                            ];
                            $c = $this->CI->db->insert('grow_users',$user_data); // ADD TO GROW USERS
                            //dump($user_data);

                            if($c){
                                $user_id = $this->CI->db->insert_id();
                                $upd = [
                                    'created_by'        => $member_id,
                                    'church_id'         => $church_id
                                ];
                                $this->CI->db->where(['email_address'=>$email]);
                                $d = $this->CI->db->update('grow_members', $upd);

                                if($d){
                                    $signup = [
                                        'user_id'           =>$user_id,
                                        'church_id'         =>$church_id,
                                        'church_name'       =>$cname,
                                        'surname'           =>$sname,
                                        'first_name'        =>$fname,
                                        'email_address'     =>$email,
                                        'church_website'    =>$web,
                                        'created_by'        =>$member_id,
                                        'created_at'    => date('Y-m-d H:i:s')

                                    ];

                                    $e =  $this->CI->db->insert('grow_signup',$signup); // ADD TO GROW SIGNUP
                                    if($e){

                                        $param = [
                                            'name'=> $fname . ' ' . $sname,
                                            'web'=>$web,
                                            'random'=>$random,
                                            'email'=>$email
                                        ];

                                        if($sub == 'trial'){
                                            $f = $this->CI->mails_lib->new_user($fname.' '.$sname, $email, $web, $random);

                                            if($f){
                                                $this->CI->session->set_userdata('info','You have been registered successfully. Please check your mailbox.');
                                                redirect(base_url());
                                                return true;
                                            }
                                        } else {
                                            $_SESSION['mail'] = $param;
                                            $payment = $this->CI->payment_lib->payWithPaystack($sub, $email);
                                        }



                                    }

                                }
                            }
                        }
                    }
                }


            }
        }

        $this->CI->load->view('partials/signup');

    }



    public function activate_user(){
        $a = $this->CI->uri->segment(3);
//        dump(cloud_decode($a));
        if($a){
            $b = $this->CI->db->get_where('grow_users',['random_key'=>cloud_decode($a)]);
            if($b->result_array()){

                $c = $b->result_array()[0];
//                dump($c);

                if($this->CI->input->post('set_password')){

                    $this->CI->form_validation->set_rules('password', 'lang:password', 'trim|required|min_length[8]|matches[confirm_password]');
                    $this->CI->form_validation->set_rules('confirm_password', 'lang:confirm_password', 'trim|required|matches[password]');

                    if($this->CI->form_validation->run() === FALSE){
                        $this->CI->load->view('partials/new_password');

                    } else {

                        $password           = $this->CI->input->post('password');


                        $upd = [
                            'password'      => password_hash($password, PASSWORD_DEFAULT),
                            'active'        => '1',
                            'random_key'    => ''
                        ];

                        $this->CI->db->where(['user_id'=>$c['user_id']]);
                        $d = $this->CI->db->update('grow_users', $upd);

                        if($d){
                            //Todo welcome email
                            $e = $this->CI->db->get_where('grow_members',['member_id'=>$c['member_id']]);
                            if($e->result_array()){
                                $f = $e->result_array()[0];
                                $g = $this->CI->mails_lib->welcome_user($f['first_name'].' '.$f['surname'], $f['email_address']);
                                if($g) {
                                    $this->CI->session->set_userdata('logged_in', $c);
                                    unset($_SESSION['logged_in']['password']);
                                    unset($_SESSION['logged_in']['random_key']);

                                    $this->CI->session->set_userdata('info', 'Welcome to Grow Cloud');
                                    redirect(base_url('dashboard'));
                                }
                            }



                        }

                    }
                }

                $this->CI->load->view('partials/new_password');

            } else{
                echo 'no';
            }

        } else {
            show_404();
        }
    }



    public function logout()
    {
        if(isset($_SESSION['logged_in'])){
            $this->CI->session->unset_userdata('logged_in');

            session_destroy();
        }

        redirect(base_url(), 'refresh');
    }

    public function login(){
        if(isset($this->CI->session->logged_in)){

            $this->dashboard();

        } else {

            //TODO: Login validation
            //$this->CI->load->view('partials/login');
            $this->CI->form_validation->set_rules('username','lang:auth_username','trim|required|valid_email');
            $this->CI->form_validation->set_rules('password','lang:auth_password','trim|required');

            if($this->CI->form_validation->run() === FALSE){
                $this->CI->load->view('partials/login');
            } else {

                    $username  = $this->CI->input->post('username');
                    $password  = $this->CI->input->post('password');
                $a = $this->CI->db->get_where('grow_users',['username'=>$username]);
                if($a->result_array()){
                    $b = $a->result_array()[0];
//                    dump($b);
                    if(password_verify($password,$b['password'])){
                        $c = $this->CI->db->get_where('grow_churches',['church_id'=>$b['church_id']]);
                        if($c->result_array()){
                            $church = $c->result_array()[0];
                            $website = $church['church_website'];
                            if($website == extract_domain()){
                                $this->CI->session->set_userdata('logged_in',$b);
                                unset($_SESSION['logged_in']['password']);
                                $this->dashboard();
                            } else{
                                $this->CI->session->set_userdata('error', $this->CI->lang->line('wrong_url'));
                                $this->CI->load->view('partials/login');
                            }
                        } else{
                            $this->CI->session->set_userdata('error', $this->CI->lang->line('wrong_url'));
                            $this->CI->load->view('partials/login');
                        }


                    } else {
                        $this->CI->session->set_userdata('error', $this->CI->lang->line('password_incorrect'));
                        $this->CI->load->view('partials/login');
                    }
                } else{
                    $this->CI->load->view('partials/login');
                }
            }
        }

    }

    public function forgot_password(){
        $this->CI->form_validation->set_rules('username','lang:auth_username', 'trim|required|valid_email');

        if($this->CI->form_validation->run() === FALSE)
        {
            redirect(base_url(''),'refresh');

        } else {
            //TODO FORGOT PASSWORD


        }

    }




}