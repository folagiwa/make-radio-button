<?php
if( defined(BASEPATH)) exit('No direct access script allowed');

/**
 * File       : MY_Controller.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/10/18
 * Time: 3:08 PM
 */

class MY_Controller extends CI_Controller {

    function __construct()
    {
        parent::__construct();
        $this->lang->load('general', detect_language());
        $this->lang->load('menu',$this->session->language);
        $this->load->model('states_model');
        $this->load->model('cities_model');



        ENVIRONMENT != 'development' || $this->output->enable_profiler(TRUE);
        // ENVIRONMENT != 'testing' || $this->output->enable_profiler(TRUE);


    }
}