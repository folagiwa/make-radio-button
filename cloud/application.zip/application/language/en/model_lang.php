<?php
/**
 * File       : model_lang.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/10/18
 * Time: 6:55 PM
 */


//members_model_language

$lang["title"]                       = "Title";
$lang["surname"]                     = "Surname";
$lang["first_name"]                  = "First name";
$lang["birth_date"]                  = "Date of birth";
$lang["gender"]                      = "Gender";
$lang["phone_mobile_primary"]        = "Primary phone";
$lang["phone_mobile_secondary"]      = "KingsChat";
$lang["phone_home"]                  = "Home";
$lang["phone_office"]                = "Office Phone";
$lang["email_adress"]                = "Email address";
$lang["country"]                     = "Country";
$lang["state"]                       = "State";
$lang["city"]                        = "City";
$lang["address"]                     = "Address";
$lang["nearest_landmark"]            = "Nearest landmark";
$lang["marital_status"]              = "Marital status";
$lang["edu_level"]                   = "Education level";
$lang["profession"]                  = "Profession";
$lang["present_occupation"]          = "Present occupation";
$lang["spouse"]                      = "Spouse";
$lang["no_children"]                 = "Number of children";
$lang["first_day_in_church"]         = "First day in Church";
$lang["invited_by"]                  = "Invited By";
$lang["prayer_request"]              = "Prayer request";
$lang["visit_time"]                  = "Visiting time";
$lang["cell_assigned"]               = "Cell assigned";
$lang["foundation_school_status"]    = "Foundation school";
$lang["is_new_convert"]              = "Is first timer new convert";
$lang["is_baptised"]                 = "Is first timer baptised";
$lang["record_type"]                 = "Record type";
$lang["lmc_status"]                  = "Lmc Status";
$lang["member_picture"]              = "Member Picture";

$lang['mobile_phone']                = 'Mobile Phone';



//products Language
$lang['product_name']                = 'Product Name';
$lang['product_description']         = 'Product Description';
$lang['product_img']                 = 'Product Image';
$lang['product_price']               = 'Product Price';
$lang['product']                     = 'product';
$lang['product_category']            = 'Product Category';

 //Products categories
$lang['product_category_name']       = 'Product Category Name';
$lang['product_category']            = 'Product Category';


//order items model
$lang['product_quantity']            = 'Product Quantity';
$lang['order']                       = 'Order';
$lang['product']                     = 'Product';
$lang['order_items']                 = 'Order items';

//product orders
$lang['order_date']                  = 'Order Date';
$lang['order_total']                 = 'Order Total';
$lang['order_id']                    = 'Order';


//Service Report Model

$lang['service_date']                = 'Service Date';
$lang['service_type']                = 'Service Type';
$lang['attendance_kids']             = 'Attendance kids';
$lang['attendance_teens']            = 'Attendance Teens';
$lang['attendance_adults']           = 'Attendance Adults';
$lang['first_timers']                = 'First Timers';
$lang['new_converts']                = 'New Converts';
$lang['offering']                    = 'Offering';
$lang['tithe']                       = 'Tithe';
$lang['seed']                        = 'Seed';
$lang['thanksgiving']                = 'Thanksgiving';
$lang['created_by']                  = 'Created_by';
$lang['service']                     = 'Service';




//end of Serevice Report model

//state model
$lang['state_name']                  = 'State Name';
$lang['state']                       = 'State';

//Station Contracts Model

$lang['start_date']                  ='Start Date';
$lang['end_date']                    = 'End Date';
$lang['contract']                    = 'Contract';
$lang['created_by']                  = 'Created By';

//Stations model
$lang['service_name']                = 'Service Name';
$lang['station_type']                = 'Station Type';
$lang['station_tel']                 = 'Station Tel';
$lang['station_contact_person']      = 'Station Contact Person';
$lang['station_address']             = 'Station Address';
$lang['station_country']             = 'Station Country';
$lang['station']                     = 'Station Country';



//user_privileges_model
$lang['function_name']               = 'Function Name';
$lang['privilege']                   = 'Privilege';
$lang['function']                    = 'Function';

//users_model
$lang['username']                    = 'Username';
$lang['password']                    = 'Password';
$lang['retype_password']             = 'Retype Password';
$lang['active']                      = 'Active';
$lang['is_admin']                    = 'Is Admmin';
$lang['user_scope']                  = 'User Scope';
$lang['random_key']                  = 'Random Key';
$lang['user_roles']                  = 'User Roles';
$lang['member']                      = 'Member';

//regions model
$lang['region']                      = 'Region';
$lang['region_directorate']          = 'Region directorate';
$lang['regional_pastor']             = 'Regional Pastor';
$lang['regional_admin']              = 'Regional Admin';
$lang['region_name']                 = 'Region Name';
$lang['address']                     = 'Address';
$lang['regional_desc']               = 'Regional Admin';
$lang['region_name']                 = 'Region Name';



//senior cell leaders model

$lang['pcf']                         = 'PCF';
$lang['senior_cell_name']            = 'Senior Cell Name';
$lang['senior_cell_leader']          = 'Senior Cell Leader';
$lang['senior_cell_email']           = 'Senior Cell Email';



//Zones model
$lang['region']                      = 'Regions';
$lang['zone']                        = 'Zone';
$lang['zone_name']                   = 'Zone Name';
$lang['zone_type']                   = 'Zone Type';
$lang['zonal_pastor']                = 'Zonal Pastor';
$lang['zonal_admin']                 = 'Zonal Admin';
$lang['zone_office_address']         = 'Zone Office Address';
$lang['zone_phone']                  = 'Zone Phone';
$lang['zone_desc']                   = 'Zone Description';
$lang['created_by']                  = 'Created By';



//giving category
$lang["giving_category"]             = "Giving category";
$lang["church_name"]                 = "Church name";
$lang["group_name"]                  = "Group name";
$lang["category_name"]               = "Category name";
$lang["giving_category_description"] = "Category description";
$lang["created_by"]                  = "Created by";

//records lang
$lang["record_date"]                 = "Given On";
$lang["currency_code"]               = "Currency";
$lang["giving_amount"]               = "Amount";
$lang["citation"]                    = "Citation";

//group_churches_language
$lang["group_pastor"]                = "Group pastor";
$lang["group_admin"]                 = "Group administrator";
$lang["group_description"]           = "Group description";



//orders_language
$lang["order_date"]                  = "Order date";
$lang["order_total"]                 = "Order total";

//outreach_event
$lang["church_name"]                 = "Church Name";
$lang["event_scope"]                 = "Event Scope";
$lang["event_location"]              = "Event Location";
$lang["event_start"]                 = "Event-Start";
$lang["event_end"]                   = "Event-End";
$lang["event_frequency"]             = "Event Frequency";
$lang["event_time"]                  = "Event Time";
$lang["event_custom"]                = "Event Custom";


//partnership_language
$lang["partnership_name"]            = "Partnership Name";
$lang["partnership_description"]     = "Partnership Description";

//partnership_records_language
$lang["partnership_arm_name"]        = "Partnership Arm Name";
$lang["currency_name"]               = "Currency Name";
$lang["partnership_amount"]          = "Partnership Amount";

//pcd_language
$lang["sacrament_date"]              = "Sacrament Date";
$lang["total_number"]                = "Total Number";
$lang["sacrament_type"]              = "Sacrament Type";
$lang["comments"]                    = "Comments";

//grow_pcf language
$lang["pcf_name"]                    = "Pcf Name";
$lang["pcf_leader"]                  = "Pcf Leader";
$lang["pcf_email"]                   = "Pcf Email";
$lang["pcf_scope"]                   = "Pcf Scope";


//cell_attendance
$lang['cell_attendance_register']    = 'Cell Attendance Register';
$lang['week number']                 = 'Week number';
$lang['cell']                        = 'cell';
$lang['total_members']               = 'Total Members';
$lang['mid_week_service_attendance'] = 'Midweek Service attendance';
$lang['weekend_service_attendance']  = 'Weekend service attendance';
$lang['cell_meeting_attendance']     = 'Cell meeting attendance';


//cell_first_timers
$lang['cell_first_timers']           = 'Cell first timers';
$lang['date_in_meeting']             = 'Date in meeting';


//cell_outline
$lang['cell_outline']                = 'Cell Outline';
$lang['file_name']                   = 'File name';
$lang['description']                 = 'Description';

//cell_reports
$lang['report']                      = 'Report';
$lang['activity_date']               = "Activity Date";
$lang['activity_type']               = "Activity type";
$lang['first_timers']                = 'First Timers';
$lang['new_converts']                = 'New converts';
$lang['offering']                    = 'Offering';

//cell_role
$lang['cell_role']                   = 'Cell role';
$lang['designation']                 = 'Designation';
$lang['appointed_date']              = 'Appointed On';

//cells table
$lang['cell']                        = 'cellule';
$lang['pcf']                         = 'PCF';
$lang['senior_cell']                 = 'Senior Cell';
$lang['cell_name']                   = 'Cell name';
$lang['cell_leader']                 = 'Cell leader';
$lang['cell_address']                = 'Cell Address';


//churches
$lang['city']                        = 'City';
$lang['state']                       = 'State';
$lang['country']                     = "Country";
$lang['currency']                    = 'Currency';

//cities
$lang['church']                      = 'Church';
$lang['church_pastor']               = "Church Pastor";
$lang['church_admin']                = "Church Admin";
$lang['church_description']          = "description de l'église";
$lang['longitude']                   = "Longitude";
$lang['lattitude']                   = "Lattitude";

//countries


//follow_up_report
$lang['follow_up_report']           = 'Follow up report';
$lang['report_date']                = 'Report date';
$lang['remarks']                    = 'Remarks';


///pasted
///



