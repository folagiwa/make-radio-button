<?php
/**
 * File       : general_lang.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/8/18
 * Time: 6:29 PM
 */


//login language
$lang["auth_username_required"] = "Username is required";
$lang["auth_password_required"] = "Password is required";
$lang['auth_username']          = "Username";
$lang['auth_password']          = "Password";
$lang["auth_authorize"]         = "Authorize to proceed";
$lang["auth_lang_choose"]       = "Choose Language";
$lang["auth_detected"]          = "Default";
$lang["auth_forgot"]            = "Forgot username or password";
$lang["auth_signin"]            = "Sign In";
$lang["password_sent"]          = "Kindly login to your email for your password.";
$lang["create_account"]         = "Create an account";
$lang['auth_account']           = "Already have an account?";

$lang['surname']                = "Surname";
$lang['first_name']             = "Firstname";
$lang['church_name']            = "Church Name";
$lang['username']               = "Username";
$lang['password']               = "Password";
$lang['church_website']         = "Church Website";
$lang['licence']                = "Accept the license agreement";
$lang['forgot']                 = "Forgot password?";
$lang['forgot_msg']             = "Kindly enter your email to reset your password";
$lang['email']                  = "Email Address";

$lang['legend_im']              = "Download,populate it and upload it back";

$lang['auth_confirm_password']  = "Confirm Password";

$lang['new_account_email']      = "New Account Email";
$lang['new_acc_legend']         = 'Kindly find below for the your login credentials to the Grow Cloud. It is for managing ministry information for growth as it relates to you. You may reply to this email for further clarification.';
$lang['signup_legend']          = 'Welcome to Grow Cloud. Kindly click on the link below to activate your account. This software is used for managing ministry information for growth as it relates to your church. You may reply this email for further clarification.';
$lang['address']                = 'Address';
$lang['salutation']             = 'Dear';

$lang['grow_cloud_welcome']     = 'Welcome to Grow Cloud';


$lang['disclaimer']             = 'This email is confidential and is intended solely for the stated recipient(s). If you are not the intended recipient tell the sender immediately and destroy this email without using, sending or storing it. Sender does not accept liability for damage caused by this email';

$lang['password_incorrect']     = 'Password incorrect';
$lang['wrong_url']              = 'Check your site URL.';
$lang['url_exists']             = 'Sorry this site name has been taken.';
$lang['welcome_email']          = 'Welcome Email';
$lang['welcome_legend']         = 'Welcome to Grow Cloud. Kindly find below your login details and your customised url.You may reply this email for further clarification.';
$lang['url']                    = 'URL';
$lang['service_date']           = 'Date';
$lang['attendance_adults']           = 'Attendance_adults';
$lang['how_it_works']           = 'How it works';
$lang['submit']                 = 'Submit';

$lang['no_label']               = 'No label passed';
$lang['attendance_adults']      = 'Attendance adults';
$lang['birth_date']             = 'Birth date';
$lang['dates']                  = 'Pick a date';
$lang['date']                   = 'eg: 23/05/2014';
$lang['male']                   ='Male';
$lang['female']                 ='Female';
$lang['gender']                 ='Gender';


//Members
$lang['title']                  = 'Title';
$lang['rev']                    = 'Rev';
$lang['pastor']                 = 'Pastor';
$lang['deacon']                 = 'Deacon';
$lang['deaconess']              = 'Deaconess';
$lang['brother']                = 'Brother';
$lang['sister']                 = 'Sister';
$lang['prophet']                = 'Prophet';
$lang['evangelist']             = 'Evangelist';
$lang['elder']                  = 'Elder';
$lang['none']                   = 'None';
$lang['mobile_phone']           = 'Mobile phone';
$lang['single']                 = 'Single';
$lang['married']                = 'Married';
$lang['widowed']                = 'Widowed';
$lang['marital_status']         = 'Marital Status';
$lang['email_address']          = 'Email Address';
//$lang['work_phone']             = 'Work phone';
$lang['home_address']           = 'Home Address';
$lang['format']                 = 'eg: 000-00-000000';
$lang['group_assign']           = 'Group assign';
$lang['assign_later']           = 'Assign later';
$lang['usher']                  = 'Usher';
$lang['choir']                  = 'choir';
$lang['set_location']           = 'Set Location';
$lang['update_record']          = 'Update record';
$lang['new_record']             = 'New record';
$lang['cancel']                 = 'Cancel';
$lang['country']                = 'Country';
$lang['state']                  = 'State';
$lang['city']                   = 'City';
$lang['no_record']              = 'No record';
$lang['somebody']               = 'Somebody';
$lang['anybody']                = 'Anybody';
$lang['invited_by']             = 'Invited by';
$lang['invited_by']             = 'Invited by';
$lang['member']                 = 'Member';
$lang['member_picture_upload']  = 'Member picture';
$lang['first_timer']            = 'First timer';
$lang['full_name']              = 'Full name';
$lang['import_members']         = 'Import member(s)';
$lang['download_template']      = 'Download template';
$lang['no_file']                = 'No file';
$lang['yes']                    = 'Yes';
$lang['no']                     = 'No';


$lang['leader']                 = 'Leader';
$lang['cell_phone']             = 'Cell Phone';
$lang['mobile_phone']           = 'Mobile Phone';

$lang['unit_name']              = 'Unit Name';
$lang['unit_leader']            = 'Unit Leader';
$lang['kids_group']             = 'Kid\'s Group';
$lang['teens_group']            = 'Teens Group';
$lang['adult_group']            = 'Adult Group';
$lang['service_department']     = 'Service Department';
$lang['house_fellowship']       = 'House Fellowship';
$lang['unit_type']              = 'Unit Type';
$lang['unit_email']             = 'Unit\'s Email Address';
$lang['enter_email']            = 'Enter Email Address';
$lang['save_success']           = 'Record has been saved successfully';
$lang['save_error']             = 'Unable to save data. Please try again';




//form
$lang['how_it_works']           = 'How it works';

$lang['how_it_works_speech']    = "<li>The system expects report date to either be a Sunday or a Wednesday.</li>
                    <li>All other services saved are kept for local reference and can always be accessed at service reports</li>
                    <li>Data entered into this form cannot be altered after three months.</li>
                    <li>This report will be used for monthly, half year and annual reports.</li>
                    <li>A copy of this report is available to the church, the group, the zone and the region.</li>
                    <li>The report will be saved and indicated on the dashboard calendar in green.</li>";

$lang['options_how_it_works']    = "<li>The tick boxes at the right side menu contains the all the field sections for the form being displayed.</li>
                    <li>You will have to tick the boxes of the fields you want to fill</li>
                    <li>Please we also advise you tick all the boxes and fill every field in the form, for accurate data</li>";

$lang['fill_form_instruction']          = 'Fill the form to create or update a record. All fields marked * are required. You can enter 0 where field is empty';
$lang['select_service_date']            = 'Select service date';
$lang['attendance_kids']                = 'Kids\' Attendance';
$lang['attendance_teens']               = 'Teenagers\' Attendance';
$lang['attendance_adults']              = 'Adults\' Attendance';
$lang['attendance_first_timers']        = 'First Timers\' Attendance';
$lang['attendance_new_converts']       = 'New Converts\' Attendance';
$lang['offering']                       = 'Offering ';
$lang['tithe']                          = 'Tithe ';
$lang['seed']                           = 'Seed ';
$lang['thanksgiving']                   = 'Thanksgiving ';
$lang['remarks_long']                   = 'Remarks: Please type on the line';
$lang['remarks']                        = 'Remarks';
$lang['remaining']                      = 'Remaining ';
$lang['select_service_type']            = 'Select service type ';
$lang['latest_records']                 = 'Latest records';


//content titles
$lang['outreaches_sec']         = 'Outreaches\' section ';
$lang['trending']               = 'Trending';
$lang['all_about_cloud']        = 'About Us';
$lang['key_features']           = 'Key Features';
$lang['features_speech']        = "<p>Grow Cloud empowers a Church Pastor with a 360 degree view of the activities within the church for effective monitoring and arms the Pastor with prompt and accurate data for accurate decision making planning</p>
                                <p>Grow was also designed to be compliant with the recently introduced Data Protection and Privacy laws.</p>";
$lang['about_speech']           = "<p>Grow is the next generation church management software designed for spiritual, numerical and financial growth. The software effectively models the mordern Church's structure; from the church pastor to the member.</p>
                                <p>Through the use of highly effective and custom-built data capture, data analysis, forecasting tools, Grow provides a Fellowship Leader, Senior Fellowship Leader, Group Leader, Church Pastor with all the requirements, tools and features to effectively monitor and grow his Fellowship, Senior Fellowship, Group and Church.</p>";
$lang['welcome']                = 'welcome';
$lang['submit_new']             = 'Submit New';
$lang['submit_exit']            = 'Close';
$lang['submit']                 = 'Submit';
$lang['cancel']                 = 'Cancel';

//service_report
$lang['update_service_report']  = 'Update Service Report Record';
$lang['new_service_report']     = 'New Service Report Record';
$lang['service_report_sec']     = 'Service Report Section';
$lang['weekend']                = 'Weekend';
$lang['mid_week']               = 'Mid week';
$lang['communion']              = 'Communion';
$lang['outreach']               = 'Outreach';
$lang['day_ago']                = ' day(s) ago';
$lang['month_ago']              = ' month(s) ago';
$lang['year_ago']               = ' year(s) ago';
$lang['minute_ago']             = ' minute(s) ago';
$lang['hour_ago']               = ' hour(s) ago';

//tables
$lang['table_service_report']   = 'Service Report Table';
$lang['sub_title_write_up']     = 'List of all service reports submitted in the Church';
$lang['list']                   = ' List';
$lang['service_date']           = 'Service Date';
$lang['service_type']           = 'Service Type';
$lang['total_attendance']       = 'Total Attendance';
$lang['first_timers']           = 'First Timers\'';
$lang['new_converts']           = 'New Converts';
$lang['manage']                 = 'Manage';
$lang['no_record']              = 'No records set';
$lang['print_text']             = 'Grow Cloud Print';

//giving
$lang['add_giving_category']         = 'Add new giving category';
$lang['category_name']               = 'Category Name';
$lang["giving_category"]             = "Giving category";
$lang["church_name"]                 = "Church name";
$lang["group_name"]                  = "Group name";
$lang["category_name"]               = "Category name";
$lang["giving_category_description"] = "Category description";
$lang["giving_citation"]             = "Giving Citation";
$lang['giving_record_list']          = "Giving record Lists";
$lang['new_giving_record']           = "New Giving Record";
$lang['new_giving']                  = "New giving";

$lang['purpose']                     = "Purpose Of giving";
$lang["record_date"]                 = "Given On";
$lang["currency_code"]               = "Currency code";
$lang["currency"]                    = "Select Currency";
$lang["giving_amount"]               = "Amount";
$lang['giving_purpose']              = "Purpose of giving";
$lang['full_name']                   = "Full Name";
$lang["citation"]                    = "Citation";

//dashboard
$lang["contact_info"]                = "Contact Information";
$lang["get_back_to_you"]             = "This is your Church's contact details everybody sees";
$lang["number_members"]              = "No. of members";
$lang["number_fellowships"]          = "Active fellowships";
$lang["number_givers"]               = "No. of givers";
$lang["average_sunday_attendance"]   = "Avg Sunday service attendance";
$lang["pastor_dashboard"]            = "Pastor's Dashboard";
$lang["dashboard_graph_title"]       = "Church Members Service Attendance Time";
$lang["dashboard_graph_subtitle"]    = "Weekly church service attendance time";
$lang["tab_1_title"]                 = "Service Report Stats";
$lang["tab_1_subtitle"]              = "Cumulative figures for the past 30 days (weekly graph)";
$lang["all_first_timers"]            = "All first timers";
$lang["all_new_converts"]            = "All new converts";
$lang["total_tithes"]                = "Total tithes";
$lang["total_offering"]              = "Total offering";
$lang["other_givings"]               = "Other givings";




