<?php
/**
 * File       : menu_lang.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/10/18
 * Time: 10:38 AM
 */

$lang['organization']            = 'Organization';
$lang['send_account_email']      = 'Send login access credentials';
$lang['church_units']            = 'Church Units';
$lang['unit_leaders']            = 'Unit leaders';
$lang['new_unit']                = 'New Unit';

$lang['dashboard']               = "Dashboard";
$lang['church_growth']           = "Church Growth";
$lang['attendance']              = "Attendance";
$lang['financial']               = "Financial";
$lang['new_converts']            = "New Convert";
$lang['first_timers']            = "First Timers";

$lang['fellowship']              = "Fellowship";
$lang['overview']                = "Overview";
$lang['fellowship_reports']      = "Fellowship Reports";
$lang['manage_group']            = "Manage Groups";
$lang['fellowship_outline']      = "Fellowship Outline";
$lang['group_leaders']           = "Group leaders";
$lang['growth_history']          = "Growth History";
$lang['members_missing_church']  = "Members Missing Church";
$lang['fellowship_report']       = "Fellowship Report";
$lang['members_missing_cell_meeting'] = "Members Missing Cell Meeting";

$lang['first_timers'] = "First Timers";
$lang['add_first_timers'] = "Add First Timers";
$lang['manage_first_timers'] = "Manage First Timers";
$lang['manage_follow_up_reports'] = "Manage Follow up Reports";
$lang['soul_winners'] = "Soul Winners";
$lang['retention_ratio'] = "First timers Retention";
$lang['distribution_by_city'] = "Distribution by City";
$lang['first_timer_sources'] = "First Timer Sources";
$lang['first_timer_reports'] = "First Timer Reports";

$lang['members']                         = "Members";
$lang['new_member']                      = "Add a member";
$lang['member_list']                     = "Members List";
$lang['birthdays']                       = "Birthdays";
$lang['member_profile']                  = "Member Profile";
$lang['import_members']                  = "Import Members";
$lang['growth_report']                   = "Growth Report";
$lang['growth_summary']                  = 'Members finance';

$lang['partnership'] = "Partnership";
$lang['reports'] = "Report";
$lang['administrators'] = "Administrators";
$lang['pledges'] = "Pledges";
$lang['pledges_redeem_rate'] = "Pledges Redeem Rate";
$lang['manage_birthday_greetings'] = "Manage Birthday Greetings";
$lang['individual_reports'] = "Individual Reports";
$lang['partnership_report_for_all_arms'] = "Partnership Report for all Arms";
$lang['consistent_partners'] = "Consistent Partners";
$lang['annual_report'] = "Annual Report";

$lang['outreaches'] = "Outreaches";
$lang['manage_souls'] = "Manage Souls";
$lang['import_souls'] = "Import Souls";
$lang['tv_radio'] = "TV Radio";
$lang['media_feedback'] = "Media Feedback";
$lang['impact_report'] = "Impact Report";
$lang['events']         = 'Events';

$lang['records'] = "Giving Records";
$lang['categories'] = "Categories";
$lang['administration'] = "Administration";
$lang['reminders'] = "Reminders";
$lang['giving_reports'] = "Giving Reports";

$lang['accounts'] = "Accounts";
$lang['settings'] = "Settings";
$lang['users'] = "Users";


$lang['users'] = "Users";
$lang['managing_messages'] = "Managing Messages";
$lang['system_log'] = "System Log";

$lang['reports'] = "Report";
$lang['monthly_report'] = "Monthly Report";
$lang['quarterly_report'] = "Quarterly";
$lang['half_year_report'] = "Half Year Report";
$lang['annual_report'] = "Annual Report";
$lang['custom_report'] = "Custom Report";

$lang['evangelism']="Evangelism";
$lang['events'] = "Events";
$lang['manage_souls'] = "Manage Souls";
$lang["import_souls"] = "Import Souls";
$lang["tv_radio"] = "TV Radio";
$lang["media_feedback"] = "Media Feedback";
$lang["impact_report"] = "Impact Report";

$lang['giving'] = "Giving";
$lang['overview'] = "Overview";
$lang['record'] = "Record";
$lang['categories'] = "Add new Category";
$lang['pledges'] = "Pledges";
$lang['administration'] = "Administration";
$lang['reminders'] = "Reminders";
$lang['member_not_giving'] = "Member not Giving";
$lang['giving_report'] = "Giving Report";

$lang['accounts'] = "Account";
$lang['settings'] = "settings";
$lang['users'] = "Users";
$lang['profile'] = "Profile";
$lang['logout'] = "Logout";
$lang['sign_out'] = "Sign out";

$lang['messaging'] = "Messaging";
$lang['manage_messages'] = "Manage Messages";
$lang['system_log'] = "System Log";
$lang['report'] = "Report";
$lang['monthly_report'] = "Monthly Report";
$lang['quaterly_report'] = "Quarterly Report";
$lang['mid_year_report'] = "Mid Year Report";
$lang['annual_report'] = "Annual Report";
$lang['custom_report'] = "Custom Report";

$lang['service_report'] = 'Service Report';
$lang['submit_reports']     = 'Submit service report';
$lang['service_reports']   = 'Service reports';







