<?php
/**
 * ------------------------------------------------------- *
 * File         : new_giving
 * Created for  : PROJECT GROW.
 * @Author      : Aruleba Segun
 * @Email       : segunaruleba@loveworld360.com
 * @Kingschat   : +2348121724280
 * Date         : 09/30/17
 * Time         : 10:55 AM
 * ------------------------------------------------------- *
 */
//default values for hidden fields
$this->CI =& get_instance();
$church = $this->session->logged_in['church_id'];

if(isset($success)){
if($success == TRUE){

}
}
$form_data = [];

if(is_array($giving_record_info)){
    $data = $giving_record_info;

} else {

    $data = [
        'record_id'       => '',
        'record_date'     => '',
        'church_id'       => $church,
        'giving_cat_id'   => '',
        'currency_id'     => '',
        'member_id'       => '',
        'giving_amount'   => '',
        'giving_citation' => '',
        'created_by'      => '',


    ];
}
$form_a = [

    [
        'name'  => 'record_id',
        'class' => 'form-control',
        'id'    => 'record_id',
        'type'  => 'hidden',
        'value' => $data['record_id'],

    ],

    [
        'name'  => 'church_id',
        'class' => 'form-control',
        'id'    => 'church_id',
        'type'  => 'hidden',
        'value' => $data['church_id'],
    ],


];
echo make_form($form_a);

$label_givers =['category_name'];

if(isset($giving_category[0]['category_name']) !=''){

    echo make_drop('giving_cat_id',lang('category_name'),$giving_category,'giving_cat_id',$label_givers,$data['giving_cat_id']);
} else {
    echo anchor("/giving/create_a_giving_category",lang('new_giving_cat'));
}
echo make_drop('currency_id',lang('currency'),$currency_id,'currency_code','currency_name',$data['currency_id']);

$label_member = ['title','surname','first_name'];

echo make_drop('member_id',lang('member'),$members,'member_id', $label_member,$data['member_id']);

$form_c = [
    [

        'name'  => 'record_date',
        'label' => $this->lang->line('record_date'),
        'class' => 'form-control date-picker flatpickr-input ',
        'placeholder'   =>  $this->lang->line('record_date'),
        'id'    => 'record_date',
        'type'  => 'text',
        'value' => $data['record_date'],
        'required'  =>  'required'
    ],

    [
        'name'  => 'giving_amount',
        'label' => $this->lang->line('giving_amount'),
        'class' => 'form-control form-control-lg',
        'placeholder' => $this->lang->line('giving_amount'),
        'id'    => 'giving_amount',
        'type'  => 'text',
        'value' => $data['giving_amount'],
        'required'  =>  'required'
    ],

    [
        'name'      =>  'created_by',
        'label'     =>  lang('created_by'),
        'class'     =>  'form-control form-control-sm',
        'id'        =>  'created_by',
        'type'      =>  'hidden',
        'value'     =>  $data['created_by'],
        'required'  =>  'required'
    ]


];
echo make_form($form_c);

//echo make_form($form_c);
$form_b = [
    [
        'name'     => 'giving_citation',
        //'label'    => $this->lang->line('giving_citation'),
        'class'    => '',
        'placeholder' => $this->lang->line('giving_citation'),
        'remaining'     =>  $this->lang->line('remaining'),
        'id'       => 'giving_citation',
        'type'     => 'text',
        'value'    => $data['giving_citation'],
        'require'  => 'required'
    ],

];
echo make_text($form_b);


//echo form_default();

?>



