<?php
/**
 * ------------------------------------------------------- *
 * File         : new_giving_category.php.v.1.0
 * Created for  : PROJECT GROW.
 * @Author      : Segun Aruleba
 * @Email       : segunaruleba@loveworld360.com
 * @Kingschat   : +2348121724280
 * Date         : 8/02/17
 * Time         : 9:50 AM
 * ------------------------------------------------------- *
 */

$church = $this->session->logged_in['church_id'];

$form_data = [];
if(is_array($giving_cat)){
    $data = $giving_cat;

} else {
    $data = [
        'giving_cat_id'          => '',
        'church_id'              => $church,
        'category_name'          => '',
//        'giving_cat_description' => '',
//        'classification'         => '',
//        'begin_date'             => '',
//        'end_date'               => '',
        'created_by'             => ''

    ];
}

$form_a = [

    [
        'name'  => 'giving_cat_id',
        'class' => 'form-control input-transparent',
        'id'    => 'giving_cat_id',
        'type'  => 'hidden',
        'value' => $data['giving_cat_id']
    ],

    [
        'name'  => 'church_id',
        'class' => 'form-control',
        'id'    => 'church_id',
        'type'  => 'hidden',
        'value' => $data['church_id']
    ],

    [
        'name'          => 'category_name',
//        'label'         => $this->lang->line('category_name'),
        'class'         => 'form-control input-transparent',
        'placeholder'   =>  $this->lang->line('category_name'),
        'id'            => 'category_name',
        'type'          => 'text',
        'value'         => $data['category_name'],
        'required'      => 'required'
    ]
];
echo make_form($form_a);