<?php
/**
 * Created by PhpStorm.
 * User: grow
 * Date: 09/10/2018
 * Time: 11:17 AM
 */
$path = base_url('assets/');
?>

<script src="<?=$path;?>vendors/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/jszip/dist/jszip.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/datatables.net-buttons/js/buttons.html5.min.js"></script>
