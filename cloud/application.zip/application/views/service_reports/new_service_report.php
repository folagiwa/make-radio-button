<?php
/**
 * File:    new_service_report
 * @Author: XYZoe
 * @email:  zoechuksimm@loveworld360.com
 * Date:    26/09/2018
 * Time:    12:46
 */

$this->CI =& get_instance();
$church = $this->session->logged_in['church_id'];

if(is_array($service_info)){
    $data   = $service_info;
}else{
    $data   = [
        'service_id'        => '',
        'church_id'         => $church,
        'service_date'      => '',
        'service_type'      => '',
        'attendance_kids'   => '',
        'attendance_teens'  => '',
        'attendance_adults' => '',
        'first_timers'      => '',
        'new_converts'      => '',
        'offering'          => '',
        'tithe'             => '',
        'seed'              => '',
        'thanksgiving'      => '',
        'remarks'           => '',
        'created_by'        => '',
    ];
}
$form_a = [
    [
        'name'      =>  'service_id',
        'class'     =>  '',
        'id'        =>  'service_id',
        'type'      =>  'hidden',
        'value'     =>  $data['service_id'],
    ],

    [
        'name'      =>  'church_id',
        'class'     =>  '',
        'id'        =>  'church_id',
        'type'      =>  'hidden',
        'value'     =>  $data['church_id'],
    ],

    [
        'name'          =>  'service_date',
        'class'         =>  'form-control date-picker flatpickr-input',
        'placeholder'   =>  $this->lang->line('select_service_date'),
        'id'            =>  'service_date',
        'type'          =>  'text',
        'value'         =>  $data['service_date']
        //'required'  =>  'required'
    ],
];
echo make_form($form_a);

$service_type = [
    ['label'=>$this->lang->line('weekend'),'val'=>'Weekend'],
    ['label'=>$this->lang->line('mid_week'),'val'=>'Mid-Week'],
    ['label'=>$this->lang->line('communion'), 'val'=>'Communion'],
    ['label'=>$this->lang->line('outreach'),'val'=>'Outreach'],
];

echo make_drop('service_type', $this->lang->line('select_service_type'), $service_type, 'val', 'label', $data['service_type']);

$form_b = [

    [
        'name'          =>  'attendance_kids',
        'class'         =>  'form-control form-control-lg',
        'placeholder'   =>  $this->lang->line('attendance_kids'),
        'id'            =>  'attendance_kids',
        'type'          =>  'text',
        'value'         =>  $data['attendance_kids']
        //'required'      =>  'required'
    ],

    [
        'name'          =>  'attendance_teens',
        'class'         =>  'form-control form-control-lg',
        'placeholder'   =>  $this->lang->line('attendance_teens'),
        'id'            =>  'attendance_teens',
        'type'          =>  'text',
        'value'         =>  $data['attendance_teens']
        //'required'      =>  'required'
    ],

    [
        'name'          =>  'attendance_adults',
        'class'         =>  'form-control form-control-lg',
        'placeholder'   =>  $this->lang->line('attendance_adults'),
        'id'            =>  'attendance_adults',
        'type'          =>  'text',
        'value'         =>  $data['attendance_adults']
        //'required'      =>  'required'
    ],

    [
        'name'          =>  'first_timers',
        'class'         =>  'form-control form-control-lg',
        'placeholder'   =>  $this->lang->line('attendance_first_timers'),
        'id'            =>  'first_timers',
        'type'          =>  'text',
        'value'         =>  $data['first_timers']
        //'required'      =>  'required'
    ],

    [
        'name'          =>  'new_converts',
        'class'         =>  'form-control form-control-lg',
        'placeholder'   =>  $this->lang->line('attendance_new_converts'),
        'id'            =>  'new_converts',
        'type'          =>  'text',
        'value'         =>  $data['new_converts']
        //'required'      =>  'required'
    ],

    [
        'name'          =>  'offering',
        'class'         =>  'form-control form-control-lg',
        'placeholder'   =>  $this->lang->line('offering'),
        'id'            =>  'offering',
        'type'          =>  'text',
        'value'         =>  $data['offering']
        //'required'      =>  'required'
    ],

    [
        'name'          =>  'tithe',
        'class'         =>  'form-control form-control-lg',
        'placeholder'   =>  $this->lang->line('tithe'),
        'id'            =>  'tithe',
        'type'          =>  'text',
        'value'         =>  $data['tithe']
        //'required'      =>  'required'
    ],

    [
        'name'          =>  'seed',
        'class'         =>  'form-control form-control-lg',
        'placeholder'   =>  $this->lang->line('seed'),
        'id'            =>  'seed',
        'type'          =>  'text',
        'value'         =>  $data['seed']
        //'required'      =>  'required'
    ],

    [
        'name'          =>  'thanksgiving',
        'class'         =>  'form-control form-control-lg',
        'placeholder'   =>  $this->lang->line('thanksgiving'),
        'id'            =>  'thanksgiving',
        'type'          =>  'text',
        'value'         =>  $data['thanksgiving']
        //'required'      =>  'required'
    ]
];

echo make_form($form_b);

$form_c = [
    [
        'name'          =>  'remarks',
        'class'         =>  '',
        'placeholder'   =>  $this->lang->line('remarks_long'),
        'remaining'     =>  $this->lang->line('remaining'),
        'id'            =>  'remarks',
        'type'          =>  'text',
        'value'         =>  $data['remarks'],
        //'required'      =>  'required'
    ]
];
echo make_text($form_c);