<?php
/**
 * File       : new_service_report.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 8/30/17
 * Time: 9:57 AM
 */

//$cur = $_SESSION['currency'];

//$service_info = '';

if (isset($service_info)){
    $data = $service_info;
} else {

    $data = [
        'service_id'        => '',
        'church_id'         => '',
        'group_id'          => '',
        'zone_id'           => '',
        'region_id'         => '',
        'service_date'      => '',
        'week_number'       => '',
        'service_type'      => '',
        'attendance_kids'   => '',
        'attendance_teens'  => '',
        'attendance_adults' => '',
        'first_timers'      => '',
        'new_converts'      => '',
        'offering'          => '',
        'tithe'             => '',
        'seed'              => '',
        'thanksgiving'      => '',
        'created_by'        => ''
    ];
}


$form_a = [
    [
        'name'              =>  'service_id',
        'class'             =>  '',
        'id'                =>  'service_id',
        'type'              =>  'hidden',
        'placeholder'       =>  '',
        'value'             =>  $data['service_id'],
    ],

    [
        'name'              => 'service_date',
        'label'             => $this->lang->line('service_date'),
        'class'             => 'form-control form-control-sm',
        'id'                => 'service_date',
        'type'              => 'text',
        'placeholder'       =>'',
        'value'             => $data['service_date'],

    ],

    [
        'name'              => 'attendance_kids',
        'label'             => $this->lang->line('attendance_kids'),
        'class'             => 'form-control form-control-sm',
        'id'                => 'attendance_kids',
        'type'              => 'text',
        'placeholder'       =>'',
        'value'             => $data['attendance_kids'],
//                'required'          => 'required'
    ],

    [
        'name'              => 'attendance_teens',
        'label'             => $this->lang->line('attendance_teens'),
        'class'             => 'form-control form-control-sm',
        'id'                => 'attendance_teens',
        'type'              => 'text',
        'placeholder'       =>'',
        'value'             => $data['attendance_teens'],
//                'required'          => 'required'
    ],


    [
   'name'              => 'attendance_adults',
      'label'             => $this->lang->line('attendance_adults'),
        'class'             => 'form-control form-control-sm',
        'id'                => 'attendance_adults',
        'type'              => 'text',
        'value'             => $data['attendance_adults'],
//                'required'          => 'required'
    ],

    [
        'name'              => 'first_timers',
        'label'             => $this->lang->line('first_timers'),
        'class'             => 'form-control form-control-sm',
        'id'                => 'first_timers',
        'type'              => 'text',
        'placeholder'       =>'',
        'value'             => $data['first_timers']

    ],

    [
        'name'              => 'new_converts',
        'label'             => $this->lang->line('new_converts'),
        'class'             => 'form-control form-control-sm',
        'id'                => 'new_converts',
        'type'              => 'text',
        'placeholder'       =>'',
        'value'             => $data['new_converts']

    ]

];

echo make_form($form_a);

