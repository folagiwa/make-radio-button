<?php
/**
 * File       : new_service_report.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 8/30/17
 * Time: 9:57 AM
 */

if(isset($unit_info)){

    $data = $unit_info;


} else {

    $data = [
        'tag_id'            => '',
        'church_id'         => $this->session->logged_in['church_id'],
        'tag_name'          => '',
        'tag_type'          => '',
        'leader'            => '',
        'tag_email'         => '',
        'created_by'        => '',
        'created_at'        => ''
    ];
}

$form_a = [
    [
        'name'              =>  'tag_id',
        'id'                =>  'tag_id',
        'type'              =>  'hidden',
        'value'             =>  $data['tag_id'],
    ],

    [
        'name'              =>  'church_id',
        'id'                =>  'church_id',
        'type'              =>  'hidden',
        'value'             =>  $data['church_id'],
    ],

    [
        'name'              => 'tag_name',
        'label'             => lang('unit_name'),
        'class'             => 'form-control form-control-lg',
        'id'                => 'tag_name',
        'type'              => 'text',
        'placeholder'       =>'',
        'value'             => $data['tag_name'],
        'required'          => 'required'

    ],

];

echo make_form($form_a);


$label_member =['title','surname','first_name'];
echo make_drop('leader', lang('leader'), $members, 'member_id', $label_member, $data['leader']);



$type = [
    ['label' => lang('house_fellowship'), 'val' => 'fellowship'],
    ['label' => lang('service_department'), 'val' => 'service_department'],
    ['label' => lang('teens_group'), 'val' => 'teens'],
    ['label' => lang('kids_group'), 'val' => 'kids'],
    ['label' => lang('adult_group'), 'val' => 'adult'],
];

echo make_drop('tag_type',lang('unit_type'),$type,'val','label',$data['tag_type']);


$form_b = [
    [
        'name'      => 'tag_email',
        'type'      => 'email',
        'label'     => lang('unit_email'),
        'class'     => 'form-control form-control-lg',
        'id'        => 'tag_email',
        'placeholder'   => lang('enter_email'),
        'value'     => $data['tag_email']
    ]

];

echo make_form($form_b);
