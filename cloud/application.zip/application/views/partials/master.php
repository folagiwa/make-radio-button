<?php
/**
 * File       : master.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/4/18
 * Time: 3:05 PM
 */
?>

<?php include('header.php');?>
<?php echo isset($handle)? $handle:'No content sent';?>
<?php include('footer.php');?>



<?php //include('header.php');?>
<?php //echo isset($handle)? $handle:'No content sent';?>
<?php
//$uri = $this->CI->uri->segment(1);
//if($uri == 'dashboard'){
//    include('footer.php');
//}elseif ($uri == 'home'|| $uri == 'church'){
//    include('footer_form_blank.php');
//}else{
//    include('footer_blank.php');
//}
