<?php
$path = base_url().'assets/';
?>

<script src="<?=$path;?>vendors/bower_components/jquery-mask-plugin/dist/jquery.mask.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/select2/dist/js/select2.full.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/dropzone/dist/min/dropzone.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/moment/min/moment.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/flatpickr/dist/flatpickr.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/nouislider/distribute/nouislider.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/trumbowyg/dist/trumbowyg.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/rateYo/min/jquery.rateyo.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/jquery-text-counter/textcounter.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/autosize/dist/autosize.min.js"></script>