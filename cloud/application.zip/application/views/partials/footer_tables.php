<?php
/**
 * File       : footer_tables.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 10/10/18
 * Time: 14:26
 */

$path = base_url().'assets/';
?>

<!--vendors: Data tables -->
<script src="<?=$path;?>vendors/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/jszip/dist/jszip.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/datatables.net-buttons/js/buttons.html5.min.js"></script>