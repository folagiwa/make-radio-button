<?php
$path = base_url().'assets/';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Grow Cloud | <?php echo $this->lang->line('welcome');?></title>

    <!-- Vendor styles -->
    <link rel="icon" type="image/png" href="<?=$path?>img/favicon.png" />
    <link rel="stylesheet" href="<?=$path;?>vendors/bower_components/material-design-iconic-font/dist/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="<?=$path;?>vendors/bower_components/animate.css/animate.min.css">

    <!-- App styles -->
    <link rel="stylesheet" href="<?=$path;?>css/app.min.css">
</head>

<body data-sa-theme="2">

<div class="row justify-content-center align-items-center" style="margin-top: 10% !important;">
    <div class="col-md-3">


        <!-- Login -->
        <div class="login__block active" id="l-login">
            <?php if($this->session->userdata('info') !== null): ?>
                <div class="alert alert-info alert-dismissable">
                    <?php echo $this->session->userdata('info'); ?>
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                </div>
                <?php unset($_SESSION['info']); endif; ?>

            <?php if($this->session->userdata('error') !== null): ?>
                <div class="alert alert-danger alert-dismissable">
                    <?php echo $this->session->userdata('error'); ?>
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                </div>
                <?php unset($_SESSION['error']); endif; ?>
            <div class="login__block__header">
                <i class=""><img src="<?=$path;?>img/logo.png"></i>
                <h5><?php echo strtoupper($this->lang->line('auth_authorize'));?></h5>

                <div class="actions actions--inverse login__block__actions">
                    <div>
                        <i data-toggle="dropdown" class="zmdi zmdi-more-vert actions__item"></i>

                        <div class="dropdown-menu dropdown-menu-right">
                            <a class="dropdown-item" data-sa-action="login-switch" data-sa-target="#l-register" href=""><?php echo $this->lang->line('create_account');?></a>
                            <a class="dropdown-item" data-sa-action="login-switch" data-sa-target="#l-forget-password" href=""><?php echo $this->lang->line('forgot_password');?></a>
                        </div>
                    </div>
                </div>
            </div>


            <div class="login__block__body">
                <?php echo form_open('cloud', 'class="no-margin"'); ?>

                <div class="form-group">
                    <?php echo form_error('username');?>
                    <input type="text" class="form-control text-center" name="username" placeholder="<?php echo $this->lang->line('auth_username');?>">
                </div>

                <div class="form-group">
                    <?php echo form_error('password');?>

                    <input type="password"  class="form-control text-center" name="password" placeholder="<?php echo $this->lang->line('auth_password');?>">
                </div>

                <button type="submit" name="login" value="login" class="btn btn--icon login__block__btn"><i class="zmdi zmdi-long-arrow-right"></i></button>
                </form>
            </div>
        </div>

        <!-- Register -->
        <div class="login__block" id="l-register">
            <div class="login__block__header">
                <i class="zmdi zmdi-account-circle"></i>

                <?php echo $this->lang->line('create_account');?>

                <div class="actions actions--inverse login__block__actions">
                    <div>
                        <i data-toggle="dropdown" class="zmdi zmdi-more-vert actions__item"></i>

                        <div class="dropdown-menu dropdown-menu-right">
                            <a class="dropdown-item" data-sa-action="login-switch" data-sa-target="#l-login" href=""><?php echo $this->lang->line('auth_account');?></a>
                            <a class="dropdown-item" data-sa-action="login-switch" data-sa-target="#l-forget-password" href=""><?php echo $this->lang->line('auth_forgot');?></a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="login__block__body">
                <?php echo form_open('cloud','');?>
                <div class="form-group">
                    <?php echo form_error('surname');?>
                    <input type="text" class="form-control text-center" name="surname" placeholder="<?php echo $this->lang->line('surname');?>">
                </div>

                <div class="form-group">
                    <?php echo form_error('first_name');?>
                    <input type="text" class="form-control text-center" name="first_name" placeholder="<?php echo $this->lang->line('first_name');?>">
                </div>

                <div class="form-group form-group--centered">
                    <?php echo form_error('church_name');?>
                    <input type="text" class="form-control text-center" name="church_name" placeholder="<?php echo $this->lang->line('church_name');?>">
                </div>

                <div class="form-group form-group--centered">
                    <?php echo form_error('email_address');?>
                    <input type="text" class="form-control text-center" name="email_address" placeholder="<?php echo $this->lang->line('email');?>">
                </div>
                <div class="input-group">
                    <div class="form-group form-group--centered">
                        <?php echo form_error('church_website');?>
                        <input type="text" class="form-control text-center" name="church_website" placeholder="<?php echo $this->lang->line('church_website');?>">
                    </div>
                    <span class="input-group-addon">.growcloud.com</span>
                </div>

                <br><br>
                <div class="form-group">
                    <label class="custom-control custom-checkbox">
                        <input type="checkbox" name="licence" value="licence" class="custom-control-input">
                        <span class="custom-control-indicator"></span>
                        <span class="custom-control-description"><?php echo $this->lang->line('licence');?></span>
                    </label>
                </div>

                <button type="submit" class="btn btn--icon login__block__btn" name="register" value="register"><i class="zmdi zmdi-long-arrow-right"></i></button>
                </form>
            </div>
        </div>

        <!-- Forgot Password -->
        <div class="login__block" id="l-forget-password">
            <div class="login__block__header">
                <i class="zmdi zmdi-account-circle"></i>
                <?php echo $this->lang->line('forgot');?>

                <div class="actions actions--inverse login__block__actions">
                    <div>
                        <i data-toggle="dropdown" class="zmdi zmdi-more-vert actions__item"></i>

                        <div class="dropdown-menu dropdown-menu-right">
                            <a class="dropdown-item" data-sa-action="login-switch" data-sa-target="#l-login" href=""><?php echo $this->lang->line('auth_account');?></a>
                            <a class="dropdown-item" data-sa-action="login-switch" data-sa-target="#l-register" href=""><?php echo $this->lang->line('create_account');?></a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="login__block__body">
                <p class="mb-5"><?php echo $this->lang->line('forgot_msg');?></p>
                <?php echo form_open('cloud','');?>
                <div class="form-group">
                    <input type="text" class="form-control text-center" name="username" placeholder="Email Address">
                </div>

                <button type="submit" name="forgot" value="forgot" class="btn btn--icon login__block__btn"><i class="zmdi zmdi-check"></i></button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-5">
        <div class="card">
            <div class="card-body">
                <div class="tab-container">
                    <ul class="nav nav-tabs nav-fill" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" data-toggle="tab" href="#trending" role="tab" aria-expanded="false"><?php echo $this->lang->line('trending')?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#about" role="tab" aria-expanded="false"><?php echo $this->lang->line('all_about_cloud')?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#features" role="tab" aria-expanded="true"><?php echo $this->lang->line('key_features')?></a>
                        </li>
                    </ul>

                    <div class="tab-content">
                        <div class="tab-pane active fade show" id="trending" role="tabpanel">
                            <img class="card-img-top" src="<?=$path?>demo/img/widgets/blow_ad_2.jpg" alt="">
                        </div>
                        <div class="tab-pane fade" id="about" role="tabpanel"><?php echo $this->lang->line('about_speech')?></div>
                        <div class="tab-pane fade" id="features" role="tabpanel"><?php echo $this->lang->line('features_speech')?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<!-- Older IE warning message -->
<!--[if IE]>
<div class="ie-warning">
    <h1>Warning!!</h1>
    <p>You are using an outdated version of Internet Explorer, please upgrade to any of the following web browsers to access this website.</p>

    <div class="ie-warning__downloads">
        <a href="http://www.google.com/chrome">
            <img src="img/browsers/chrome.png" alt="">
        </a>

        <a href="https://www.mozilla.org/en-US/firefox/new">
            <img src="img/browsers/firefox.png" alt="">
        </a>

        <a href="http://www.opera.com">
            <img src="img/browsers/opera.png" alt="">
        </a>

        <a href="https://support.apple.com/downloads/safari">
            <img src="img/browsers/safari.png" alt="">
        </a>

        <a href="https://www.microsoft.com/en-us/windows/microsoft-edge">
            <img src="img/browsers/edge.png" alt="">
        </a>

        <a href="http://windows.microsoft.com/en-us/internet-explorer/download-ie">
            <img src="img/browsers/ie.png" alt="">
        </a>
    </div>
    <p>Sorry for the inconvenience!</p>
</div>



<![endif]-->

<!-- Javascript -->
<!-- Vendors -->
<script src="<?=$path;?>vendors/bower_components/jquery/dist/jquery.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/popper.js/dist/umd/popper.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

<!-- App functions and actions -->
<script src="<?=$path;?>js/app.min.js"></script>
</body>
</html>