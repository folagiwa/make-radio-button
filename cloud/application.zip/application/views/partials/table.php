<?php
/**
 * File       : table.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 10/13/18
 * Time: 21:39
 */
?>
<div class="card">
    <div class="card-body">
        <h4 class="card-title"><?php echo isset($title)?$title:'Page title Goes here';?></h4>
<h6 class="card-subtitle"><?php echo isset($sub_title)?$sub_title:'';?></h6>

<?php echo isset($content)?$content:'Page Content Goes Here, page is empty';?>

</div>
</div>

