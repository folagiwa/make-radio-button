<?php
$path = base_url().'assets/';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Vendor styles -->
    <link rel="stylesheet" href="<?=$path;?>vendors/bower_components/material-design-iconic-font/dist/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="<?=$path;?>vendors/bower_components/animate.css/animate.min.css">

    <!-- App styles -->
    <link rel="stylesheet" href="<?=$path;?>css/app.min.css">
</head>

<body data-sa-theme="2">
<div class="login">

    <!-- Login -->
    <div class="login__block active" id="l-login">
        <div class="login__block__header">
            <i class=""><img src="<?=$path;?>img/logo.png"></i>
            <h4><?php echo strtoupper($this->lang->line('auth_authorize'));?></h4>

            <div class="actions actions--inverse login__block__actions">

            </div>
        </div>

        <div class="login__block__body">
            <?php echo form_open('', 'class="no-margin"'); ?>

            <div class="form-group">
                <?php echo form_error('username');?>
                <input type="password" class="form-control text-center" name="password" placeholder="<?php echo $this->lang->line('auth_password');?>">
            </div>

            <div class="form-group">
                <?php echo form_error('password');?>

                <input type="password"  class="form-control text-center" name="confirm_password" placeholder="<?php echo $this->lang->line('auth_confirm_password');?>">
            </div>

            <button type="submit" name="set_password" value="set_password" class="btn btn--icon login__block__btn"><i class="zmdi zmdi-long-arrow-right"></i></button>
            </form>
        </div>
    </div>



    <!-- Forgot Password -->

</div>

<!-- Older IE warning message -->
<!--[if IE]>
<div class="ie-warning">
    <h1>Warning!!</h1>
    <p>You are using an outdated version of Internet Explorer, please upgrade to any of the following web browsers to access this website.</p>

    <div class="ie-warning__downloads">
        <a href="http://www.google.com/chrome">
            <img src="img/browsers/chrome.png" alt="">
        </a>

        <a href="https://www.mozilla.org/en-US/firefox/new">
            <img src="img/browsers/firefox.png" alt="">
        </a>

        <a href="http://www.opera.com">
            <img src="img/browsers/opera.png" alt="">
        </a>

        <a href="https://support.apple.com/downloads/safari">
            <img src="img/browsers/safari.png" alt="">
        </a>

        <a href="https://www.microsoft.com/en-us/windows/microsoft-edge">
            <img src="img/browsers/edge.png" alt="">
        </a>

        <a href="http://windows.microsoft.com/en-us/internet-explorer/download-ie">
            <img src="img/browsers/ie.png" alt="">
        </a>
    </div>
    <p>Sorry for the inconvenience!</p>
</div>
<![endif]-->

<!-- Javascript -->
<!-- Vendors -->
<script src="<?=$path;?>vendors/bower_components/jquery/dist/jquery.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/popper.js/dist/umd/popper.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

<!-- App functions and actions -->
<script src="<?=$path;?>js/app.min.js"></script>
</body>
</html>