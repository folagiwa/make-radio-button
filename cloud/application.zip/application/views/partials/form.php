<?php
/**
 * File       : form.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/6/18
 * Time: 11:39 AM
 */
?>

<div class="card">
    <div class="card-body">
        <h4 class="card-title">Textual inputs</h4>
        <h6 class="card-subtitle">Basic Textual inputs with different sizes by height and column.</h6>

        <h3 class="card-body__title">Control sizing</h3>

        <div class="form-group">
            <input type="text" class="form-control form-control-sm" placeholder="Input Small">
            <i class="form-group__bar"></i>
        </div>

        <div class="form-group">
            <input type="text" class="form-control" placeholder="Input Default">
            <i class="form-group__bar"></i>
        </div>

        <div class="form-group">
            <input type="text" class="form-control form-control-lg" placeholder="Input Large">
            <i class="form-group__bar"></i>
        </div>

        <br>

        <h3 class="card-body__title">Column sizing</h3>

        <div class="row">
            <div class="col-sm-4">
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="col-sm-4">
                    <i class="form-group__bar"></i>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="col-sm-4">
                    <i class="form-group__bar"></i>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="col-sm-4">
                    <i class="form-group__bar"></i>
                </div>
            </div>

            <div class="col-sm-3">
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="col-sm-3">
                    <i class="form-group__bar"></i>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="col-sm-3">
                    <i class="form-group__bar"></i>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="col-sm-3">
                    <i class="form-group__bar"></i>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="col-sm-3">
                    <i class="form-group__bar"></i>
                </div>
            </div>

            <div class="col-sm-6">
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="col-sm-6">
                    <i class="form-group__bar"></i>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="col-sm-6">
                    <i class="form-group__bar"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $path = base_url().'assets/'; ?>

<script src="<?=$path;?>vendors/bower_components/jquery/dist/jquery.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/popper.js/dist/umd/popper.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/jquery.scrollbar/jquery.scrollbar.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/jquery-scrollLock/jquery-scrollLock.min.js"></script>

<script src="<?=$path;?>vendors/bower_components/autosize/dist/autosize.min.js"></script>

<script src="<?=$path;?>js/app.min.js"></script>
