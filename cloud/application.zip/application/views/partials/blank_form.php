<?php
/**
 * File:    form_blank.php
 * @Auhor:  XYZoe
 * @email:  zoechuksimm@loveworld360.com
 * Date:    26/09/2018
 * Time:    12:56
 */

$this->CI =& get_instance();
$path = base_url().'assets/';
?>

<div class="row">
    <div class="col-md-8">
        <div class="card">
            <?php
            if(isset($multi) && $multi === TRUE){
                echo form_open_multipart("$action", 'class="card-body" id="user-form"');
            } else {
                echo form_open("$action", 'class="card-body" id="user-form"');
            }
            ?>
            <fieldset>
                <h6 class="card-subtitle"><?php echo $this->lang->line('fill_form_instruction')?></h6>

                <!--                    --><?php //echo isset($_SESSION['info']) ? alert_success($_SESSION['info']) :''; unset($_SESSION['info']);?>
                <!--                    --><?php //echo isset($_SESSION['error']) ? alert_warning($_SESSION['error']) :''; unset($_SESSION['error']);?>
                <!--                    --><?php //echo isset($_SESSION['info_b']) ? alert_info($_SESSION['info_b']) :''; unset($_SESSION['info_b']);?>

                <?php echo $form_content;?>
            </fieldset>

            <div class="form-actions">
                <div class="row">
                    <div class="col-sm-8 col-sm-offset-4">
                        <input type="hidden" name="created_by" value="<?php echo $this->session->logged_in['member_id'];?>">

                        <?php if (isset($list)) {?>
                            <button id="sub" type="submit" onclick="new_form()" class="btn btn-primary"><?php echo $this->lang->line('submit_new');?></button>
                            <!--                            <button id="subs" type="submit" name="list_page" value="--><?php //echo (isset($list)) ? $list : '';?><!--" class="btn btn-primary">--><?php //echo $this->lang->line('submit_exit');?><!--</button>-->
                        <?php } else { ?>
                            <button type="submit" class="btn btn-primary mt-5"><?php echo $this->lang->line('submit');?></button>
                        <?php } ?>
                        <!--                        <button type="reset" class="btn btn-default">--><?php //echo $this->lang->line('cancel');?><!--</button>-->
                    </div>
                </div>
            </div>
            </form>


        </div>
    </div>

    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title"><?php echo $this->lang->line('how_it_works')?></h4>
                <ul class="text-list">
                    <?php echo $this->lang->line('how_it_works_speech')?><br>
                </ul>
            </div>
        </div>

        <img class="card-img-bottom mb-5" src="<?=$path;?>demo/img/headers/app_banner_blow.jpg">

        <div class="card">
            <?php if(isset($latest)){
                echo $latest;
            }?>
        </div>
    </div>

</div>