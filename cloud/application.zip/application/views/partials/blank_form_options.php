<?php
/**
 * ------------------------------------------------------- *
 * File         : forecast_form.php.v.1.0
 * Created for  : PROJECT GROW.
 * @Author      : Ebenezer Nii Otoo
 * @Email       : askeben@loveworld360.com
 * @Kingschat   : +233261562716
 * Date         : 7/17/17
 * Time         : 3:47 PM
 * ------------------------------------------------------- *
 */
//$scope = $_SESSION['logged_in']['user_scope'];
$path = base_url().'assets/';

?>

<div class="row">
    <div class="col-md-8">
    <div class="card">
    <div class="card-body">
    <h4 class="card-title"><?php echo (isset($title))?$title:'No title set';?></span><small><?php echo (isset($bread))?$bread:'';?></small></h4>
    <h6 class="card-subtitle"><?php echo isset($sub_title)?$sub_title:'No subtitle set';?></h6>

                <div class="body">

                    <?php
                    if(isset($multi) && $multi === TRUE){
                        echo form_open_multipart("$action", 'class="form-horizontal form-label-left"');
                    } else {
                        echo form_open("$action", 'class="form-horizontal form-label-left"');
                    }
                    ?>

<!---->
<!--                    <fieldset>-->
<!--                        <legend class="section">--><?php //echo $legend;?><!--</legend>-->
<!--                        --><?php //echo isset($_SESSION['info']) ? alert_success($_SESSION['info']) :''; unset($_SESSION['info']);?>
<!--                        --><?php //echo isset($_SESSION['error']) ? alert_warning($_SESSION['error']) :''; unset($_SESSION['error']);?>
<!--                        --><?php //echo $form_content;?>
<!---->
<!---->
<!--                    </fieldset>-->

                    <?php echo $form_content;?>


                    <div class="form-actions">
                        <div class="row">
                            <div class="col-sm-8 col-sm-offset-4">
                                <input type="hidden" name="created_by" value="<?php echo $this->session->logged_in['member_id'];?>">
                                <button type="submit" class="btn btn-primary"><?php echo $this->lang->line('submit');?></button>
                                <button type="reset" class="btn btn-default"><?php echo lang('cancel');?></button>
                            </div>
                        </div>
                    </div>
                    </form>
                </div>
        </div>
    </div>
    </div>


    <div class="col-md-4">

        <div class="card">
            <div class="card-body">
                <h4 class="card-title"><?php echo $this->lang->line('how_it_works')?></h4>
                <h6 class="card-subtitle"><?=lang('options_how_it_works')?></h6>
                <ul style="list-style-type:none">
                    <li>
                        <label class="custom-control custom-checkbox">
                            <input type="checkbox" id="toggle_fullname" class="custom-control-input" checked disabled>
                            <span class="custom-control-indicator"></span>
                            <span class="custom-control-description"><?php echo lang('full_name');?></span>
                        </label>
                    </li>
                    <li>
                        <label class="custom-control custom-checkbox">
                            <input type="checkbox" id="toggle_birth_date" class="custom-control-input">
                            <span class="custom-control-indicator"></span>
                            <span class="custom-control-description"><?php echo lang('birth_date');?></span>
                        </label>
                    </li>
                    <li>
                        <label class="custom-control custom-checkbox">
                            <input type="checkbox" id="toggle_country" class="custom-control-input">
                            <span class="custom-control-indicator"></span>
                            <span class="custom-control-description"><?php echo lang('country');?></span>
                        </label>
                    </li>
                    <li>
                        <label class="custom-control custom-checkbox">
                            <input type="checkbox" id="toggle_state" class="custom-control-input">
                            <span class="custom-control-indicator"></span>
                            <span class="custom-control-description"><?php echo lang('state');?></span>
                        </label>
                    </li>
                    <li>
                        <label class="custom-control custom-checkbox">
                            <input type="checkbox" id="toggle_city" class="custom-control-input">
                            <span class="custom-control-indicator"></span>
                            <span class="custom-control-description"><?php echo lang('city');?></span>
                        </label>
                    </li>
                    <li>
                        <label class="custom-control custom-checkbox">
                            <input type="checkbox" id="toggle_gender" class="custom-control-input">
                            <span class="custom-control-indicator"></span>
                            <span class="custom-control-description"><?php echo lang('gender');?></span>
                        </label>
                    </li>
                    <li>
                        <label class="custom-control custom-checkbox">
                            <input type="checkbox" id="toggle_marital_status" class="custom-control-input">
                            <span class="custom-control-indicator"></span>
                            <span class="custom-control-description"><?php echo lang('marital_status');?></span>
                        </label>
                    </li>
                    <li>
                        <label class="custom-control custom-checkbox">
                            <input type="checkbox" id="toggle_mobile_phone" class="custom-control-input">
                            <span class="custom-control-indicator"></span>
                            <span class="custom-control-description"><?php echo lang('mobile_phone');?></span>
                        </label>
                    </li>

                    <li>
                        <label class="custom-control custom-checkbox">
                            <input type="checkbox" id="toggle_email_address" class="custom-control-input">
                            <span class="custom-control-indicator"></span>
                            <span class="custom-control-description"><?php echo lang('email_address');?></span>
                        </label>
                    </li>
                    <li>
                        <label class="custom-control custom-checkbox">
                            <input type="checkbox" id="toggle_home_address" class="custom-control-input">
                            <span class="custom-control-indicator"></span>
                            <span class="custom-control-description"><?php echo lang('home_address');?></span>
                        </label>
                    </li>
                    <li>
                        <label class="custom-control custom-checkbox">
                            <input type="checkbox" id="toggle_group_assigned" class="custom-control-input">
                            <span class="custom-control-indicator"></span>
                            <span class="custom-control-description"><?php echo lang('group_assign');?></span>
                        </label>
                    </li>
                    <li>
                        <label class="custom-control custom-checkbox">
                            <input type="checkbox" id="toggle_profession" class="custom-control-input">
                            <span class="custom-control-indicator"></span>
                            <span class="custom-control-description"><?php echo lang('profession');?></span>
                        </label>
                    </li>
                    <li>
                        <label class="custom-control custom-checkbox">
                            <input type="checkbox" id="toggle_profile_picture" class="custom-control-input">
                            <span class="custom-control-indicator"></span>
                            <span class="custom-control-description"><?php echo lang('member_picture_upload');?></span>
                        </label>
                    </li>
                </ul>
            </div>
        </div>
        <img class="card-img-bottom mb-5" src="<?=$path;?>demo/img/headers/app_banner_blow.jpg">

    </div>
</div>
















<!-- page application js -->
