<?php
$path = base_url().'assets/';
$sub_type = $this->uri->segment(3);
if($sub_type == 'trial'){
    $sub_type = 'trial';
} else if($sub_type == 'standard'){
    $sub_type = 'standard';

} else if($sub_type == 'gold'){
    $sub_type = 'gold';

} else {
    $sub_type = 'trial';

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Grow Cloud | Welcome</title>

    <!-- Vendor styles -->
    <link rel="icon" type="image/png" href="<?=$path?>img/favicon.png" />
    <link rel="stylesheet" href="<?=$path;?>vendors/bower_components/material-design-iconic-font/dist/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="<?=$path;?>vendors/bower_components/animate.css/animate.min.css">

    <!-- App styles -->
    <link rel="stylesheet" href="<?=$path;?>css/app.min.css">
</head>

<body data-sa-theme="2">

<div class="login">


    <!-- Login -->
    <div class="login__block active" id="l-login">
        <?php if($this->session->userdata('info') !== null): ?>
            <div class="alert alert-info alert-dismissable">
                <?php echo $this->session->userdata('info'); ?>
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            </div>
            <?php unset($_SESSION['info']); endif; ?>

        <?php if($this->session->userdata('error') !== null): ?>
            <div class="alert alert-danger alert-dismissable">
                <?php echo $this->session->userdata('error'); ?>
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            </div>
            <?php unset($_SESSION['error']); endif; ?>

        <div class="login__block__header">
            <i class="zmdi zmdi-account-circle"></i>

            <?php echo $this->lang->line('create_account');?>

            <div class="actions actions--inverse login__block__actions">
<!--                <div class="dropdown">-->
<!--                    <i data-toggle="dropdown" class="zmdi zmdi-more-vert actions__item"></i>-->
<!---->
<!--                    <div class="dropdown-menu dropdown-menu-right">-->
<!--                        <a class="dropdown-item" href="--><?php //echo base_url(); ?><!--">--><?php //echo $this->lang->line('auth_account');?><!--</a>-->
<!--                    </div>-->
<!--                </div>-->
            </div>
        </div>


        <div class="login__block__body">
            <div class="alert alert-info">You are on <?=$sub_type;?> subscription</div>
            <?php echo form_open('welcome/register','');?>

            <input type="hidden" name="subscription_type" value="<?=$sub_type;?>">
            <div class="form-group">
                <?php echo form_error('surname');?>
                <input type="text" class="form-control text-center" name="surname" placeholder="<?php echo $this->lang->line('surname');?>">
            </div>

            <div class="form-group">
                <?php echo form_error('first_name');?>
                <input type="text" class="form-control text-center" name="first_name" placeholder="<?php echo $this->lang->line('first_name');?>">
            </div>

            <div class="form-group form-group--centered">
                <?php echo form_error('church_name');?>
                <input type="text" class="form-control text-center" name="church_name" placeholder="<?php echo $this->lang->line('church_name');?>">
            </div>

            <div class="form-group form-group--centered">
                <?php echo form_error('email_address');?>
                <input type="text" class="form-control text-center" name="email_address" placeholder="<?php echo $this->lang->line('email');?>">
            </div>
            <div class="input-group">
                <div class="form-group form-group--centered">
                    <?php echo form_error('church_website');?>
                    <input type="text" class="form-control text-center" name="church_website" placeholder="<?php echo $this->lang->line('church_username');?>">
                </div>
                <span class="input-group-addon">.growcloud.com</span>
            </div>

            <br><br>
            <div class="form-group">
                <label class="custom-control custom-checkbox">
                    <input type="checkbox" name="licence" value="licence" class="custom-control-input">
                    <span class="custom-control-indicator"></span>
                    <span class="custom-control-description"><?php echo $this->lang->line('licence');?></span>
                </label>
            </div>

            <button type="submit" class="btn btn--icon login__block__btn" name="register" value="register"><i class="zmdi zmdi-long-arrow-right"></i></button>
            </form>
        </div>

    </div>


</div>

<!-- Older IE warning message -->
<!--[if IE]>
<div class="ie-warning">
    <h1>Warning!!</h1>
    <p>You are using an outdated version of Internet Explorer, please upgrade to any of the following web browsers to access this website.</p>

    <div class="ie-warning__downloads">
        <a href="http://www.google.com/chrome">
            <img src="img/browsers/chrome.png" alt="">
        </a>

        <a href="https://www.mozilla.org/en-US/firefox/new">
            <img src="img/browsers/firefox.png" alt="">
        </a>

        <a href="http://www.opera.com">
            <img src="img/browsers/opera.png" alt="">
        </a>

        <a href="https://support.apple.com/downloads/safari">
            <img src="img/browsers/safari.png" alt="">
        </a>

        <a href="https://www.microsoft.com/en-us/windows/microsoft-edge">
            <img src="img/browsers/edge.png" alt="">
        </a>

        <a href="http://windows.microsoft.com/en-us/internet-explorer/download-ie">
            <img src="img/browsers/ie.png" alt="">
        </a>
    </div>
    <p>Sorry for the inconvenience!</p>
</div>
<![endif]-->

<!-- Javascript -->
<!-- Vendors -->
<script src="<?=$path;?>vendors/bower_components/jquery/dist/jquery.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/popper.js/dist/umd/popper.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

<!-- App functions and actions -->
<script src="<?=$path;?>js/app.min.js"></script>
</body>
</html>