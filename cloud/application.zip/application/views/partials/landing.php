<?php $path = base_url().'assets/';?>

<!DOCTYPE html>
<html lang="en-US">
  <head>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="GROW Cloud" content="Grow is the next generation church management software designed for spiritual, numerical and financial growth. The software effectively models the mordern Church's structure; from the church pastor to the member.">
    <meta name="Church Management Platform" content="church, management, software, group meeting, fellowship, cell meeting">

    <title>GROW Cloud - Church Management System</title>

    <!-- Font Google -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600,700,800%7CComfortaa:300,400,700" rel="stylesheet">
    
    <!-- custom styles (optional) -->
    <link href="<?=$path;?>external/css/plugins.css" rel="stylesheet">
    <link href="<?=$path;?>external/css/style.css" rel="stylesheet">
    <link href="<?=$path;?>externalcss/responsive.css" rel="stylesheet">
  </head>
  <body>

    <!-- Loader
    ================================================== -->
    <div id="preloader">
      <div class='loader-ring'>
        <div class='loader-ring-light'></div>
        <div class='loader-ring-track'></div>
      </div>
    </div>
    <!-- End Loader
    ================================================== -->

    <!-- Navbar
    ================================================== -->
    <nav class="navbar navbar-expand-lg">
      <div class="container">

        <a class="navbar-brand" href="demo-video.html#">
          <img src="<?=$path;?>external/img/logo-2.png" alt="logo" class="logo-1">
        </a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="fas fa-bars"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link " href="demo-video.html#home">Home <span class="sr-only">(current)</span></a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="demo-video.html#about">About</a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="demo-video.html#why_grow">Why Grow?</a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="demo-video.html#features">Features</a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="demo-video.html#pricing">Pricing</a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="demo-video.html#testimonial">Client</a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="demo-video.html#contact">Contact</a>
            </li>

            
            <li class="nav-item">
              <a href="#pricing" class="btn-danger btn-sm">
                <span class="text" style=" font-size: 12px; color: white;">Get Started</span>
              </a>
            </li>

              <li class="nav-item">
                  <a href="#" class="btn-danger btn-sm" data-toggle="modal" data-target="#loginView">
                      <span class="text" style=" font-size: 12px; color: white;">Already Registered?</span>
                  </a>
              </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- End Navbar
    ================================================== -->


    <main class="main">

      <!--  Header
      ================================================== -->
      <header id="home" class="header" data-overlay='5'>
       <video autoplay muted loop id="myVideo">
  <source src="<?=$path;?>external/video/video_sample.mp4" type="video/mp4">
</video>
        <div class="container h-100">
          <div class="row align-items-center h-100">
            <div class="caption text-center m-auto"> 
              <h4 style="color: white">Grow Spiritually, Financially &amp; Numerically!</h4>
              <p class="m-auto" style="font-size:15px;">Grow Cloud is a  cloud-based Church Management System<br> that allows track membership growth and make better decisions</p>
              <a href="#" class="btn btn-light  mt-20">
                <span class="text">Start your FREE account!</span>
              </a>
            </div>
          </div>
        </div>
      </header>
     
      <!-- End Header
      ================================================== -->


      <!-- About
      ================================================== -->
      <section id="about" class="about section-padding">
        <div class="container">
          <div class="row">

            <div class="col-lg-6 mb-50">
              <div class="content-title">
                <span class="vertical-text">About Us</span>
                <h5>Top Church Assistant Tool</h5>
                <h2>Welcome To GROW</h2>
              </div>
              <div class="content-about">
                <p class="pa-t mb-20">Grow is the next generation church management software designed for spiritual, numerical and financial growth. The software effectively models the mordern Church's structure; from the church pastor to the member.
</p>

                <p>Through the use of highly effective and custom-built data capture, data analysis, forecasting tools, Grow provides a Fellowship Leader, Senior Fellowship Leader, Group Leader, Church Pastor with all the requirements, tools and features to effectively monitor and grow his Fellowship, Senior Fellowship, Group and Church.</p>
              </div>
            </div>

            <div class="col-lg-6 mb-50">
              <div class="box-img">
                <img src="<?=$path;?>external/img/about-us.jpg" alt="">
              </div>
            </div>



            <div class="col-12">
              <div class="features-wrap">
                <div class="row">

                  <div class="col-lg-4">
                    <div class="inner-box">
                      <div class="content">
                        <h2>01.</h2>
                        <div class="box-tit">
                          <div class="delimiter"></div>
                          <div class="title"><h4 class="box-header"> Track Record</h4></div>
                        </div>


                        <p>Track attendance, baptism records, salvations, membership spiritual growth and development and lot more to keep the pastor informed and make timely decisions.</p>
                      </div>
                    </div>
                  </div>

                  <div class="col-lg-4">
                    <div class="inner-box">
                      <div class="content">
                        <h2>02.</h2>
                        <div class="box-tit">
                          <div class="delimiter"></div>
                          <div class="title"><h4 class="box-header">Run Customized Dashboard</h4></div>
                        </div>


                        <p>Create parameters you’d like to see at a glance on the dashboard. Everything about your Church at a glance.</p>
                      </div>
                    </div>
                  </div>

                  <div class="col-lg-4">
                    <div class="inner-box">
                      <div class="content">
                        <h2>03.</h2>
                        <div class="box-tit">
                          <div class="delimiter"></div>
                          <div class="title"><h4 class="box-header">Data Forecast </h4></div>
                        </div>


                        <p>Set a parameters and let Grow cloud compile your church data for any given period. Review week or a year forecast, and see exactly how you’ve grown.</p>
                      </div>
                    </div>
                  </div>

                </div>
              </div>
            </div>

          </div>
        </div>
      </section>
      <!-- End About
      ================================================== -->

    <!-- services 
    ================================================== -->
    <section id="why_grow" class="services section-padding">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="content-title">
              <span class="vertical-text">Services</span>
              <h5>GROW for every Church</h5>
              <h2>Why Use GROW </h2>
            </div>
          </div>

          <div class="col-lg-6 col-md-6 col-sm-12 mb-30">
            <div class="service-box">
              <div class="icon">
                <span class="icon jam jam-users"></span>
              </div>

              <div class="content">
                <h4 class="mb-20">Manage Congregation</h4>
                <p>Ministry is about people. Grow cloud church management  is a powerful software tool helps you manage people, track people spiritual growth all the way from their first visit throughout their entire membership..</p>
              </div>
            </div>
          </div>

          <div class="col-lg-6 col-md-6 col-sm-12 mb-30">
            <div class="service-box">
              <div class="icon">
                <span class="icon jam jam-smiley"></span>
              </div>

              <div class="content">
                <h4 class="mb-20">Membership Involvement </h4>
                <p>GROW Cloud helps each member of the church log in and participate; there is no limits to number of users. Our flexible structure gives you the privilege to control who is allowed to do what. </p>
              </div>
            </div>
          </div>

          <div class="col-lg-6 col-md-6 col-sm-12 mb-30">
            <div class="service-box">
              <div class="icon">
                <span class="icon jam jam-direction"></span>
              </div>

              <div class="content">
                <h4 class="mb-20">Effective Communications</h4>
                <p>GROW Cloud help facilitate and manage church communications between small group leaders and members. </p>
              </div>
            </div>
          </div>

          <div class="col-lg-6 col-md-6 col-sm-12 mb-30">
            <div class="service-box">
              <div class="icon">
                <span class="icon jam jam-target"></span>
              </div>

              <div class="content">
                <h4 class="mb-20">Reports </h4>
                <p>With Grow cloud, you can view trends for any timeframe you need. Schedule a report, and get stats sent directly to your mail box.</p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
    <!-- End services
    ================================================== -->
    
    
      <!-- process
      ================================================== -->
      <section class="process">
       <h4 class="caption text-center m-auto mb-20 mt-70">Designed For Grow</h4>
        <div class="part-top section-padding cover-bg parallax" data-image-src="<?=$path;?>external/img/bg-3.jpg" data-overlay='8'></div>
        <div class="part-bottom text-center">
          <div class="container">
            <div class="row">
              <div class="col-lg-3 col-md-6">
                <div class="item-process-content">
                  <h4> Data Capture</h4>
                  <div class="icon-box">
                    <span>01</span>
                  </div>
                  <p>Data capture is very important; the admin will have to always fill in the Church reports on the GROW platform</p>
                </div>
              </div>

              <div class="col-lg-3 col-md-6">
                <div class="item-process-content">
                  <h4> Monitoring</h4>
                  <div class="icon-box">
                    <span>02</span>
                  </div>
                  <p>The admin will also have to follow up on the Church leaders to submit their Church reports </p>
                </div>
              </div>

              <div class="col-lg-3 col-md-6">
                <div class="item-process-content">
                  <h4> Assistive Tasks</h4>
                  <div class="icon-box">
                    <span>03</span>
                  </div>
                  <p>The assistant sends giving receipts, giving reminders, customized scriptures and daily articles etc</p>
                </div>
              </div>

              <div class="col-lg-3 col-md-6">
                <div class="item-process-content">
                  <h4> Forecast</h4>
                  <div class="icon-box">
                    <span>04</span>
                  </div>
                  <p>Our forecasting is designed to help churches grow in all areas over the next 12-month period</p>
                </div>
              </div>

            </div>
          </div>
        </div>
      </section>
      <!-- End process
      ================================================== -->

    <!-- our-feature
    ================================================== -->
    <section id="features" class="our-feature our-feature-3 pb-70">
        <div class="container">
          <div class="row">

            <div class="col-lg-6 mb-30">
              <div class="box-img">
                <img src="<?=$path;?>external/img/m4-bg-3.jpg" alt="">
              </div>
            </div>

            <div class="col-lg-6 mb-30">
              <div class="box-content" style="padding-top:0px;">

                <div>
                  <div class="content-title">
                    <span class="vertical-text">Key Features</span>
                    <h5>GROW CLOUD CORE FEATURES</h5>
                    <h2>Key Features That Makes Grow Cloud Tick</h2>
                  </div>
                  <p class="mb-30">Grow Cloud empowers a Church Pastor with a 360 degree view of the activities within the church for effective monitoring and arms the Pastor with prompt and accurate data for accurate decision making planning<br><br>
                  Grow was also designed to be compliant with the recently introduced Data Protection and Privacy laws. </p>
                </div>

                <div class="tab-box mb-30">
                  <div class="tabs-wrap">
                    <div class="tabs">
                      <div class="selector"></div>
                      <h5 id="tab-1" class="button active">Membership</h5>
                      <h5 id="tab-2" class="button">Follow ups</h5>
                      <h5 id="tab-3" class="button">Giving</h5>
                      <h5 id="tab-4" class="button">Attendance</h5>
                    </div>
                  </div>
                </div>
                

                <div class="items  mb-30">
                  <div id="tab-1-con" class="item">
                    <div class="norebro-text-sc ">
                      <ul class="list-box">
                        <li>
                          <span class="icon jam jam-check"></span>
                          <span class="tit">Add or create and also update a new member </span>
                        </li>
                        <li>
                          <span class="icon jam jam-check"></span>
                          <span class="tit">Monitor member growth(baptism, bible study etc)</span>
                        </li>
                        <li>
                            <span class="icon jam jam-check"></span>
                          <span class="tit">Organizes and easily sort out your members and their details
</span>
                        </li>
                      </ul>
                    </div>
                  </div>

                  <div id="tab-2-con" class="item">
                    <div class="norebro-text-sc ">
                      <ul class="list-box">
                        <li>
                          <span class="icon jam jam-check"></span>
                          <span class="tit">Add or create and also update a new soul </span>
                        </li>
                        <li>
                          <span class="icon jam jam-check"></span>
                          <span class="tit">Keep up with people from their first visit to their baptism. </span>
                        </li>
                        <li>
                            <span class="icon jam jam-check"></span>
                          <span class="tit">One or more leaders can be involed in a soul follow up 
</span>
                        </li>
                      </ul>
                    </div>
                  </div>

                  <div id="tab-3-con" class="item">
                    <div class="norebro-text-sc ">
                        <ul class="list-box">
                          <li>
                            <span class="icon jam jam-check"></span>
                            <span class="tit">Online giving services for the Church</span>
                          </li>
                          <li>
                            <span class="icon jam jam-check"></span>
                            <span class="tit">Easily track giving for your congregation</span>
                          </li>
                          <li>
                              <span class="icon jam jam-check"></span>
                            <span class="tit">Identify slumps with graphs for giving trends</span>
                          </li>
                        </ul>
                    </div>
                  </div>

                  <div id="tab-4-con" class="item">
                    <div class="norebro-text-sc ">
                      <ul class="list-box">
                          <li>
                            <span class="icon jam jam-check"></span>
                            <span class="tit">Attendance system that allows you see trends and absences</span>
                          </li>
                          <li>
                            <span class="icon jam jam-check"></span>
                            <span class="tit">Submit service attendance report</span>
                          </li>
                          <li>
                              <span class="icon jam jam-check"></span>
                            <span class="tit">Mass communication system for the Church</span>
                          </li>
                        </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>
      <!-- End Our Features
      ================================================== -->

      
    <!-- Pricing
    ================================================== -->
    <section id="pricing" class="pricing">
      <div class="part-top cover-bg  parallax" data-image-src="<?=$path;?>external/img/main-img.jpg" data-overlay='7'>
        <div class="container">
          <div class="row">
            <div class="col-12">
              <div class="content-title content-title-2">
                <span class="vertical-text">Our Pricing</span>
                <h5>Your first 30 days are free! — no credit card required</h5>
                <h2>GROW Cloud Pricelist</h2>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="part-bottom">
        <div class="container">
          <div class="row">

            <div class="col-lg-4">
              <div class="pricing-table text-center">
                <h4 class="title mb-5">Free</h4>
                
                <div class="price">
                  <h3><span>$</span>0</h3>
                  <br>
                  <div class="inter">1 MONTH</div>
                  <p>Have access to the basic GROW Cloud's features for the Church</p>
                </div>

                <ul class="list-box">
                  <li>
                    <span class="icon jam jam-check"></span>
                    <span class="tit">Membership</span>
                  </li>
                  <li>
                    <span class="icon jam jam-check"></span>
                    <span class="tit">Follow ups</span>
                  </li>
                  <li>
                    <span class="icon jam jam-check"></span>
                    <span class="tit">Attendance Trends</span>
                  </li>
                  <li class=" disabled">
                    <span class="icon jam jam-close"></span>
                    <span class="tit">Reports</span>
                  </li>
                  <li class=" disabled">
                    <span class="icon jam jam-close"></span>
                    <span class="tit">Dashboard</span>
                  </li>
                  <li class=" disabled">
                    <span class="icon jam jam-close"></span>
                    <span class="tit">Online givings</span>
                  </li>
                </ul>

                <a href="<?=base_url('/welcome/register/trial')?>" class="btn mt-15">
                  <span class="text">Get Started</span>
                </a>
              </div>
            </div>

            <div class="col-lg-4">
              <div class="pricing-table text-center">
                <h4 class="title mb-5">Standard</h4>
                
                <div class="price">
                  <h3>$300</h3>
                  <br>
                  <div class="inter">1 QUARTER</div>
                  <p>Have access to all the GROW Cloud's features for the Church for a quarter</p>
                </div>

                <ul class="list-box">
                  <li>
                    <span class="icon jam jam-check"></span>
                    <span class="tit">Membership</span>
                  </li>
                  <li>
                    <span class="icon jam jam-check"></span>
                    <span class="tit">Follow ups</span>
                  </li>
                  <li>
                    <span class="icon jam jam-check"></span>
                    <span class="tit">Attendance Trends</span>
                  </li>
                  <li>
                    <span class="icon jam jam-check"></span>
                    <span class="tit">Reports</span>
                  </li>
                  <li>
                    <span class="icon jam jam-check"></span>
                    <span class="tit">Dashboard</span>
                  </li>
                  <li>
                    <span class="icon jam jam-check"></span>
                    <span class="tit">Online givings</span>
                  </li>
                </ul>

                <a href="<?=base_url('/welcome/register/standard')?>" class="btn mt-15">
                  <span class="text">Get Started</span>
                </a>
              </div>
            </div>

              <div class="col-lg-4">
              <div class="pricing-table text-center">
                <h4 class="title mb-5">Gold</h4>
                
                <div class="price">
                  <h3>$1000</h3>
                  <br>
                  <div class="inter">1 YEAR</div>
                  <p>Have access to all the GROW Cloud's features for the Church for a year and get an extra one month free!</p>
                </div>

                <ul class="list-box">
                  <li>
                    <span class="icon jam jam-check"></span>
                    <span class="tit">Membership</span>
                  </li>
                  <li>
                    <span class="icon jam jam-check"></span>
                    <span class="tit">Follow ups</span>
                  </li>
                  <li>
                    <span class="icon jam jam-check"></span>
                    <span class="tit">Attendance Trends</span>
                  </li>
                  <li>
                    <span class="icon jam jam-check"></span>
                    <span class="tit">Reports</span>
                  </li>
                  <li>
                    <span class="icon jam jam-check"></span>
                    <span class="tit">Dashboard</span>
                  </li>
                  <li>
                    <span class="icon jam jam-check"></span>
                    <span class="tit">Online givings</span>
                  </li>
                </ul>

                <a href="<?=base_url('/welcome/register/gold')?>" class="btn mt-15">
                  <span class="text">Get Started</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End Pricing
    ================================================== -->


      <!-- testimonial
      ================================================== -->
      <section id="testimonial" class="testimonial section-padding">
        <div class="container">
          <div class="row">
            <div class="col-12">
              <div class="content-title">
                <span class="vertical-text">TESTIMONIAL</span>
                <h5>Get in touch with us to see how</h5>
                <h2>Our clients say</h2>
              </div>
            </div>

            <div class="col-12 testimonial-box">
              <div class="owl-carousel owl-theme">
                  <div class="item-testimonial">
                    <div class="row">
                      <div class="col-md-4">
                        <div class="box-avatar">
                          <div class="box-img cover-bg" data-image-src="<?=$path;?>external/img/testimonial/01.jpg"></div>
                          <div>
                            <h5>Pastor Zoe Ofunne</h5>
                            <h6>Regional Pastor EUR LVZ</h6>
                          </div>
                        </div>
                      </div>
      
                      <div class="col-md-8">
                        <div>
                          <p>Wow..this is an awesome platform, technology us here to stay!</p>
      
                        </div>
                      </div>
                    </div>
                    
                  </div>                  
      
                </div>
            </div>

          </div>
        </div>

<!--
        <div class="testimonial-brand mt-30 mb-30">
          <div class="container">
            <div class="owl-carousel owl-theme">
              <div class="item">
                <a href="demo-video.html#">
                  <img src="img/testimonial/brand/1.png" alt="">
                </a>
              </div>

              <div class="item">
                <a href="demo-video.html#">
                  <img src="img/testimonial/brand/2.png" alt="">
                </a>
              </div>

              <div class="item">
                <a href="demo-video.html#">
                  <img src="img/testimonial/brand/3.png" alt="">
                </a>
              </div>

              <div class="item">
                <a href="demo-video.html#">
                  <img src="img/testimonial/brand/1.png" alt="">
                </a>
              </div>

              <div class="item">
                <a href="demo-video.html#">
                  <img src="img/testimonial/brand/2.png" alt="">
                </a>
              </div>

              <div class="item">
                <a href="demo-video.html#">
                  <img src="img/testimonial/brand/3.png" alt="">
                </a>
              </div>

            </div>
          </div>
        </div>
-->
      </section>
      <!-- End testimonial
      ================================================== -->

      <!-- contact
      ================================================== -->
      <section id="contact" class="contact">
        <div class="part-top  cover-bg parallax"  data-image-src="<?=$path;?>external/img/bg-4.jpg" data-overlay='7'>
          <div class="container">
            <div class="row">
              <div class="col-12">
                <div class="content-title content-title-2">
                  <span class="vertical-text">Contact</span>
                  <h5>Get In Touch</h5>
                  <h2>Get Contact</h2>
                </div>
              </div>

            </div>
          </div>
        </div>

        <div class="part-bottom">
          <div class="container">
            <div class="row">
              <div class="col-lg-7 mb-30">
                <div class="contact-form">
                  <h4>Send Us A Message</h4>
                  <form class="form" id="contact-form" action="contact.php" data-toggle="validator">
                    <div class="messages"></div>
                    <div class="controls">
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group">
                            <input id="form_name" type="text" name="name" placeholder="Name *" required="required" data-error="name is required.">
                            <div class="help-block with-errors"></div>
                          </div>
                        </div>
    
                        <div class="col-md-6">
                          <div class="form-group">
                              <input id="form_email" type="email" name="email" placeholder="Email *" required="required" data-error="Valid email is required.">
                              <div class="help-block with-errors"></div>
                          </div>
                        </div>
    
                        <div class="col-md-12">
                          <div class="form-group">
                              <input id="form_subject" type="text" name="subject" placeholder="subject">
                          </div>
                        </div>
    
                        <div class="col-md-12 form-group">
                          <textarea id="form_message" name="text" class="form-control" placeholder=" Type Your Message " required data-error="Please leave us a message."></textarea>
                          <div class="help-block with-errors"></div>
                        </div>
    
                        <div class="col-md-12">
                          <button class="btn">
                            <span class="text">Send Message</span>
                          </button>
                        </div>
    
                      </div>
                    </div>
                  </form>
                </div>
              </div>

              <div class="col-lg-5 mb-30">
                <div class="box-info">
                  <h4>Contact Info</h4>

                  <p class="mb-20">Questions? Enquiries? Feedbacks? Please write us and we will surely get back at you.</p>

                  <div class="item mb-20">
                    <i class="jam jam-map-marker-f"></i>
                    <h5>No 1 Ize-Iyamu close, off Billings Way <br> Lagos, Nigeria</h5>
                  </div>

                  <div class="item mb-20">
                    <i class="jam jam-envelope"></i>
                    <h5><a href="#">growteam@loveworld360.com
</a> <br><a href="#">growteam@loveworld360.com
</a> </h5>
                  </div>

                  <div class="item">
                    <i class="jam jam-phone"></i>
                    <h5>(001) 8686 234 432<br> Office - (001) 2345 678 900 </h5>
                  </div>

<!--
                  <div class="social-icon mt-20">
                    <a href="https://smartic-1.netlify.com/0#" class="facebook"><span><i class="fab fa-facebook-f"></i></span></a>
                    <a href="https://smartic-1.netlify.com/0#" class="twitter"><span><i class="fab fa-twitter"></i></span></a>
                    <a href="https://smartic-1.netlify.com/0#" class="dribbble"><span><i class="fab fa-dribbble"></i></span></a>
                    <a href="https://smartic-1.netlify.com/0#" class="linkedin"><span><i class="fab fa-linkedin-in"></i></span></a>
                  </div>
-->

                </div>
              </div>
    
            </div>
          </div>
        </div>
      </section>
      <!-- End Contact
      ================================================== -->

    </main>

    <!-- Footer
    ================================================== -->
    <footer class="footer footer-fixed text-center">
      <div class="container">
        <div class="row">

          <div class="logo">
            <img src="<?=$path;?>external/img/logo-2.png" alt="logo" class="logo-1">
          </div>
<!--
          <div class="scoial-icon text-center">
            <a href="demo-video.html#0"><span><i class="fab fa-facebook-f"></i></span></a>
            <a href="demo-video.html#0"><span><i class="fab fa-twitter"></i></span></a>
            <a href="demo-video.html#0"><span><i class="fab fa-linkedin-in"></i></span></a>
            <a href="demo-video.html#0"><span><i class="fab fa-google-plus-g"></i></span></a>
          </div>
-->
        </div>
      </div>
      <div class="footer-bootom">
        <div class="container">
          <div class="cop">
            <h6>© 2018 Powered By CeFlix Scepter</h6>
          </div>
        </div>
      </div>
    </footer>
    <!-- End Footer
    ================================================== -->

    <!-- Modal -->
    <div id="loginView" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Login</h4>
                </div>
                <div class="modal-body">
                    <p>Insert URL</p>
                    <div class="row">
                        <div class="col-md-8">
                            <input type="text" class="form-control" id="urlModal">
                        </div>
                        <div class="col-md-4">
                            <button class="btn-primary btn-sm form-control" id="urlBtn">Go</button>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-default btn-sm" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="<?=$path;?>external/js/jquery-3.1.1.min.js"></script>
    <script src="<?=$path;?>external/js/popper.min.js"></script>
    <script src="<?=$path;?>external/js/bootstrap.min.js"></script>

    <!-- owl carousel js -->
    <script src="<?=$path;?>external/js/owl.carousel.min.js"></script>

    <!-- typed -->
    <script src="<?=$path;?>external/js/typed.js"></script>
    
    <!-- parallax -->
    <script src="<?=$path;?>external/js/parallaxie.min.js"></script>

    <!-- magnific-popup -->
    <script src="<?=$path;?>external/js/jquery.fancybox.min.js"></script>
    
    <!-- YouTubePopUp -->
    <script src="<?=$path;?>external/js/YouTubePopUp.jquery.js"></script>

		<!-- isotope.pkgd.min js -->
		<script src="<?=$path;?>external/js/isotope.pkgd.min.js"></script>
    <script src="<?=$path;?>external/js/validator.js"></script>
    <script src="<?=$path;?>external/js/custom.js"></script>

    <script type="text/javascript">
        $(document).ready(function(){
            var url = document.getElementById('urlModal');
            $('#urlBtn').on('click', function(){

//                location.href = 'http://'+url+ '.'+ location.host+'/cloud';
                if(url !== ''){
                    var base_url = (location.host == 'localhost') ? location.host+'/cloud/cloud' : location.host+ '/cloud';
                    location.href = 'http://'+url.value+ '.'+ base_url;
                }
            });
        });
    </script>

    </body>
</html>
