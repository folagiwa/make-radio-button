<?php
/**
 * File       : footer_form_blank.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 10/3/18
 * Time: 22:36
 */
$path = base_url().'assets/';

?>


<?php include('footer_blank.php');?>


<!--<!-- Javascript -->-->
<!--<!-- Vendors -->-->
<!--<script src="--><?//=$path;?><!--vendors/bower_components/jquery/dist/jquery.min.js"></script>-->
<!--<script src="--><?//=$path;?><!--vendors/bower_components/popper.js/dist/umd/popper.min.js"></script>-->
<!--<script src="--><?//=$path;?><!--vendors/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>-->
<!--<script src="--><?//=$path;?><!--vendors/bower_components/jquery.scrollbar/jquery.scrollbar.min.js"></script>-->
<!--<script src="--><?//=$path;?><!--vendors/bower_components/jquery-scrollLock/jquery-scrollLock.min.js"></script>-->
<!---->
<!--<script src="--><?//=$path;?><!--vendors/bower_components/autosize/dist/autosize.min.js"></script>-->
<!---->
<!--<script src="--><?//=$path;?><!--js/app.min.js"></script>-->



<script src="<?=$path;?>vendors/bower_components/jquery-mask-plugin/dist/jquery.mask.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/select2/dist/js/select2.full.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/dropzone/dist/min/dropzone.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/moment/min/moment.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/flatpickr/dist/flatpickr.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/nouislider/distribute/nouislider.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/trumbowyg/dist/trumbowyg.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/rateYo/min/jquery.rateyo.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/jquery-text-counter/textcounter.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/autosize/dist/autosize.min.js"></script>
