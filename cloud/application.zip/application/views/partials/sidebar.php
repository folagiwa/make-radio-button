<?php
/**
 * File       : sidebar.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/4/18
 * Time: 3:00 PM
 */
$path = base_url().'assets/';
$map = $this->session->logged_in;
$mem = member_info();
?>


<aside class="sidebar">
    <div class="scrollbar-inner">

        <div class="user">
            <div class="user__info" data-toggle="dropdown">
                <img class="user__img" src="<?=$path;?>demo/img/profile-pics/8.jpg" alt="">
                <div>
                    <div class="user__name"><?php echo $mem['first_name'].' '.$mem['surname']; ?></div>
                    <div class="user__email"><?php echo ucwords($map['user_type']); ?></div>
                </div>
            </div>

            <div class="dropdown-menu">
                <a class="dropdown-item" href="">View Profile</a>
                <a class="dropdown-item" href="">Settings</a>
                <a class="dropdown-item" href="<?php echo base_url('accounts/logout'); ?>">Logout</a>
            </div>
        </div>

        <ul class="navigation">
            <li><a href="<?php echo base_url('dashboard/pastor'); ?>"><i class="fa fa-home"></i> Dashboard</a></li>
           <?php echo $links;?>
            <li><a href="<?php echo base_url('accounts/logout'); ?>"><i class="fa fa-power-off"></i> Signout</a></li>
        </ul>
    </div>
</aside>
<div class="themes">
    <div class="scrollbar-inner">
        <a href="" class="themes__item" data-sa-value="1"><img src="<?=$path;?>img/bg/1.jpg" alt=""></a>
        <a href="" class="themes__item active" data-sa-value="2"><img src="<?=$path;?>img/bg/2.jpg" alt=""></a>
        <a href="" class="themes__item" data-sa-value="3"><img src="<?=$path;?>img/bg/3.jpg" alt=""></a>
        <a href="" class="themes__item" data-sa-value="4"><img src="<?=$path;?>img/bg/4.jpg" alt=""></a>
        <a href="" class="themes__item" data-sa-value="5"><img src="<?=$path;?>img/bg/5.jpg" alt=""></a>
        <a href="" class="themes__item" data-sa-value="6"><img src="<?=$path;?>img/bg/6.jpg" alt=""></a>
        <a href="" class="themes__item" data-sa-value="7"><img src="<?=$path;?>img/bg/7.jpg" alt=""></a>
        <a href="" class="themes__item" data-sa-value="8"><img src="<?=$path;?>img/bg/8.jpg" alt=""></a>
        <a href="" class="themes__item" data-sa-value="9"><img src="<?=$path;?>img/bg/9.jpg" alt=""></a>
        <a href="" class="themes__item" data-sa-value="10"><img src="<?=$path;?>img/bg/10.jpg" alt=""></a>
    </div>
</div>

<section class="content">
    <div class="content__inner">
        <header class="content__title">
            <h1><?php echo isset($title) ? $title : '';?></h1>
            <div class="actions">

            </div>
        </header>

