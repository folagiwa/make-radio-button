<?php
/**
 * File:    dashboard_template_raw
 * @Author: XYZoe
 * @email:  zoechuksimm@loveworld360.com
 * Date:    01/11/2018
 * Time:    07:23
 */

$path = base_url().'assets/';
?>

<div class="flot-chart flot-dynamic invisible"style="padding: 0px;position: relative;height: 0.5px;"></div>

<div class="row quick-stats">
    <div class="col-sm-6 col-md-3">
        <div class="quick-stats__item">
            <div class="quick-stats__info">
                <h2>987,459</h2>
                <small>Total Leads Recieved</small>
            </div>

            <div class="quick-stats__chart peity-bar">6,4,8,6,5,6,7,8,3,5,9</div>
        </div>
    </div>

    <div class="col-sm-6 col-md-3">
        <div class="quick-stats__item">
            <div class="quick-stats__info">
                <h2>356,785K</h2>
                <small>Total Website Clicks</small>
            </div>

            <div class="quick-stats__chart peity-bar">4,7,6,2,5,3,8,6,6,4,8</div>
        </div>
    </div>

    <div class="col-sm-6 col-md-3">
        <div class="quick-stats__item">
            <div class="quick-stats__info">
                <h2>$58,778</h2>
                <small>Total Sales Orders</small>
            </div>

            <div class="quick-stats__chart peity-bar">9,4,6,5,6,4,5,7,9,3,6</div>
        </div>
    </div>

    <div class="col-sm-6 col-md-3">
        <div class="quick-stats__item">
            <div class="quick-stats__info">
                <h2>214</h2>
                <small>Total Support Tickets</small>
            </div>

            <div class="quick-stats__chart peity-bar">5,6,3,9,7,5,4,6,5,6,4</div>
        </div>
    </div>
</div>

<br>

<div class="row">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Line Chart with curved edges</h4>
                <h6 class="card-subtitle">Curved edges made possible with the help of curvedLines Flot plugin.</h6>

                <div class="flot-chart flot-curved-line"></div>
                <div class="flot-chart-legends flot-chart-legends--curved"></div>
            </div>
        </div>
    </div>

    <div class="col-lg-6">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Line Chart</h4>

                <div class="flot-chart flot-line"></div>
                <div class="flot-chart-legends flot-chart-legends--line"></div>
            </div>
        </div>
    </div>
</div>

<div data-columns>
    <div class="card widget-past-days">
        <div class="card-body">
            <h4 class="card-title">For the past 30 days</h4>
            <h6 class="card-subtitle">Pellentesque ornare sem lacinia quam</h6>
        </div>

        <div class="widget-past-days__main">
            <div class="flot-chart flot-chart--sm flot-past-days" style="padding: 0px; position: relative;"><canvas class="flot-base" width="489" height="100" style="direction: ltr; position: absolute; left: 0px; top: 0px; width: 489px; height: 100px;"></canvas><canvas class="flot-overlay" width="489" height="100" style="direction: ltr; position: absolute; left: 0px; top: 0px; width: 489px; height: 100px;"></canvas></div>
        </div>

        <div class="card widget-past-days">

            <div class="listview listview--striped">
                <div class="listview__item">
                    <div class="widget-past-days__info">
                        <small>Page Views</small>
                        <h3>47,896,536</h3>
                    </div>

                    <div class="widget-past-days__chart hidden-sm">
                        <div class="peity-bar">6,9,5,6,3,7,5,4,6,5,6,4,2,5,8,2,6,9</div>
                    </div>
                </div>

                <div class="listview__item">
                    <div class="widget-past-days__info">
                        <small>Site Visitors</small>
                        <h3>24,456,799</h3>
                    </div>

                    <div class="widget-past-days__chart hidden-sm">
                        <div class="peity-bar">5,7,2,5,2,8,6,7,6,5,3,1,9,3,5,8,2,4</div>
                    </div>
                </div>

                <div class="listview__item">
                    <div class="widget-past-days__info">
                        <small>Total Clicks</small>
                        <h3>13,965</h3>
                    </div>

                    <div class="widget-past-days__chart hidden-sm">
                        <div class="peity-bar">5,7,2,5,2,8,6,7,6,5,3,1,9,3,5,8,2,4</div>
                    </div>
                </div>

                <div class="listview__item">
                    <div class="widget-past-days__info">
                        <small>Total Returns</small>
                        <h3>198</h3>
                    </div>

                    <div class="widget-past-days__chart hidden-sm">
                        <div class="peity-bar">3,9,1,3,5,6,7,6,8,2,5,2,7,5,6,7,6,8</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card widget-signups">
        <div class="card-body">
            <h4 class="card-title">Most Recent Signups</h4>
            <h6 class="card-subtitle">Magna cursus malesuada lacinia</h6>

            <div class="widget-signups__list">
                <a data-toggle="tooltip" title="" href="" data-original-title="Jani Popovich"><img class="avatar-img" src="demo/img/profile-pics/1.jpg" alt=""></a>
                <a data-toggle="tooltip" title="" href="" data-original-title="Rosina Lamont"><div class="avatar-char">R</div></a>
                <a data-toggle="tooltip" title="" href="" data-original-title="Wava Vermeulen"><div class="avatar-char">W</div></a>
                <a data-toggle="tooltip" title="" href="" data-original-title="Delisa Sheilds"><img class="avatar-img" src="demo/img/profile-pics/2.jpg" alt=""></a>
                <a data-toggle="tooltip" title="" href="" data-original-title="Elsy Wilhoit"><img class="avatar-img" src="demo/img/profile-pics/3.jpg" alt=""></a>
                <a data-toggle="tooltip" title="" href="" data-original-title="Deanne Jeffreys"><div class="avatar-char">D</div></a>
                <a data-toggle="tooltip" title="" href="" data-original-title="ddsds"><div class="avatar-char">F</div></a>
                <a data-toggle="tooltip" title="" href="" data-original-title="Shery Heredia"><div class="avatar-char">S</div></a>
                <a data-toggle="tooltip" title="" href="" data-original-title="Gaylord Coolbaugh"><div class="avatar-char">G</div></a>
                <a data-toggle="tooltip" title="" href="" data-original-title="Lyda Wortman"><div class="avatar-char">L</div></a>
                <a data-toggle="tooltip" title="" href="" data-original-title="Corene Langstaff"><img class="avatar-img" src="demo/img/profile-pics/4.jpg" alt=""></a>
                <a data-toggle="tooltip" title="" href="" data-original-title="Aracely Goudeau"><img class="avatar-img" src="demo/img/profile-pics/5.jpg" alt=""></a>
                <a data-toggle="tooltip" title="" href="" data-original-title="Matilde Weibel"><div class="avatar-char">M</div></a>
                <a data-toggle="tooltip" title="" href="" data-original-title="Clement Mayor"><div class="avatar-char">C</div></a>
                <a data-toggle="tooltip" title="" href="" data-original-title="Phil Wyatt"><div class="avatar-char">P</div></a>
                <a data-toggle="tooltip" title="" href="" data-original-title="Altagracia Manke"><div class="avatar-char">A</div></a>
                <a data-toggle="tooltip" title="" href="" data-original-title="Siu Derosier"><div class="avatar-char">S</div></a>
                <a data-toggle="tooltip" title="" href="" data-original-title="Nigel Shipe"><img class="avatar-img" src="demo/img/profile-pics/6.jpg" alt=""></a>
                <a data-toggle="tooltip" title="" href="" data-original-title="Bossman"><div class="avatar-char">B</div></a>
                <a data-toggle="tooltip" title="" href="" data-original-title="Crystal Markel"><div class="avatar-char">C</div></a>
                <a data-toggle="tooltip" title="" href="" data-original-title="Noman Nottage"><div class="avatar-char">N</div></a>
                <a data-toggle="tooltip" title="" href="" data-original-title="Melonie Carreira"><img class="avatar-img" src="demo/img/profile-pics/7.jpg" alt=""></a>
                <a data-toggle="tooltip" title="" href="" data-original-title="Shaneka Hoyle"><div class="avatar-char">S</div></a>
                <a data-toggle="tooltip" title="" href="" data-original-title="Milagro Evans"><div class="avatar-char">M</div></a>
            </div>
        </div>
    </div>

    <div class="card widget-contacts">
        <div class="card-body">
            <h4 class="card-title">Contact Information</h4>
            <h6 class="card-subtitle">Fusce eget dolor id justo luctus commodo vel pharetra nisi</h6>

            <ul class="icon-list">
                <li><i class="zmdi zmdi-phone"></i> 00971123456789</li>
                <li><i class="zmdi zmdi-email"></i> malinda.h@gmail.com</li>
                <li><i class="zmdi zmdi-facebook-box"></i> malinda.hollaway</li>
                <li><i class="zmdi zmdi-twitter"></i> @malinda (twitter.com/malinda)</li>
                <li><i class="zmdi zmdi-pin"></i>
                    <address>
                        44-46 Morningside Road,
                        Edinburgh,
                        Scotland
                    </address>
                </li>
            </ul>
        </div>

        <a class="widget-contacts__map" href="">
            <img src="demo/img/widgets/map.png" alt="">
        </a>
    </div>

</div>