<?php
/**
 * File:    dashboard_template
 * @Author: XYZoe
 * @email:  zoechuksimm@loveworld360.com
 * Date:    31/10/2018
 * Time:    12:15
 */

$path = base_url().'assets/';
?>

<!--    In your full life, DON'T TOUCH THE NEXT LINE!!! Just leave am like that bico!-->
    <div class="flot-chart flot-dynamic invisible"style="padding: 0px;position: relative;height: 0.5px;"></div>

<?php echo tabs_dash($content); ?>

<br>

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title"><strong><?=date('F') .':';?></strong> <?=lang('dashboard_graph_title');?></h4>
                    <h6 class="card-subtitle"><?=lang('dashboard_graph_subtitle');?></h6>

                    <div id="chartdiv" style="width:100%; height:400px;"></div>
                </div>
            </div>
        </div>
    </div>

    <div data-columns>
        <div class="card widget-past-days">
            <div class="card-body">
                <h4 class="card-title"><?=$serv_title;?></h4>
                <h6 class="card-subtitle"><?=$serv_subtitle;?></h6>
            </div>

            <div class="card widget-past-days">

                <div class="listview listview--striped">
                    <?php echo report_stats_sec($content_2); ?>

                </div>
            </div>
        </div>

        <div class="card widget-signups">
            <div class="card-body">
                <h4 class="card-title">Trending first Timers</h4>
                <h6 class="card-subtitle">Quick look at the most recent first timers in Church</h6>

                <div class="widget-signups__list">

                    <?php
                    $mem_num    = '1';
                    $tabm = [
                        ['mem_link'=> '#',  'mem_name'=>'Zoe Ofunne',   'mem_source'=>$path .'demo/img/profile-pics/' .$mem_num .'.jpg'],
                        ['mem_link'=> '#',  'mem_name'=>'Chuks Akunne', 'mem_source'=>$path .'demo/img/profile-pics/' .$mem_num .'.jpg']
                    ];

                    echo $m = members_pix_list($tabm);
                    ?>

<!--                    <a data-toggle="tooltip" title="" href="" data-original-title="Jani Popovich"><img class="avatar-img" src="--><?//=$path;?><!--demo/img/profile-pics/1.jpg" alt=""></a>-->
<!--                    <a data-toggle="tooltip" title="" href="" data-original-title="Rosina Lamont"><div class="avatar-char">R</div></a>-->
                </div>
            </div>
        </div>

        <div class="card widget-contacts">

            <?php
            $tabc = [
                [   'church_name'=> 'XYGrace International',    'church_phone'=>'08189052626',
                    'church_email'=>'7xyzoe@gmail.com',         'church_fb'=>'xygrace.church',
                    'church_tw'=>'@xygrace',                    'church_address'=>'No 1 Billings Way, Oregun']
            ];
            echo $c = church_contact($tabc);
            ?>

            <a class="widget-contacts__map" href="">
                <img src="<?=$path;?>demo/img/widgets/map.png" alt="">
            </a>
        </div>

    </div>