<?php
/**
 * File       : dashboard_script.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 10/11/18
 * Time: 12:24
 */
$path = base_url().'assets/';

?>
<script src="<?=$path;?>vendors/bower_components/salvattore/dist/salvattore.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/flot/jquery.flot.js"></script>
<script src="<?=$path;?>vendors/bower_components/flot/jquery.flot.resize.js"></script>
<script src="<?=$path;?>vendors/bower_components/flot.curvedlines/curvedLines.js"></script>
<script src="<?=$path;?>vendors/bower_components/jqvmap/dist/jquery.vmap.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/jqvmap/dist/maps/jquery.vmap.world.js"></script>
<script src="<?=$path;?>vendors/bower_components/jquery.easy-pie-chart/dist/jquery.easypiechart.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/peity/jquery.peity.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/moment/min/moment.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/fullcalendar/dist/fullcalendar.min.js"></script>

<!--AM Charts-->
<script src="<?=$path;?>demo/js/amcharts/amcharts.js"></script>
<script src="<?=$path;?>demo/js/amcharts/serial.js"></script>
<script src="<?=$path;?>demo/js/amcharts/custom-time.js"></script>

<!-- Charts and maps-->
<script src="<?=$path;?>demo/js/flot-charts/curved-line.js"></script>
<script src="<?=$path;?>demo/js/flot-charts/line.js"></script>
<script src="<?=$path;?>demo/js/flot-charts/dynamic.js"></script>
<script src="<?=$path;?>demo/js/flot-charts/chart-tooltips.js"></script>
<script src="<?=$path;?>demo/js/other-charts.js"></script>
<script src="<?=$path;?>demo/js/jqvmap.js"></script>

<!-- App functions and actions -->
