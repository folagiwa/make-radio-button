<?php $path = base_url().'assets/';?>

<footer class="footer hidden-xs-down">
    <p>© <?php echo date('Y'); ?> Grow Cloud. All Rights Reserved.</p>
</footer>
</section>
</main>

<script src="<?=$path;?>vendors/bower_components/jquery/dist/jquery.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/popper.js/dist/umd/popper.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/jquery.scrollbar/jquery.scrollbar.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/jquery-scrollLock/jquery-scrollLock.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js" integrity="sha256-0YPKAwZP7Mp3ALMRVB2i8GXeEndvCq3eSl/WsAl1Ryk=" crossorigin="anonymous"></script>

<?php echo isset($scripts) ? $scripts : ''; ?>

<!-- App functions and actions -->
<script src="<?=$path;?>js/app.min.js"></script>
<script src="<?=$path;?>js/custom.js"></script>


</body>
</html>