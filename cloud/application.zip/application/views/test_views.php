<?php
////
$this->CI =& get_instance();
$path = base_url().'assets/';
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Vendor styles -->
    <link rel="stylesheet" href="<?=$path;?>vendors/bower_components/material-design-iconic-font/dist/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="<?=$path;?>vendors/bower_components/animate.css/animate.min.css">
    <link rel="stylesheet" href="<?=$path;?>vendors/bower_components/jquery.scrollbar/jquery.scrollbar.css">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

    <!-- App styles -->
    <link rel="stylesheet" href="<?=$path;?>css/app.min.css">
</head>

<body data-sa-theme="1">



        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Basic example</h4>
                <h6 class="card-subtitle">DataTables is a plug-in for the jQuery Javascript library. It is a highly flexible tool, based upon the foundations of progressive enhancement, and will add advanced interaction controls to any HTML table.</h6>

                <div class="table-responsive">
                    <table id="data-table" class="table">
                        <thead>
                        <tr>
                            <th>Name</th>
                            <th>Position</th>
                            <th>Office</th>
                            <th>Age</th>
                            <th>Start date</th>
                            <th>Salary</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td>Tiger Nixon</td>
                            <td>System Architect</td>
                            <td>Edinburgh</td>
                            <td>61</td>
                            <td>2011/04/25</td>
                            <td>$320,800</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>



<!-- Javascript -->
<!--vendors -->
<script src="<?=$path;?>vendors/bower_components/jquery/dist/jquery.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/popper.js/dist/umd/popper.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/jquery.scrollbar/jquery.scrollbar.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/jquery-scrollLock/jquery-scrollLock.min.js"></script>

<!--vendors: Data tables -->
<script src="<?=$path;?>vendors/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/jszip/dist/jszip.min.js"></script>
<script src="<?=$path;?>vendors/bower_components/datatables.net-buttons/js/buttons.html5.min.js"></script>

<!-- App functions and actions -->
<script src="<?=$path;?>js/app.min.js"></script>
</body>
</html>