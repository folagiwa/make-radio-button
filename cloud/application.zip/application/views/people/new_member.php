<?php
/**
 * ------------------------------------------------------- *
 * File         : new_member.php.v.1.0
 * Created for  : PROJECT GROW.
 * @Author      : Giwa Folake
 * @Email       : askeben@loveworld360.com
 * @Kingschat   : +233261562716
 * Date         : 8/02/17
 * Time         : 9:50 AM
 * ------------------------------------------------------- *
 */

$path = base_url().'assets/';

$church = $this->session->logged_in['church_id'];
//$member = $this->session->logged_in['member_id'];


$form_data = [];
if(is_array($member_info)){

    $data = $member_info;

} else {

    $data = [

        'member_id'             => '',
        'church_id'             => $church,
        'title'                 => '',
        'surname'               => '',
        'first_name'            => '',
        'birth_date'            => '',
        'gender'                => '',
        'mobile_phone'          => '',
        //'cell_phone'          => '',
        //'work_phone'          => '',
        'email_address'         => '',
        'country'               => $dc,
        'state'                 => $ds,
        'city'                  => '',
        'home_address'          => '',
        'nearest_landmark'      => '',
        'marital_status'        => '',
        'profession'            => '',
        'first_day_in_church'   => '',
        'invited_by'            => '',
        'prayer_request'        => '',
        'visit_time'            => '',
        'group_assigned'        => '',
        'is_new_convert'        => '',
        'is_baptised'           => '',
        'member_picture'        => '',
        'created_by'            => ''
    ];
}


//start here




    $form_a = [
        [
            'name' => 'member_id',
            //'label'       =>  lang('member'),
            'class' => 'form-control form-control-sm',
            'id' => 'member_id',
            'type' => 'hidden',
            'placeholder' => 'member_id',
            'value' => $data['member_id']
        ]
    ];
    echo make_form($form_a);

    $form_b = [
        [
            'name' => 'church_id',
            //'label'       =>  lang('member'),
            'class' => 'form-control form-control-sm',
            'id' => 'church_id',
            'type' => 'hidden',
            'placeholder' => '',
            'value' => $data['church_id']
        ]
    ];
    echo make_form($form_b);

echo form_error('title');

    $data_title = [
        ['label' => lang('rev'),        'title' => 'Rev'],
        ['label' => lang('pastor'),     'title' => 'Pastor'],
        ['label' => lang('deacon'),     'title' => 'Deacon'],
        ['label' => lang('deaconess'),  'title' => 'Deaconess'],
        ['label' => lang('brother'),    'title' => 'Brother'],
        ['label' => lang('sister'),     'title' => 'Sister'],
        ['label' => lang('elder'),      'title' => 'Elder'],
        ['label' => lang('evangelist'), 'title' => 'Evangelist'],
        ['label' => lang('prophet'),    'title' => 'Prophet'],
        ['label' => lang('none'),       'title' => 'None'],
    ];

    echo make_drop('title', lang('title'), $data_title, 'title', 'label', $data['title']);

    $form_c = [
        [
            'name' => 'surname',
            'label' => lang('surname'),
            'class' => 'form-control form-control-sm',
            'id' => 'surname',
            'type' => 'text',
            'value' => $data['surname'],
            'placeholder' => lang('surname'),
            'required' => 'required'
        ]];

    echo make_form($form_c);

echo form_error('surname');

    $form_d = [
        [
            'name' => 'first_name',
            'label' => lang('first_name'),
            'class' => 'form-control form-control-sm',
            'id' => 'first_name',
            'type' => 'text',
            'placeholder' => 'first name',
            'value' => $data['first_name'],
            'required' => 'required'
        ]];
    echo make_form($form_d);


?>
<div id="toggle_birth_day">
    <?php
    $form_f = [
        [
            'data-mask'=>'00/00/0000',
            'name' => 'birth_date',
            'label' => lang('birth_date'),
            'class' => 'form-control date-picker flatpickr-input active',
            //'class' => 'form-control input-mask flatpickr-input active',
            'id' => 'birth_date',
            'type' => 'text',
            'value' => $data['birth_date'],
            'placeholder' => lang('date'),
            'required' => 'required'
        ]
    ];
    echo make_form($form_f);
?>
</div>

<div id="country_toggle">
    <?php
    echo make_drop('country', lang('country'), $data_drop, 'country_id', 'country_name', $data['country']);
?>
</div>

<div id="state_toggle">
    <?php
    echo make_drop('state', lang('state'), $states, 'state_id', 'state_name', $data['state']);

    ?>
</div>

<div id="city_toggle">
<?php
    echo make_drop('city', lang('city'), $cities, 'city_id', 'city_name', $data['city']);
?>
</div>

<div id="gender_toggle">
    <?php
    $data_d3 = [

        [
            'name' => 'gender',
            'label' => $this->lang->line('male'),
            'class' => 'form-control custom-radio',
            'id' => 'gender',
            'value' => 'male'
        ],

        [
            'name' => 'gender',
            'label' => $this->lang->line('female'),
            //'class'         =>  'custom-control custom-radio',
            'id' => 'gender',
            'value' => 'female'
        ]

    ];
//array, selected, label
    echo make_radio($data_d3, $data['gender'], $this->lang->line('gender'));
?>
</div>

<div id="marital_status_toggle">
<?php
    $marital_status = [

        ['label' => lang('single'), 'marital_status' => 'single'],
        ['label' => lang('married'), 'marital_status' => 'married'],
        ['label' => lang('widowed'), 'marital_status' => 'widowed'],
    ];

    echo make_drop('marital_status', lang('marital_status'), $marital_status, 'marital_status', 'label', $data['marital_status']);
?>
</div>

<div id="mobile_phone_toggle">
    <?php
$form_e = [

        [   'data-mask' =>'000-00-00000000',
            'name'      => 'mobile_phone',
            'label'     => lang('mobile_phone'),
            'class'     => 'form-control input-mask',
            'type'      => 'text',
            'value'     => $data['mobile_phone'],
            'placeholder' => lang('format'),
            'required' => 'required',
            'hint' => lang('no_phone')
        ]];

    echo make_form($form_e);
    ?>
</div>

<!--<div id="phone_toggle">-->
<!--    --><?php
//    $form_g = [
//
//        [
//            'data-mask'=>"000-00-0000000",
//            'name' => 'work_phone',
//            'label' => lang('work_phone'),
//            'class' => 'form-control input-mask',
//            'type' => 'text',
//            'value' => $data['work_phone'],
//            'placeholder' => lang('format'),
//            'required' => 'required',
//            'hint' => lang('no_phone')
//        ]];
//
//    echo make_form($form_g);
//    ?>
<!--</div>-->

<div id="email_toggle">
<?php
    $form_aa = [
        [
            'name' => 'email_address',
            'label' => lang('email_address'),
            'class' => 'form-control form-control-sm',
            'id' => 'email_address',
            'type' => 'text',
            'placeholder' => 'folake@yopmail.com',
            'value' => $data['email_address'],
            'required' => 'required'
        ]];
    echo make_form($form_aa);
    ?>
</div>

<div id="home_address_toggle">
    <?php
    $form_ab = [
        [
            'name' => 'home_address',
            'label' => lang('home_address'),
            'class' => 'form-control form-control-sm',
            'id' => 'home_address',
            'type' => 'text',
            'value' => $data['home_address'],
            'required' => 'required'
        ]];
    echo make_form($form_ab);
    ?>
</div>

<div id="group_assigned_toggle">
    <?php
    $label_group = [

        ['label' => lang('assign_later'),   'group_assign' => 'assign later'],
        ['label' => lang('choir'),          'group_assign' => 'Choir'],
        ['label' => lang('usher'),          'group_assign' => 'Usher'],
    ];

    echo make_drop('group_assigned', lang('group_assign'), $label_group, 'group_assign', 'label', $data['group_assigned']);
    ?>
</div>


<?php
//$label_group = ['tag_name','marital_status','age_class'];
//echo make_drop('group_assigned',$this->lang->line('group_assigned'),'','cell_id',$label_group,$data['group_assigned']);
?>

<div id="profession_toggle">
    <?php
    $this->load->view('people/professions', $data);
    ?>
</div>

<?php
//firsttimers starts here
if($this->uri->segment(2) == 'first_timers'){
    $ft_form = [
        [
            'name' => 'first_day_in_church',
            'label' => lang('first_day_in_church'),
            'class' => 'form-control date-picker flatpickr-input active',
            'id' => 'first_day_in_church',
            'type' => 'text',
            'placeholder' => 'first_day_in_church',
            'value' => $data['first_day_in_church'],
            'required' => 'required'
        ]];

    echo make_form($ft_form);

    $ft_a = [
        [
            'name' => 'prayer_request',
            'label' => lang('prayer_request'),
            'class' => 'form-control form-control-sm',
            'id' => 'prayer_request',
            'type' => 'text',
            'placeholder' => 'prayer_request',
            'value' => $data['prayer_request'],
            'required' => 'required'
        ],

        [
            'name' => 'visit_time',
            'label' => lang('visit_time'),
            'class' => 'form-control time-picker flatpickr-input active',
            'id' => 'visit_time',
            'type' => 'text',
            'value' => $data['visit_time'],
            'required' => 'required'
        ],
    ];
    echo make_form($ft_a);


    $form_ft = [
        [
            'name' => 'nearest_landmark',
            'label' => lang('nearest_landmark'),
            'class' => 'form-control form-control-sm',
            'id' => 'nearest_landmark',
            'type' => 'text',
            'value' => $data['nearest_landmark']

        ]];

    echo make_form($form_ft);


    $new_convert = [

        [
            'name' => 'is_new_convert',
            'label' => lang('yes'),
            'id' => 'is_new_convert',
            'value' => 'yes'
        ],

        [
            'name' => 'is_new_convert',
            'label' => lang('no'),
            'id' => 'is_new_convert',
            'value' => 'no'
        ]

    ];
    echo make_radio($new_convert, $data['is_new_convert'], lang('is_new_convert'));

    $baptised = [
        [
            'name' => 'is_baptised',
            'label' => lang('yes'),
            'id' => 'is_baptised',
            'value' => 'yes'
        ],

        [
            'name' => 'is_baptised',
            'label' => lang('no'),
            'id' => 'is_baptised',
            'value' => 'no'
        ]

    ];
    echo make_radio($baptised, $data['is_baptised'], lang('is_baptised'));

    $invited_by = [

        ['label' => lang('somebody'), 'invited_by' => 'somebody'],
        ['label' => lang('anybody'), 'invited_by' => 'anybody'],
        ['label' => lang('nobody'), 'invited_by' => 'nobody'],
    ];

    echo make_drop('invited_by', lang('invited_by'), $invited_by, 'invited_by', 'label', $data['invited_by']);

//    $form_cp = [
//
//        [
//            'data-mask' => "000-00-0000000",
//            'name' => 'cell_phone',
//            'label' => lang('cell_phone'),
//            'class' => 'form-control input-mask',
//            'type' => 'text',
//            'value' => $data['cell_phone'],
//            'placeholder' => lang('format'),
//            'required' => 'required',
//            'hint' => lang('no_phone')
//        ]];
//
//    echo make_form($form_cp);
}

//end of first timers data
?>
<div id="profile_picture_toggle">
    <?php
    $form_bf = [
        [
            'name'  => 'member_picture',
            'label' => lang('member_picture_upload'),
            'class' => 'dropzone dz-clickable',
            'id'    => 'dropzone-upload',
            'type'  => 'file',
            'value' => '',
            'hint'  => lang('pic_legend')

        ]
    ];

    echo make_form($form_bf);
    ?>
</div>




