<?php
/**
 * File       : import_members.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 10/12/18
 * Time: 10:08
 */


$church = $this->session->logged_in['church_id'];
?>
<?php

if(isset($_SESSION['status'])){
    $status = $_SESSION['status'];
    $success = $status['success'];
    $errors = $status['invalid'];
    if($success > 0){
        $info = $success.' '.lang('success_upload');
        echo alert_success($info);
    }
    if($errors > 0){
        $message = $errors.' '.lang('error_upload');
        $label = lang('details');
        echo alert_error_msg($message,'import_member_errors',$label);
    }

    unset($_SESSION['status']);
}
?>
<?php $path = base_url().'assets/'; ?>



                            <?php $form_info = [

    [
        'name'      =>  'file_name',
        'id'        =>  'files',
        'class'     =>  'form-control input-transparent',
        'label'     =>  lang('upload_file'),
        'type'      =>  'file',
        //'value'     =>  'file_name',
        'required'  =>  'required'
    ]

];
                            echo make_form($form_info);



if($this->uri->segment(2)=='members'){
    $mail =[
        [
            'name'          =>  'send_email',
            'label'         =>  lang('yes'),
            'id'            =>  'send_email',
            'value'         =>  'yes'
        ],

        [
            'name'          =>  'send_email',
            'label'         =>  lang('no'),
            'id'            =>  'send_email',
            'value'         =>  'no'
        ]

    ];
    echo make_radio($mail, 'yes',lang('send_account_email'));
}

                            ?>











