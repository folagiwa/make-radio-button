<?php
/**
 * File       : First_timers.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/11/18
 * Time: 2:55 PM
 */

class First_timers extends Church_Admin_Controller{
    protected $links;

    function __construct()
    {
        parent::__construct();
        $this->lang->load('model',$this->session->language);
        $this->load->library('people_lib');
        $this->links = create_menus($this->menu_items());

    }
    public function index(){
        $data['sub_title']= 'You are logged in as Admin';
        $data['title'] = $this->lang->line('zone_growth');
        $data['content'] = 'Church growth, attendance graph, growth history, church level'; //describe method in one line
        $data['links'] = $this->links;
        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
        $this->load->view('partials/master',$data);
    }


    public function add_first_timer()
    {
        $legend = 'Fill this form to create a nw member';
        $action = 'church/first_timers/add_first_timers';
        $success_page = 'church/first_timers/add_first_timers';
        $this->people_lib->new_member($legend,$this->links,$action,$success_page);
    }
    public function first_timers(){
        $this->people_lib->member_list($this->links);
    }

    public function overview(){
        $data['sub_title']= 'You are logged in as Admin';
        $data['title'] = $this->lang->line('overview');
        $data['content'] = 'Fellowship Ministry Overview, over any date range, church level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
        $this->load->view('partials/master',$data);
    }
    public function add_first_timers(){
        $data['sub_title']= 'You are logged in as Admin';
        $data['title'] = $this->lang->line('add_first_timers');
        $data['content'] = 'Add first timers to a cell, attendance graph, growth history, church level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
        $this->load->view('partials/master',$data);
    }
    public function manage_first_timers(){
        $data['sub_title']= 'You are logged in as Admin';
        $data['title'] = $this->lang->line('manage_first_timers');
        $data['content'] = 'First timer structure over any period, church level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
        $this->load->view('partials/master',$data);
    }

    public function manage_follow_up_reports(){
        $data['sub_title']= 'You are logged in as Admin';
        $data['title'] = $this->lang->line('manage_follow_up_reports');
        $data['content'] = 'Manage growth level, church level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
        $this->load->view('partials/master',$data);
    }

    public function soul_winners(){
        $data['sub_title']= 'You are logged in as Admin';
        $data['title'] = $this->lang->line('soul_winners');
        $data['content'] = 'Soul winners at group, church and zonal level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
        $this->load->view('partials/master',$data);
    }

    public function retention_ratio(){
        $data['sub_title']= 'You are logged in as Admin';
        $data['title'] = $this->lang->line('retention_ratio');
        $data['content'] = 'Ratio of total first timers to retained first timers of any date range at group, church and  zonal level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
        $this->load->view('partials/master',$data);
    }

    public function distribution_by_city(){
        $data['sub_title']= 'You are logged in as Admin';
        $data['title'] = $this->lang->line('distribution_by_city');
        $data['content'] = ' Distribution over any period, zonal level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
        $this->load->view('partials/master',$data);
    }

    public function first_timer_reports(){
        $data['sub_title']= 'You are logged in as Admin';
        $data['title'] = $this->lang->line('first_timer_reports');
        $data['content'] = 'Cummulative first timer report over any period, zonal level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
        $this->load->view('partials/master',$data);
    }

    public function first_timer_sources(){
        $data['sub_title']= 'You are logged in as Admin';
        $data['title'] = $this->lang->line('first_timer_sources');
        $data['content'] = 'Pie chart of first timers and sources that brought them all time at church, group and zonal level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
        $this->load->view('partials/master',$data);
    }

}