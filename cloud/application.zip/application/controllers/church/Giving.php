<?php
/**
 * File       : Giving.php
 * @Auhor     : Segun Aruleba
 * @email     : segunaruleba@loveworld360.com
 * @kingschat : +2348121724280
 * Date: 9/11/18
 * Time: 3:50 PM
 */

class Giving extends Church_Admin_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->library('giving_lib');
    }


    public function new_giving_category(){
        $action = 'giving/new_giving_category';
        $legend = lang('create_category');
        $links  = create_menus($this->menu_items());
        $this->giving_lib->new_giving_category($legend,$links,$action);
    }

    public function new_giving(){
        $action = 'giving/new_giving';
        $legend = $this->lang->line('fill_in_form');
        $links  = create_menus($this->menu_items());
        $this->giving_lib->new_giving($legend,$links,$action);
    }
    public function delete_giving_record(){
        $id = cloud_encode($this->uri->segment('3'));
        $this->db->where('record_id', $id);
        $this->db->delete('grow_giving_records');
        redirect('giving/new_giving','refresh');


    }





}