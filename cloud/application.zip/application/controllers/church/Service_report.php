<?php
/**
 * File:    Service_report
 * @Author: XYZoe
 * @email:  zoechuksimm@loveworld360.com
 * Date:    02/10/2018
 * Time:    14:57
 */

class Service_report extends Church_Admin_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->library('service_report_lib');
        $this->load->library('people_lib');
                $this->load->library('dashboard_all_lib');

    }

    public function service_reports(){
        $legend    = lang('service_report_sec');
        $links     = create_menus($this->menu_items());
        $action    = 'church/service_report/service_reports';
        $data['sub_title']      = 'You are logged in as Admin';
        $this->service_report_lib->new_service_report($legend,$links,$action);
    }

//    public function table(){
////        $data['links']= create_menus($this->menu_items());
////        $data['sub_title'] = 'You are logged in as Admin';
////        $data['title'] = 'Submit Service Report';
////        $data['action'] = 'service_report/table';
////        $this->load->view('partials/service_reports/new_report');
//        $data['handle'] = $this->load->view('partials/service_reports/new_report', TRUE);
////        $this->load->view('partials/master', $data);
//    }

}