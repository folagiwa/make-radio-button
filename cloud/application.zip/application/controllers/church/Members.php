<?php
/**
 * File       : Members.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/11/18
 * Time: 3:12 PM
 */
class Members extends Church_Admin_Controller
{

    protected $links;
    function __construct()
    {
        parent::__construct();
        $this->lang->load('model',$this->session->language);
        $this->load->library('people_lib');
        $this->links = create_menus($this->menu_items());
    }




    public function add_member()
    {
        $legend = 'Fill this form to create a nw member';
        $action = 'church/members/add_member';
        $success_page = 'church/members/add_member';
        $this->people_lib->new_member($legend,$this->links,$action,$success_page);
    }

    public function members(){
        $this->people_lib->member_list($this->links);
    }

    public function import_members(){
        $legend = lang('legend_im');
        $data['sub_title'] = lang('');
        $action = 'church/members/import_members';
        $this->people_lib->import_members($legend,$this->links,$action);
    }


    public function manage_members()
    {
        $data['sub_title'] = 'You are logged in as Admin';
        $data['title'] = $this->lang->line('manage_members');
        $data['content'] = 'Manage growth report, attendance graph, growth history, church level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank', $data, TRUE);
        $this->load->view('partials/master', $data);
    }

//    public function import_members()
//    {
//        $data['sub_title'] = 'You are logged in as ';
//        $data['title'] = $this->lang->line('import_members');
//        $data['content'] = 'Import Members Growth structure over any period, church level'; //describe method in one line
//        $data['links'] = create_menus($this->menu_items());
//        $data['handle'] = $this->load->view('partials/blank', $data, TRUE);
//        $this->load->view('partials/master', $data);
//    }

    public function member_profile()
    {
        $data['sub_title'] = 'You are logged in as ';
        $data['title'] = $this->lang->line('member_profile');
        $data['content'] = 'Member profile, zonal level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank', $data, TRUE);
        $this->load->view('partials/master', $data);
    }

    public function birthdays()
    {
        $data['sub_title'] = 'You are logged in as ';
        $data['title'] = $this->lang->line('birthdays');
        $data['content'] = 'Members Birthdays over any period, church level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank', $data, TRUE);
        $this->load->view('partials/master', $data);
    }

    public function distribution_by_city()
    {
        $data['sub_title'] = 'You are logged in as ';
        $data['title'] = $this->lang->line('distribution_by_city');
        $data['content'] = 'Members near the city over any period, church level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank', $data, TRUE);
        $this->load->view('partials/master', $data);
    }

    public function member_financial_growth_summary()
    {
        $data['sub_title'] = 'You are logged in as ';
        $data['title'] = $this->lang->line('member_financial_growth_summary');
        $data['content'] = 'Show individual complete finance records';
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank', $data, TRUE);
        $this->load->view('partials/master', $data);
    }

    public function growth_report()
    {
        $data['sub_title'] = 'You are logged in as ';
        $data['title'] = $this->lang->line('growth_report');
        $data['content'] = 'Cumulative growth report over any period, church level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank', $data, TRUE);
        $this->load->view('partials/master', $data);
    }

//    public function add_member(){
//        $data['title']  = 'New Member';
//        $data['sub_title'] = 'Please fill all the fields with asteriks ';
//        $data['legend'] = $this->lang->line('new_member');
//        $data['action'] = 'cloud/test';
//        $data['links'] = create_menus($this->menu_items());
//        $data['form_content'] = $this->load->view('people/new_member',$data,TRUE);
//        $data['handle'] = $this->load->view('partials/blank_form',$data,TRUE);
//        $this->load->view('partials/master', $data);
//    }


}