<?php
/**
 * File       : First_timers.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/11/18
 * Time: 2:55 PM
 */

class Outreaches extends Church_Admin_Controller{

    function __construct()
    {
        parent::__construct();
        $this->lang->load('model',$this->session->language);

    }
    public function index(){
        $data['sub_title']= 'You are logged in as Admin';
        $data['title'] = $this->lang->line('zone_growth');
        $data['content'] = 'Church growth, attendance graph, growth history, church level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
        $this->load->view('partials/master',$data);
    }

    public function overview(){
        $data['sub_title']= 'You are logged in as Admin';
        $data['title'] = $this->lang->line('overview');
        $data['content'] = 'Fellowship Ministry Overview, over any date range, church level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
        $this->load->view('partials/master',$data);
    }
    public function events(){
        $data['sub_title']= 'You are logged in as Admin';
        $data['title'] = $this->lang->line('events');
        $data['content'] = 'Add first timers to a cell, attendance graph, growth history, church level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
        $this->load->view('partials/master',$data);
    }
    public function manage_souls(){
        $data['sub_title']= 'You are logged in as Admin';
        $data['title'] = $this->lang->line('manage_first_timers');
        $data['content'] = 'First timer structure over any period, church level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
        $this->load->view('partials/master',$data);
    }

    public function import_souls(){
        $data['sub_title']= 'You are logged in as Admin';
        $data['title'] = $this->lang->line('manage_follow_up_reports');
        $data['content'] = 'Manage growth level, church level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
        $this->load->view('partials/master',$data);
    }

    public function media_feedback(){
        $data['sub_title']= 'You are logged in as Admin';
        $data['title'] = $this->lang->line('soul_winners');
        $data['content'] = 'Soul winners at group, church and zonal level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
        $this->load->view('partials/master',$data);
    }

    public function impact_report(){
        $data['sub_title']= 'You are logged in as Admin';
        $data['title'] = $this->lang->line('retention_ratio');
        $data['content'] = 'Ratio of total first timers to retained first timers of any date range at group, church and  zonal level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
        $this->load->view('partials/master',$data);
    }


}