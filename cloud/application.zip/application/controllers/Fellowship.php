<?php
/**
 * File       : Fellowship.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/10/18
 * Time: 5:59 PM
 */

class Fellowship extends Church_Admin_Controller{

    function __construct()
    {
        parent::__construct();
        $this->lang->load('model',$this->session->language);
    }

    public function index(){
        $data['sub_title'] = 'You are logged in as Admin';
        $data['title'] = 'Dashboard';
        $data['content'] = 'Ministry growth, attendance graph, church level';
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank', $data, TRUE);
        $this->load->view('partials/master', $data);
    }

    public function overview(){
        $data['sub_title'] = 'You are logged in as Admin';
        $data['title'] = 'Dashboard';
        $data['content'] = 'Fellowship Ministry overview,  growth, attendance graph, church level';
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank', $data, TRUE);
        $this->load->view('partials/master', $data);
    }

    public function fellowship_reports(){
        $data['sub_title'] = 'You are logged in as Admin';
        $data['title']    = $this->lang->line('fellowship_reports');
        $data['content']  = 'Cumulative growth report, attendance graph, growth history, zonal level';
        $data['links']    = create_menus($this->menu_items());
        $data['handle']   = $this->load->view('partials/blank', $data, TRUE);
        $this->load->view('partials/master', $data);
    }

    public function manage_group(){
        $data['title'] = $this->lang->line('manage_group');
        $data['content'] = 'This page is for create, edit, view, sort, filter';
        $data['sub_title'] = 'You are logged in as Admin';
        $data['handle'] = $this->load->view('partials/blank', $data, TRUE);
        $data['links'] = create_menus($this->menu_items());
        $this->load->view('partials/master', $data);
    }

    public function cell_outline(){
        $data['sub_title']= 'You are logged in as Admin';
        $data['title'] = $this->lang->line('fellowship_outline');
        $data['content'] = 'Create new cell outline, shows existing cell outline'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
        $this->load->view('partials/master',$data);
    }

    public function group_leaders(){
        $data['sub_title']= 'You are logged in as Admin';
        $data['title'] = $this->lang->line('group_leaders');
        $data['content'] = 'Potential Cell Leader over any period, group, church and zonal level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
        $this->load->view('partials/master',$data);
    }

    public function growth_history(){
        $data['sub_title']= 'You are logged in as Admin';
        $data['title'] = $this->lang->line('growth_history');
        $data['content'] = 'Growth History over any period, group, church and zonal level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
        $this->load->view('partials/master',$data);
    }

    public function members_missing_church(){
        $data['sub_title']= 'You are logged in as Admin';
        $data['title'] = $this->lang->line('members_missing_church');
        $data['content'] = 'Show cell members who have been absence in church consecutively, group, church and zonal level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
        $this->load->view('partials/master',$data);
    }

    public function members_missing_cell_meeting(){
        $data['sub_title']= 'You are logged in as Admin';
        $data['title'] = $this->lang->line('members_missing_cell_meeting');
        $data['content'] = 'Members who have been absent from cell meetings for two weeks, group, church and zonal level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
        $this->load->view('partials/master',$data);
    }

//    public function cell_ministry_report(){
//        $data['sub_title']= 'You are logged in as Admin';
//        $data['title'] = $this->lang->line('cell_ministry_report');
//        $data['content'] = 'Cell ministry report over any period, group, church and zonal level'; //describe method in one line
//        $data['links'] = create_menus($this->menu_items());
//        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
//        $this->load->view('partials/master',$data);
//    }
}