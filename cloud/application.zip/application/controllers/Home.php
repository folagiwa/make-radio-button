<?php
/**
 * File       : Test.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/4/18
 * Time: 3:09 PM
 */

class Home extends Church_Admin_Controller {

    public function __construct()
    {
        parent::__construct();
    }

//    public function index(){
//     $this->dashboard();
//    }
//
//    public function dashboard(){
//        //$info = $this->menu_items();
//        $data['links']= create_menus($this->menu_items());
//        $data['sub_title'] = 'You are logged in as Admin';
//        $data['title'] = 'Grow Cloud';
//        $data['content'] = 'Cloud details goes here';
//        $data['handle'] = $this->load->view('partials/dashboard', $data, TRUE);
//        $this->load->view('partials/master', $data);
//    }



    public function tables(){
        $data['links']= create_menus($this->menu_items());
        $data['sub_title'] = 'You are logged in as Admin';
        $data['title'] = 'Title goes here';
        $data['content'] = 'Table content details goes here';
        $data['handle'] = $this->load->view('partials/tables', $data, TRUE);
        $this->load->view('partials/master', $data);
    }

    public function form(){
            $data['links']= create_menus($this->menu_items());
            $data['sub_title'] = 'You are logged in as Admin';
            $data['title'] = 'Grow Cloud';
            $data['content'] = 'Cloud details goes here';
            $data['handle'] = $this->load->view('partials/form', $data, TRUE);
            $this->load->view('partials/master', $data);
    }

    public function test(){
        $data['title']  = 'New Member';
        $data['sub_title'] = 'Please fill all the fields with asteriks ';
        $data['legend'] = $this->lang->line('users');
        $data['action'] = 'cloud/test';
        $data['links'] = '';
        $data['form_content'] = $this->load->view('church/new_report',$data,TRUE);
        $data['handle'] = $this->load->view('partials/blank_form',$data,TRUE);
        $this->load->view('partials/master', $data);
    }



}