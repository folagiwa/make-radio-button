<?php
/**
 * File       : Accounts.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/11/18
 * Time: 4:11 PM
 */
Class Accounts extends Church_Admin_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('users_lib');
    }


    public function index()
    {
        $data['subtitle'] = 'You are logged in as ';
        $data['title'] = $this->lang->line('accounts');
        $data['content'] = 'Detail account profile of logged in user, view and edit';
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank', $data, TRUE);
        $this->load->view('partials/master', $data);
    }

    public function settings()
    {
        $data['subtitle'] = 'You are logged in as ';
        $data['title'] = $this->lang->line('settings');
        $data['content'] = 'User preferences, reminder, currency, emails, messages, report frequency, church level';
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank', $data, TRUE);
        $this->load->view('partials/master', $data);
    }

    public function users()
    {
        $data['subtitle'] = 'You are logged in as ';
        $data['title'] = $this->lang->line('users');
        $data['content'] = 'List of users in system, edit user, reset passwords, grant privileges, ';
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank', $data, TRUE);
        $this->load->view('partials/master', $data);
    }

    public function profile()
    {
        $data['subtitle'] = 'You are logged in as ';
        $data['title'] = $this->lang->line('profile');
        $data['content'] = 'Detail account profile of logged in user, view and edit ';
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank', $data, TRUE);
        $this->load->view('partials/master', $data);
    }

    public function logout()
    {
        $this->users_lib->logout();
    }


}