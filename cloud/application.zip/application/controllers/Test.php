<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * File       : Test.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/26/18
 * Time: 10:28 PM
 */

Class Test extends Church_Admin_Controller {

    function __construct()
    {
        parent::__construct();
    }

    public function test(){
        $data['subtitle'] = 'You are logged in as ';
        $data['title'] = $this->lang->line('users');
        $data['action'] = 'cloud/test';
        $data['links'] = create_menus($this->menu_items());;
        $data['form_content'] = $this->load->view('church/new_report',$data,TRUE);
        //$data['handle'] = $this->load->view('partials/blank_form');
        $this->load->view('partials/master', $data);
    }
}