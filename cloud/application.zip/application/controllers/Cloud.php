<?php
/**
 * File       : Cloud.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/20/18
 * Time: 10:40 AM
 */

class Cloud extends MY_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->library('users_lib');
      //$this->links =  create_menus($this->menu_items());
        if(!subdomain_exists()){
            redirect(base_url());
        }

    }

    public function index(){
        $this->users_lib->index();
    }

    public function login(){

        $this->users_lib->logout();
    }

    public function logout(){
        $this->login();
    }

    public function activate_user(){

        $this->users_lib->activate_user();
    }


    ///////////// TEST METHOD //////////////////
    public function show(){
        $this->load->view('email/new_account');
    }




    public function test(){
        $data['title']  = 'New Member';
        $data['sub_title'] = 'Please fill all the fields with asteriks ';
        $data['legend'] = $this->lang->line('users');
        $data['action'] = 'cloud/test';
        $data['links'] = '';
        $data['form_content'] = $this->load->view('church/new_report',$data,TRUE);
        $data['handle'] = $this->load->view('partials/blank_form',$data,TRUE);
        $this->load->view('partials/master', $data);
    }

    public function select_state(){
        $country_id = $this->input->post('church_country');
        $state = $this->states_model->where(['country_id'=>$country_id])->get_all();
        echo make_drop('church_state','state', $state,'state_id','state_name');

    }
    public function select_city(){
        $state_id = $this->input->post('church_state');
        $cities = $this->cities_model->where(['state_id'=>$state_id])->get_all();
        echo make_drop('church_city','city_id',$cities,'city_id','city_name');
    }



}