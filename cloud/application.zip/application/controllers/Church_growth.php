<?php
/**
 * File       : Church_growth.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/11/18
 * Time: 2:41 PM
 */

class Church_growth extends Church_Admin_Controller{

    function __construct()
    {
        parent::__construct();
        $this->lang->load('model',$this->session->language);

    }

    public function index(){
        $data['sub_title']= 'You are logged in as Admin ';
        $data['title'] = $this->lang->line('church_growth');
        $data['content'] = 'Church growth, attendance graph, growth history, church level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
        $this->load->view('partials/master',$data);
    }

    public function attendance(){
        $data['sub_title']= 'You are logged in as Admin';
        $data['title'] = $this->lang->line('attendance');
        $data['content'] = 'Attendance for Sunday, wednesday over any date range, church level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
        $this->load->view('partials/master',$data);
    }
    public function financial(){
        $data['sub_title']= 'You are logged in as Admin';
        $data['title'] = $this->lang->line('financial');
        $data['content'] = 'Offering, tithe , partnership, zonal level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
        $this->load->view('partials/master',$data);
    }
    public function new_converts(){
        $data['sub_title']= 'You are logged in as Admin';
        $data['title'] = $this->lang->line('new_converts');
        $data['content'] = 'Cummulative new converts over any period, church level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
        $this->load->view('partials/master',$data);
    }

    public function first_timers(){
        $data['sub_title']= 'You are logged in as Admin';
        $data['title'] = $this->lang->line('first_timers');
        $data['content'] = 'First timers over any given period, church level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
        $this->load->view('partials/master',$data);
    }




}