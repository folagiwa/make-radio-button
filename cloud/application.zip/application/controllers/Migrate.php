<?php
/**
 * File       : Migrate.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/18/18
 * Time: 5:41 PM
 */

class Migrate extends CI_Controller
{

    public function index()
    {
        $this->load->library('migration');

        ini_set('memory_limit', '512M');


        if ($this->migration->current() === FALSE)
        {
            show_error($this->migration->error_string());
        }
        else {
            echo 'Migration Worked';
        }
    }

}