<?php
/**
 * File       : Giving.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/11/18
 * Time: 3:50 PM
 */

class Giving extends Church_Admin_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->library('giving_lib');
    }

//    public function index(){
//        $data['sub_title']= 'You are logged in as Admin';
//        $data['title'] = $this->lang->line('overview');
//        $data['content'] = 'Zonal growth, attendance graph, growth history, church level'; //describe method in one line
//        $data['links'] = create_menus($this->menu_items());
//        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
//        $this->load->view('partials/master',$data);
//    }


//    public function records(){
//        $data['sub_title']= 'You are logged in as ';
//        $data['title'] = $this->lang->line('records');
//        $data['content'] = 'Create, edit, list, search, delete giving records at church level'; //describe method in one line
//        $data['links'] = create_menus($this->menu_items());
//        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
//        $this->load->view('partials/master',$data);
//    }

    public function new_giving_category(){
        $action = 'giving/new_giving_category';
        $legend = lang('create_category');
        $links  = create_menus($this->menu_items());
        $this->giving_lib->new_giving_category($legend,$links,$action);
    }

    public function new_giving(){
        $action = 'giving/new_giving';
        $legend = $this->lang->line('fill_in_form');
        $links  = create_menus($this->menu_items());
        $this->giving_lib->new_giving($legend,$links,$action);
    }

//    public function categories(){
//        $data['sub_title']= 'You are logged in as ';
//        $data['title'] = $this->lang->line('categories');
//        $data['content'] = 'Create, edit, list, search giving categories at church level'; //describe method in one line
//        $data['links'] = create_menus($this->menu_items());
//        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
//        $this->load->view('partials/master',$data);
//    }

//    public function pledges(){
//        $data['sub_title']= 'You are logged in as ';
//        $data['title'] = $this->lang->line('pledges');
//        $data['content'] = 'Shows total pledges over a current year at church level'; //describe method in one line
//        $data['links'] = create_menus($this->menu_items());
//        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
//        $this->load->view('partials/master',$data);
//    }
//
//    public function administrators(){
//        $data['sub_title'] = 'You are logged in as ';
//        $data['title'] = $this->lang->line('administrators');
//        $data['content'] = 'Create, edit, list, search, filter, sort partnership administrators at group, church and zonal level'; //describe method in one line
//        $data['links'] = create_menus($this->menu_items());
//        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
//        $this->load->view('partials/master',$data);
//    }
//
//
//    public function reminders(){
//        $data['sub_title']= 'You are logged in as ';
//        $data['title'] = $this->lang->line('reminders');
//        $data['content'] = 'Update the  a partners at church level'; //describe method in one line
//        $data['links'] = create_menus($this->menu_items());
//        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
//        $this->load->view('partials/master',$data);
//    }
//
//    public function member_not_giving(){
//        $data['sub_title']= 'You are logged in as ';
//        $data['title'] = $this->lang->line('member_not_giving');
//        $data['content'] = 'Display the list of non partnering member at church level'; //describe method in one line
//        $data['links'] = create_menus($this->menu_items());
//        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
//        $this->load->view('partials/master',$data);
//    }

//    public function giving_reports() {
//        $data['sub_title']= 'You are logged in as ';
//        $data['title'] = $this->lang->line('giving_reports');
//        $data['content'] = 'Provides giving report for specific givings arm in any date range at church level'; //describe method in one line
//        $data['links'] = create_menus($this->menu_items());
//        $data['handle'] = $this->load->view('partials/blank',$data, TRUE);
//        $this->load->view('partials/master',$data);
//    }


}