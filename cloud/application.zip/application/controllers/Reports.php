<?php
/**
 * File       : Reports.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 7/15/17
 * Time: 5:19 PM
 */
Class Reports extends Church_Admin_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->lang->load('model', $this->session->language);


    }

    public function index()
    {
        $data['sub_title'] = 'You are logged in as ';
        $data['title'] = $this->lang->line('overview');
        $data['content'] = 'Church growth, attendance graph, growth history at church  level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank', $data, TRUE);
        $this->load->view('partials/master', $data);
    }

    public function reports()
    {
        $data['sub_title'] = 'You are logged in as ';
        $data['title'] = $this->lang->line('reports');
        $data['content'] = 'reports goes here'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank', $data, TRUE);
        $this->load->view('partials/master', $data);
    }

    public function monthly_report()
    {
        $data['sub_title'] = 'You are logged in as ';
        $data['title'] = $this->lang->line('monthly_report');
        $data['content'] = 'Generate monthly reports for any given month at church level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank', $data, TRUE);
        $this->load->view('partials/master', $data);
    }

    public function quarterly_report()
    {
        $data['sub_title'] = 'You are logged in as ';
        $data['title'] = $this->lang->line('quarterly_report');
        $data['content'] = 'Generate quarterly report at church level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank', $data, TRUE);
        $this->load->view('partials/master', $data);
    }

    public function mid_year_report()
    {
        $data['sub_title'] = 'You are logged in as ';
        $data['title'] = $this->lang->line('mid_year_report');
        $data['content'] = 'Generate mid year report at group, church, zonal level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank', $data, TRUE);
        $this->load->view('partials/master', $data);
    }

    public function annual_report()
    {
        $data['sub_title'] = 'You are logged in as ';
        $data['title'] = $this->lang->line('annual_report');
        $data['content'] = 'Generate annual report at church level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank', $data, TRUE);
        $this->load->view('partials/master', $data);
    }

    public function custom_report()
    {
        $data['sub_title'] = 'You are logged in as ';
        $data['title'] = $this->lang->line('custom_report');
        $data['content'] = 'Generate Custom report at church level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank', $data, TRUE);
        $this->load->view('partials/master', $data);
    }
}