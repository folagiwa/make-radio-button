<?php
/**
 * File       : Dashboard.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/5/18
 * Time: 1:55 PM
 */

class Dashboard extends Church_Admin_Controller{

    protected $CI;

    public function __construct()
    {
        parent::__construct();
        $this->load->library('dashboard_all_lib');
        $this->CI =& get_instance();

    }

    public function index(){
       $this->pastor();
    }

    public function pastor(){
        $links  = create_menus($this->menu_items());
        $action = 'dashboard/pastor';
        $this->dashboard_all_lib->church_tab_stats($action,$links);
    }


}