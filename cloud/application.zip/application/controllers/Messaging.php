<?php
/**
 * File       : Messaging.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/11/18
 * Time: 3:59 PM
 */


Class Messaging extends Church_Admin_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->lang->load('model', $this->session->language);


    }

    public function index()
    {
        $data['sub_title'] = 'You are logged in as ' ;
        $data['title'] = $this->lang->line('overview');
        $data['content'] = 'Church growth, attendance graph, growth history at church level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank', $data, TRUE);
        $this->load->view('partials/master', $data);
    }

    public function manage_messages() {
        $data['sub_title'] = 'You are logged in as ';
        $data['title'] = $this->lang->line('manage_messages');
        $data['content'] = 'Create, edit, list, filter, search, sort messages at church level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank', $data, TRUE);
        $this->load->view('partials/master', $data);
    }

    public function system_log() {
        $data['sub_title'] = 'You are logged in as ';
        $data['title'] = $this->lang->line('system_log');
        $data['content'] = 'Displays messages and status ; queued, sent at church level'; //describe method in one line
        $data['links'] = create_menus($this->menu_items());
        $data['handle'] = $this->load->view('partials/blank', $data, TRUE);
        $this->load->view('partials/master', $data);
    }

}