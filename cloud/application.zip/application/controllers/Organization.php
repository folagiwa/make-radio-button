<?php
/**
 * Created by PhpStorm.
 * User: grow
 * Date: 08/10/2018
 * Time: 12:58 PM
 */

class Organization extends Church_Admin_Controller
{

    public $links;

    function __construct()
    {
        parent::__construct();
        $this->lang->load('model', $this->session->language);
        $this->load->library('structures_lib');
        $this->links = create_menus($this->menu_items());
    }

    public function index(){
        $this->overview();
    }

    public function overview(){

        $this->structures_lib->church_units($this->links);
    }

    public function church_units(){
        $this->structures_lib->church_units($this->links);
    }

    public function unit_leaders(){
        $this->structures_lib->leaders($this->links);
    }

    public function new_unit(){
        $legend = 'Create New Unit';
        $action = 'organization/new_unit';
        $this->structures_lib->new_unit($legend, $this->links, $action);
    }



}