<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

    function __construct()
    {
        parent::__construct();
        $this->lang->load('general', detect_language());
        $this->load->library('users_lib');
        $this->load->library('payment_lib');

    }

    /**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
     *
	 */
	public function index()
	{
		$this->landing();
	}

	public function landing(){
	    $this->load->view('partials/landing');
    }

    public function register(){
        $this->users_lib->signup();
    }

    public function pay(){
        $this->payment_lib->payWithPaystack('gold');
    }

    public function verify(){
        $this->payment_lib->verifyPayment();
    }

    public function success(){
        $this->load->view('partials/success_page');
    }

    public function expired(){
        $this->load->view('partials/expired');

    }


}
