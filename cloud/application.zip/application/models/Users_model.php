<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * File       : Users_model.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/19/18
 * Time: 3:57 PM
 */


class Users_model extends MY_Model
{

    //order_id,product_id,product_qty


    public $table = 'grow_users';
    public $primary_key = 'user_id';

    public $protected = ['updated_at'];



    public function __construct()
    {

        parent::__construct();
        $this->return_as = 'array';
    }


    public $rules = [
        'insert' => [
            'church_id'         => ['field' => 'church_id',         'label' => 'lang:church',           'rules' => 'is_numeric|required',],
            'member_id'         => ['field' => 'member_id',         'label' => 'lang:member',           'rules' => 'is_numeric|required'],
            'username'          => ['field' => 'username',          'label' => 'lang:username',         'rules' => 'trim|required|valid_email'],
            'password'          => ['field' => 'password',          'label' => 'lang:password',         'rules' => 'trim|required|matches[retype_password]'],
            'active'            => ['field' => 'active',            'label' => 'lang:active',           'rules' => 'intval'],
            'is_admin'          => ['field' => 'is_admin',          'label' => 'lang:is_admin',         'rules' => 'trim|required|intval'],
            'user_type'         => ['field' => 'user_scope',        'label' => 'lang:user_scope',       'rules' => 'trim|required'],
            'random_key'        => ['field' => 'random_key',        'label' => 'lang:random_key',       'rules' => 'trim|required'],
            'user_roles'        => ['field' => 'user_roles',        'label' => 'lang:user_roles',       'rules' => 'trim|required'],

        ],

        'update' => [
            'user_id'           => ['field' => 'user_id',           'label' => 'lang:user',             'rules' => 'is_numeric|required',],
            'church_id'         => ['field' => 'church_id',         'label' => 'lang:church',           'rules' => 'is_numeric|required',],
            'member_id'         => ['field' => 'member_id',         'label' => 'lang:member',           'rules' => 'is_numeric|required'],
            'username'          => ['field' => 'username',          'label' => 'lang:username',         'rules' => 'trim|required|valid_email'],
            'password'          => ['field' => 'password',          'label' => 'lang:password',         'rules' => 'trim|required|matches[retype_password]'],
            'active'            => ['field' => 'active',            'label' => 'lang:active',           'rules' => 'intval'],
            'is_admin'          => ['field' => 'is_admin',          'label' => 'lang:is_admin',         'rules' => 'trim|required|intval'],
            'user_type'         => ['field' => 'user_scope',        'label' => 'lang:user_scope',       'rules' => 'trim|required'],
            'random_key'        => ['field' => 'random_key',        'label' => 'lang:random_key',       'rules' => 'trim|required'],
            'user_roles'        => ['field' => 'user_roles',        'label' => 'lang:user_roles',       'rules' => 'trim|required'],
        ]
    ];
}
