<?php
/**
 * File       : Payment_log_model.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/19/18
 * Time: 3:39 PM
 */

class Payment_log_model extends MY_Model
{

    public $table = 'grow_payment_log';
    public $primary_key = 'log_id';

    public $protected = ['updated_at'];


    public function __construct()
    {

        parent::__construct();
        $this->return_as = 'array';
    }

    public $rules = [
        'insert' => [
            'church_id'         => ['field' => 'church_id',     'label' => 'lang:church_name',      'rules' => 'required|is_numeric'],
            'paid_at'           => ['field' => 'paid_at',       'label' => 'lang:paid_at',          'rules' => 'trim'],
            'expiry_date'       => ['field' => 'expiry_date',   'label' => 'lang:expiry_date',      'rules' => 'is_numeric'],
            'reference'         => ['field' => 'reference',     'label' => 'lang:reference',        'rules' => 'is_numeric'],

        ],
        'update' => [
            'log_id'            => ['field' => 'church_id',     'label' => 'lang:church_name',      'rules' => 'required|is_numeric'],
            'church_id'         => ['field' => 'church_id',     'label' => 'lang:church_name',      'rules' => 'required|is_numeric'],
            'paid_at'           => ['field' => 'paid_at',       'label' => 'lang:paid_at',          'rules' => 'trim'],
            'expiry_date'       => ['field' => 'expiry_date',   'label' => 'lang:expiry_date',      'rules' => 'is_numeric'],
            'reference'         => ['field' => 'reference',     'label' => 'lang:reference',        'rules' => 'is_numeric'],

        ],


    ];

}