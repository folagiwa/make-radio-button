<?php
if(! defined('BASEPATH')) exit('No direct script access allowed');

#file giving_categories
#@author Segun Aruleba
#Email: segunaruleba@loveworld360.com
# @kingschat : +2348121724280
#Date: 2017-07-06

class Giving_categories_model extends MY_Model
{
    public $table = 'grow_giving_categories';//Name of the table
    public $primary_key = 'giving_cat_id'; //This is a primary key

    public function __construct()
    {
        parent::__construct();
        $this->return_as = 'array';
    }
    public function fetch_giving_categories($giving_cat_id){
        $this->db->select('*');
        $this->db->where('giving_cat_id', $giving_cat_id);
        $this->db->order_by('church_id', 'ASC');
        $this->db->from('grow_giving_categories');
        $query = $this->db->get();
       return  $query->result();
    }
     public function cat($cat_id){
         $this->CI->db->select('category_name','giving_name');
         $this->CI->db->get_where('giving_cat_id',$cat_id);
         $this->CI->db->from('grow_giving_categories');
         $update = $this->CI->db->get();
       return  $update->result();
     }

    public $rules = [
        'insert'=> [
            'church_id'              => ['field' =>'church_id',               'label' => 'lang:church_name',                'rules' => 'is_numeric'],
            'category_name'          => ['field' => 'category_name',          'label' => 'lang:category_name',              'rules' => 'required|trim'],
            'created_by'             => ['field' => 'created_by',             'label' => 'lang:created_by',                 'rules' =>'required|trim']
        ],
        'update'  => [
            'giving_cat_id'          =>['field'  =>'giving_cat_id',           'label' => 'lang:giving_category',            'rules' => 'is_numeric'],
            'church_id'              => ['field' =>'church_id',               'label' => 'lang:church_name',                'rules' => 'is_numeric'],
            'category_name'          => ['field'  => 'category_name',         'label' => 'lang:category_name',              'rules' => 'required|trim'],
            'created_by'             => ['field' => 'created_by',             'label' => 'lang:created_by',                 'rules' =>'required|trim']



        ]
    ];
}