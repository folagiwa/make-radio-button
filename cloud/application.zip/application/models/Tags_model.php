<?php
/**
 * File       : Tags_model.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/19/18
 * Time: 3:55 PM
 */

defined('BASEPATH') OR exit('No direct script access allowed');

class Tags_model extends MY_Model
{
    public $table = 'grow_tags';
    public $primary_key = 'tag_id';

    public $protected = ['updated_at'];

    public function __construct()
    {

        parent::__construct();
        $this->return_as = 'array';
    }

    public $rules = [
        'insert'   => [
            'church_id'         => ['field' =>'church_id',       'label' => 'lang:church',          'rules' =>'is_numeric|required'],
            'tag_name'          => ['field' =>'tag_name',        'label' => 'lang:tag_name',        'rules' =>'trim'],
            'tag_type'          => ['field' =>'tag_type',        'label' => 'lang:tag_type',        'rules' =>'trim'],
            'leader'            => ['field' =>'leader',          'label' => 'lang:leader',          'rules' =>'is_numeric|required'],
            'tag_email'         => ['field' =>'tag_email',       'label' => 'lang:tag_email',       'rules' =>'trim'],
            'created_by'        => ['field' =>'created_by',      'label' => 'lang:created_by',      'rules' => 'trim']
        ],
        'update'   => [
            'tag_id'            => ['field' =>'tag_id',         'label' => 'lang:tag',              'rules' =>'is_numeric|required'],
            'church_id'         => ['field' =>'church_id',      'label' => 'lang:church',           'rules' =>'is_numeric|required'],
            'tag_name'          => ['field' =>'tag_name',       'label' => 'lang:tag_name',         'rules' =>'trim'],
            'tag_type'          => ['field' =>'tag_type',       'label' => 'lang:tag_type',         'rules' =>'trim'],
            'leader'            => ['field' =>'leader',         'label' => 'lang:leader',           'rules' =>'is_numeric|required'],
            'tag_email'         => ['field' =>'tag_email',      'label' => 'lang:tag_email',        'rules' =>'trim'],
            'created_by'        => ['field' =>'created_by',     'label' => 'lang:created_by',       'rules' => 'trim']
        ]
    ];
}
