<?php
if(!defined('BASEPATH')) exit('No direct script access');

/**
 * File       : Churches_model.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/19/18
 * Time: 3:12 PM
 */

class Churches_model extends MY_Model {


    public $table = 'grow_churches';
    public $primary_key = 'church_id';

    public $protected = ['created_at'];
    public function __construct()
    {
        parent::__construct();
        $this->return_as = 'array';
    }


       public $rules = [

           'insert'   => [

               'church_name'         => ['field' => 'church_name',      'label'  => 'lang:church_name',         'rules' => 'is_numeric'],
               'church_pastor'       => ['field' => 'church_pastor',    'label'  => 'lang:church_pastor',       'rules' => 'is_numeric'],
               'church_admin'        => ['field' => 'church_admin',     'label'  => 'lang:church_admin',        'rules' => 'is_numeric'],
               'church_email'        => ['field' => 'church_email',     'label'  => 'lang:church_email',        'rules' => 'is_numeric'],
               'authorization_code'  => ['field' => 'authorization_code','label' => 'lang:authorization_code',  'rules' => 'trim'],
               'reference'           => ['field' => 'reference',         'label' => 'lang:reference',           'rules' => 'trim'],
               'paid_at'             => ['field' => 'paid_at',          'label'  => 'lang:paid_at',             'rules' => 'trim'],
               'subscription_type'   => ['field' => 'subscription_type', 'label' => 'lang:subscription',       'rules' => 'trim|required'],
               'church_country'      => ['field' => 'church_country',   'label'  => 'lang:church_country',      'rules' => 'trim'],
               'church_state'        => ['field' => 'church_state',     'label'  => 'lang:church_state',        'rules' => 'trim'],
               'church_city'         => ['field' => 'church_city',      'label'  => 'lang:church_city',         'rules' => 'trim'],
               'church_address'      => ['field' => 'church_address',    'label' => 'lang:church_address',      'rules' => 'trim'],
               'church_phone'        => ['field' => 'church_phone',      'label' => 'lang:church_phone',        'rules' => 'trim'],
               'church_desc'         => ['field' => 'church_desc',      'label'  => 'lang:church_desc',         'rules' => 'trim'],
               'church_longitude'    => ['field' => 'church_longitude', 'label'  => 'lang:church_longitude',    'rules' => 'trim'],
               'church_latitude'     => ['field' => 'church_latitude',  'label'  => 'lang:church_latitude',     'rules' => 'trim'],
               'created_on'          => ['field' => 'created_on',       'label'  => 'lang:created_on',          'rules' => 'trim'],
               'created_by'          => ['field' => 'created_by'  ,     'label'  => 'lang:created_by',          'rules' => 'trim'],

           ],
           'update'   => [
               'church_id'           => ['field' => 'church_id',        'label'  => 'lang:church_name',         'rules' => 'required|is_numeric'],
               'church_name'         => ['field' => 'church_name',      'label'  => 'lang:church_name',         'rules' => 'is_numeric'],
               'church_pastor'       => ['field' => 'church_pastor',    'label'  => 'lang:church_pastor',       'rules' => 'is_numeric'],
               'church_admin'        => ['field' => 'church_admin',     'label'  => 'lang:church_admin',        'rules' => 'is_numeric'],
               'church_email'        => ['field' => 'church_email',     'label'  => 'lang:church_email',        'rules' => 'is_numeric'],
               'authorization_code'  => ['field' => 'authorization_code','label' => 'lang:authorization_code',  'rules' => 'trim'],
               'reference'           => ['field' => 'reference',         'label' => 'lang:reference',           'rules' => 'trim'],
               'paid_at'             => ['field' => 'paid_at',          'label'  => 'lang:paid_at',             'rules' => 'trim'],
               'church_country'      => ['field' => 'church_country',   'label'  => 'lang:church_country',      'rules' => 'trim'],
               'church_state'        => ['field' => 'church_state',     'label'  => 'lang:church_state',        'rules' => 'trim'],
               'church_city'         => ['field' => 'church_city',      'label'  => 'lang:church_city',         'rules' => 'trim'],
               'church_address'      => ['field' => 'church_address',   'label'  => 'lang:church_address',      'rules' => 'trim'],
               'church_phone'        => ['field' => 'church_phone',     'label'  => 'lang:church_phone',        'rules' => 'trim'],
               'church_desc'         => ['field' => 'church_desc',      'label'  => 'lang:church_desc',         'rules' => 'trim'],
               'church_longitude'    => ['field' => 'church_longitude', 'label'  => 'lang:church_longitude',    'rules' => 'trim'],
               'church_latitude'     => ['field' => 'church_latitude',  'label'  => 'lang:church_latitude',     'rules' => 'trim'],
               'created_on'          => ['field' => 'created_on',       'label'  => 'lang:created_on',          'rules' => 'trim'],
               'created_by'          => ['field' => 'created_by'  ,     'label'  => 'lang:created_by',          'rules' => 'trim'],

           ]
       ];
}

