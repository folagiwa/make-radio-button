<?php
if(! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * File       : Members_model.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/19/18
 * Time: 1:06 PM
 */

class Members_model extends MY_Model {

    public $table = 'grow_members';
    public $primary_key = 'member_id';

    public $protected = ['created_at'];

    //public $protected = ['updated_at'];

    public function __construct()
    {
        parent::__construct();
        $this->return_as= 'array';
    }

    public $rules = [
        'insert' => [
            'church_id'              => ['field' => 'church_id',            'label' => 'lang:church_name',            'rules' => 'required|is_numeric'],
            'title'                  => ['field' => 'title',                'label' => 'lang:title',                  'rules' => 'required|trim'],
            'surname'                => ['field' => 'surname',              'label' => 'lang:surname',                'rules' => 'required|trim'],
            'first_name'             => ['field' => 'first_name',           'label' => 'lang:first_name',             'rules' => 'required|trim'],
            'birth_date'             => ['field' => 'birth_date',           'label' => 'lang:birth_date',             'rules' => 'required'],
            'gender'                 => ['field' => 'gender',               'label' => 'lang:gender',                 'rules' => 'required'],
            'mobile_phone'           => ['field' => 'mobile_phone',         'label'=> 'lang:mobile_phone',            'rules' => 'trim'],
           // 'cell_phone'             => ['field' => 'cell_phone',           'label'=> 'lang:cell_phone',             'rules' => 'required'],
            //'work_phone'             => ['field' => 'work_phone',           'label'=> 'lang:work_phone',              'rules' => 'trim'],
            'email_address'          => ['field' => 'email_address',        'label'=> 'lang:email_address',           'rules' => 'required'],
            'country'                => ['field' => 'country',              'label'=> 'lang:country',                 'rules' => 'required'],
            'state'                  => ['field' => 'state',                'label'=> 'lang:state',                   'rules' => 'required'],
            'city'                   => ['field' => 'city',                 'label'=> 'lang:city',                    'rules' => 'required'],

            //MAKE OPTIONAL
            //FIRST TIMER ONLY

            'home_address'           => ['field' => 'home_address',          'label'=> 'lang:home_address',           'rules' => 'required'],
            'nearest_landmark'       => ['field' => 'nearest_landmark',      'label'=> 'lang:nearest_landmark',       'rules' => 'trim'],
            'marital_status'         => ['field' => 'marital_status',        'label'=> 'lang:marital_status',         'rules' => 'trim'],
            'profession'             => ['field' => 'profession',            'label'=> 'lang:profession',             'rules' => 'trim'],
            'first_day_in_church'    => ['field' => 'first_day_in_church',   'label'=> 'lang:first_day_in_church',    'rules' => 'trim'],
            'invited_by'             => ['field' => 'invited_by',            'label'=> 'lang:invited_by',             'rules' => 'trim'],
            'prayer_request'         => ['field' => 'prayer_request',        'label'=> 'lang:prayer_request',         'rules' => 'trim'],
            'visit_time'             => ['field' => 'visit_time',            'label'=> 'lang:visit_time',             'rules' => 'trim'],
            'group_assigned'         => ['field' => 'group_assigned',         'label'=> 'lang:group_assigned',        'rules' => 'trim'],
            'is_new_convert'         => ['field' => 'is_new_convert',        'label'=> 'lang:is_new_convert',         'rules' => 'trim'],
            'is_baptised'            => ['field' => 'is_baptised',           'label'=> 'lang:is_baptised',            'rules' => 'trim'],
            'member_picture'         => ['field' => 'member_picture',        'label'=> 'lang:member_picture',         'rules' => 'trim'],
            'created_by'             => ['field' => 'created_by',            'label'=> 'lang:created_by',             'rules' => 'trim']


                ],

                'update' => [
                    'member_id'              =>  ['field' => 'member_id',            'label' => 'lang:member_id',              'rules' =>'required|is_numeric'],
                    'church_id'              => ['field' => 'church_id',            'label' => 'lang:church_name',            'rules' => 'required|is_numeric'],
                    'title'                  => ['field' => 'title',                'label' => 'lang:title',                  'rules' => 'required|trim'],
                    'surname'                => ['field' => 'surname',              'label' => 'lang:surname',                'rules' => 'required|trim'],
                    'first_name'             => ['field' => 'first_name',           'label' => 'lang:first_name',             'rules' => 'required|trim'],
                    'birth_date'             => ['field' => 'birth_date',           'label' => 'lang:birth_date',             'rules' => 'required'],
                    'gender'                 => ['field' => 'gender',               'label' => 'lang:gender',                 'rules' => 'required'],
                    'mobile_phone'           => ['field' => 'mobile_phone',        'label'=> 'lang:mobile_phone',           'rules' => 'trim'],
                    //'cell_phone'             => ['field' => 'cell_phone',            'label'=> 'lang:cell_phone',             'rules' => 'required'],
                    //'work_phone'             => ['field' => 'work_phone',           'label'=> 'lang:work_phone',              'rules' => 'trim'],
                    'email_address'          => ['field' => 'email_address',        'label'=> 'lang:email_address',           'rules' => 'required'],
                    'country'                => ['field' => 'country',              'label'=> 'lang:country',                 'rules' => 'required'],
                    'state'                  => ['field' => 'state',                'label'=> 'lang:state',                   'rules' => 'required'],
                    'city'                   => ['field' => 'city',                 'label'=> 'lang:city',                    'rules' => 'required'],

                    //MAKE OPTIONAL
                    //FIRST TIMER ONLY

                    'home_address'           => ['field' => 'home_address',          'label'=> 'lang:home_address',           'rules' => 'required'],
                    'nearest_landmark'       => ['field' => 'nearest_landmark',      'label'=> 'lang:nearest_landmark',       'rules' => 'trim'],
                    'marital_status'         => ['field' => 'marital_status',        'label'=> 'lang:marital_status',         'rules' => 'trim'],
                    'profession'             => ['field' => 'profession',            'label'=> 'lang:profession',             'rules' => 'trim'],
                    'first_day_in_church'    => ['field' => 'first_day_in_church',   'label'=> 'lang:first_day_in_church',    'rules' => 'trim'],
                    'invited_by'             => ['field' => 'invited_by',            'label'=> 'lang:invited_by',             'rules' => 'trim'],
                    'prayer_request'         => ['field' => 'prayer_request',        'label'=> 'lang:prayer_request',         'rules' => 'trim'],
                    'visit_time'             => ['field' => 'visit_time',            'label'=> 'lang:visit_time',             'rules' => 'trim'],
                    'group_assigned'         => ['field' => 'group_assigned',         'label'=> 'lang:group_assigned',        'rules' => 'trim'],
                    'is_new_convert'         => ['field' => 'is_new_convert',        'label'=> 'lang:is_new_convert',         'rules' => 'trim'],
                    'is_baptised'            => ['field' => 'is_baptised',           'label'=> 'lang:is_baptised',            'rules' => 'trim'],
                    'member_picture'         => ['field' => 'member_picture',        'label'=> 'lang:member_picture',         'rules' => 'trim'],
                    'created_by'             => ['field' => 'created_by',            'label'=> 'lang:created_by',             'rules' => 'trim']

                ]


                ];


}