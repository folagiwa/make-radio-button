<?php
/**
 * File       : Fellowship_reports_model.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/19/18
 * Time: 4:02 PM
 */

class Fellowship_reports_model extends MY_Model {

    public $table = 'grow_fellowship_reports';
    public $primary_key = 'report_id';

    public $protected = ['created_at'];

    public function __construct()
    {

        parent::__construct();
        $this->return_as = 'array';
    }

    public $rules = [
        'insert' => [
            'cell_id'            => ['field' =>'cell_id',         'label' => 'lang:cell',              'rules' =>'is_numeric|required'],
            'church_id'          => ['field' =>'church_id',       'label' => 'lang:church',            'rules' =>'is_numeric|required'],
            'activity_date'      => ['field' =>'activity_date',   'label' => 'lang:activity_date',     'rules' =>'trim'],
            'activity_type'      => ['field' =>'activity_type',   'label' => 'lang:activity_type',     'rules' =>'trim'],
            'attendance'         => ['field' =>'attendance',      'label' => 'lang:attendance',        'rules' =>'trim'],
            'first_timers'       => ['field' =>'first_timers',    'label' => 'lang:first_timers',      'rules' =>'trim'],
            'new_converts'       => ['field' =>'new_converts',    'label' => 'lang:new_converts',      'rules' =>'trim'],
            'offering'           => ['field' =>'offering',        'label' => 'lang:offering',          'rules' =>'trim'],
            'created_by'         => ['field' =>'created_by',      'label' => 'lang:created_by',        'rules' => 'trim']

        ],
        'update' => [
            'report_id'          => ['field' =>'report_id',       'label' => 'lang:report',            'rules' =>'is_numeric|required'],
            'cell_id'            => ['field' =>'cell_id',         'label' => 'lang:cell',              'rules' =>'is_numeric|required'],
            'church_id'          => ['field' =>'church_id',       'label' => 'lang:church',            'rules' =>'is_numeric|required'],
            'activity_date'      => ['field' =>'activity_date',   'label' => 'lang:activity_date',     'rules' =>'trim'],
            'activity_type'      => ['field' =>'activity_type',   'label' => 'lang:activity_type',     'rules' =>'trim'],
            'attendance'         => ['field' =>'attendance',      'label' => 'lang:attendance',        'rules'=>'trim'],
            'first_timers'       => ['field' =>'first_timers',    'label' => 'lang:first_timers',      'rules' =>'trim'],
            'new_converts'       => ['field' =>'new_converts',    'label' => 'lang:new_converts',      'rules' =>'trim'],
            'offering'           => ['field' =>'offering',        'label' => 'lang:offering',          'rules' =>'trim'],
            'created_by'         => ['field' =>'created_by',      'label' => 'lang:created_by',        'rules' => 'trim']

        ]

    ];

}