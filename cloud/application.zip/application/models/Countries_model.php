<?php
#countries
#countries model
#XYZoe
#zoechuksimm@loveworld360.com
#8th July 2017

if(!defined('BASEPATH')) exit('No direct script access');

class Countries_model extends MY_Model
{
    public $table = 'grow_countries';
    public $primary_key = 'country_id';

    public $fillable = ['sortname',
                        'country_name',
                        'currency_code',
                        'currency_name'];

    public function __construct()
    {
        parent::__construct();
        $this->return_as = 'array';
    }

    public $rules = [
        'insert' => [
            'sortname' => [ 'field' => 'sortname',
                            'label' => 'lang:sortname',
                            'rules' => 'required | alpha_dash'],

            'country_name' => [ 'field' => 'country_name',
                                'label' => 'lang:country_name',
                                'rules' => 'required | alpha_dash'],

            'currency_code' => ['field' => 'country_name',
                                'label' => 'lang:country_name',
                                'rules' => 'required | alpha_dash'],

            'currency_name' => ['field' => 'currency_name',
                                'label' => 'lang:currency_name',
                                'rules' => 'required | alpha_dash']
        ],

        'update' => [
            'country_id' => [   'field' => 'country_id',
                                'label' => 'lang:country',
                                'rules' => 'required | is_numeric'],

            'sortname' => [ 'field' => 'sortname',
                            'label' => 'lang:sortname',
                            'rules' => 'required | alpha_dash'],

            'country_name' => [ 'field' => 'country_name',
                                'label' => 'lang:country_name',
                                'rules' => 'required | alpha_dash'],

            'currency_code' => ['field' => 'country_name',
                                'label' => 'lang:country_name',
                                'rules' => 'required | alpha_dash'],

            'currency_name' => ['field' => 'currency_name',
                                'label' => 'lang:currency_name',
                                'rules' => 'required | alpha_dash']
        ]
    ];
}
