<?php
/**
 * File       : Sign_up_model.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/19/18
 * Time: 3:47 PM
 */

class Signup_model extends MY_Model {

    public $table = 'grow_signup';
    public $primary_key = 'user_id';

    public $protected = ['updated_at'];


    public function  __construct(){

        parent::__construct();
        $this->return_as= 'array';
    }

    public $rules = [

        'insert'  => [
            'church_id'       => ['field' => 'church_id',      'label'  => 'lang:church_name',          'rules' => 'required|is_numeric'],
            'church_name'     => ['field' => 'church_name',    'label'  => 'lang:church_name',          'rules' => 'is_numeric'],
            'first_name'      => ['field' => 'first_name',     'label'  => 'lang:first_name',           'rules' => 'is_numeric'],
            'last_name'       => ['field' => 'last_name',      'label'  => 'lang:last_name',            'rules' => 'is_numeric'],
            'username'        => ['field' => 'username',       'label'  => 'lang:username',             'rules' => 'is_numeric'],
            'password'        => ['field' => 'password' ,       'label'  => 'lang:password',             'rules' => 'trim|required|matches[retype_password]'],
            'retype_password' => ['field' => 'retype_password',  'label'  => 'lang:retype_Password',      'rules' => 'trim|required|matches[password]'],
            'phone_number'    => ['field' => 'phone_number'  ,   'label'  => 'lang:phone_number',         'rules' => 'trim'],
            'church_website'  => ['field' => 'church_website'  , 'label'  => 'lang:church_website',       'rules' => 'trim'],
            'created_by'      => ['field' => 'created_by'  ,     'label'  => 'lang:created_by',           'rules' => 'trim'],


        ],
        'update'  => [
            'user_id'         => ['field' => 'user_id',          'label'   => 'lang:user',                'rules' => 'required|is_numeric'],
            'church_id'       => ['field' => 'church_id',        'label'  => 'lang:church_name',          'rules' => 'required|is_numeric'],
            'church_name'     => ['field' => 'church_name'  ,    'label'  => 'lang:church_name',          'rules' => 'is_numeric'],
            'first_name'      => ['field' => 'first_name'  ,     'label'  => 'lang:first_name',           'rules' => 'is_numeric'],
            'last_name'       => ['field' => 'last_name'  ,      'label'  => 'lang:last_name',            'rules' => 'is_numeric'],
            'username'        => ['field' => 'username'  ,       'label'  => 'lang:username',             'rules' => 'is_numeric'],
            'password'        => ['field' => 'password'  ,       'label'  => 'lang:password',             'rules' => 'trim|required|matches[retype_password]'],
            'retype_password' => ['field' => 'retype_password',  'label'  => 'lang:retype_Password',      'rules' => 'trim|required|matches[password]'],
            'phone_number'    => ['field' => 'phone_number'  ,   'label'  => 'lang:phone_number',         'rules' => 'trim'],
            'church_website'  => ['field' => 'church_website'  , 'label'  => 'lang:church_website',       'rules' => 'trim'],
            'created_by'      => ['field' => 'created_by'  ,     'label'  => 'lang:created_by',           'rules' => 'trim'],
        ]
    ];


}