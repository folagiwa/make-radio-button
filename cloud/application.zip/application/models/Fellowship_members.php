<?php
/**
 * File       : Fellowship_members.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 1/10/19
 * Time: 18:31
 */

#cell members
#cell members model
#XYZoe
#zoechuksimm@loveworld360.com
#8th July 2017

if(!defined('BASEPATH')) exit('No direct script access');

class Fellowship_members_model extends MY_Model
{
    public $table = 'grow_fellowship_members';
    public $primary_key = 'fellowship_member_id';

    public $fillable = ['member_id',
        'tag_id',
        'church_id',
        'created_by'];

    public function __construct()
    {
        parent::__construct();
        $this->return_as = 'array';
    }

    public $rules = [
        'insert' => [
            'member_id' => ['field' => 'member_id',
                'label' => 'lang:member',
                'rules' => 'required | is_numeric'],

            'cell_id' => [	'field' =>	'tag_id',
                'label' =>	'lang:tag',
                'rules' =>	'required | is_numeric'],

            'church_id' => ['field' =>	'church_id',
                'label' =>	'lang:church',
                'rules' =>	'required | is_numeric'],

            'created_by' => [	'field' => 'created_by',
                'label' => 'lang:created_by',
                'rules' => 'required | integer']


        ],

        'update' => [
            'fellowship_member_id' => [   'field' => 'fellowship_member_id',
                'label' => 'lang:fellowship_member',
                'rules' => 'required | is_numeric'],

            'member_id' => ['field' => 'member_id',
                'label' => 'lang:member',
                'rules' => 'required | is_numeric'],

            'cell_id' => [	'field' =>	'tag_id',
                'label' =>	'lang:tag',
                'rules' =>	'required | is_numeric'],

            'church_id' => ['field' =>	'church_id',
                'label' =>	'lang:church',
                'rules' =>	'required | is_numeric'],

            'created_by' => [	'field' => 'created_by',
                'label' => 'lang:created_by',
                'rules' => 'required | integer']


        ]
    ];

}