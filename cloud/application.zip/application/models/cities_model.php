<?php
#cities
#cities model
#XYZoe
#zoechuksimm@loveworld360.com
#8th July 2017

if(!defined('BASEPATH')) exit('No direct script access');

class cities_model extends MY_Model
{
	public $table = 'grow_cities';
	public $primary_key = 'city_id';
	
	public $fillable = ['city_name', 'state_id'];
	
	public function __construct()
	{
		parent::__construct();
		$this->return_as = 'array';
	}
	
	public $rules = [
        'insert' => [
            'city_name' => ['field' =>	'city_name',
                            'label' =>	'lang:city_name',
                            'rules' =>	'required | alpha_dash'],

            'state_id' => [ 'field' =>	'state_id',
                            'label' =>	'lang:state',
                            'rules' =>	'required | is_numeric']
        ],
		
		'update' => [
            'city_id' => [  'field' =>	'city_id',
                            'label' =>	'lang:city',
                            'rules' =>	'required | alpha_dash'],

			'city_name' => ['field' =>	'city_name',
							'label' =>	'lang:city_name',
							'rules' =>	'required | alpha_dash'],
							
			'state_id' => ['field' =>	'state_id',
							'label' =>	'lang:state',
							'rules' =>	'required | is_numeric']			
		]
	];
}