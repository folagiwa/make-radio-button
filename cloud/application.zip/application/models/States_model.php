<?php defined('BASEPATH') OR exit('No direct script access allowed');
/*Author: Segun Aruleba
* Email :Segunaruleba@loveworld360.com
*/

class States_model extends MY_Model{

    //order_id,product_id,product_qty

    public $table = 'grow_states';
    public $primary_key = 'state_id';

    public $fillable = ['state_name','state_id'];



    public function __construct()
    {

        parent::__construct();
        $this->return_as = 'array';
    }



    public $rules = [
        'insert' =>[
            'country_id' => [
                'field' =>'country_id',
                'label' =>'lang:country',
                'rules' =>'trim|is_natural'],

            'state_name' => [
                'field' =>'state_name',
                'label' =>'lang:state_name',
                'rules' =>'trim|required'],
        ],

        'update' =>[
            'state_id' => [
                'field' =>'state_id',
                'label' =>'lang:state',
                'rules' =>'trim|is_natural'],

            'country_id' => [
                'field' =>'country_id',
                'label' =>'lang:country',
                'rules' =>'trim|is_natural'],

                'state_name' => [
                    'field' =>'state_name',
                    'label' =>'lang:state_name',
                    'rules' =>'trim|required'],


        ]




    ];




}
