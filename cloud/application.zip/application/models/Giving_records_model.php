<?php

if(! defined('BASEPATH')) exit('No direct script access allowed');

#file giving_records
#@author Segun Aruleba
#Email: segunaruleba@loveworld360.com
# @kingschat : +2348121724280
#Date: 2017-07-06

class Giving_records_model extends MY_Model
{
    public $table = 'grow_giving_records';
    public $primary_key = 'record_id';

    protected $res;
    public function __construct()
    {

        parent::__construct();
        $this->return_as= 'array';

    }


    public function convert_usd_to_any($amount, $to,$q){
        $this->db->select('exchange_rate');
        $this->db->where('currency',$to);
        $this->db->from('grow_currencies');
        $rate = $q[0]['exchange_rate'];
        $this->res = $amount * $rate;
        $query = $this->db->get();
        return $query->result();
    }
    public function convert_any_to_usd($amount, $from, $q){
        $this->db->select('exchange_rate');
        $this->db->where('currency',$from);
        $this->db->from('grow_currencies');
        $rate = $q[0]['exchange_rate'];
        $this->res = $amount / $rate;
        $query = $this->db->get();
        return $query->result();

    }


    public $rules = [
        'insert' => [
            'record_date'     => ['field' => 'record_date',     'label' => 'lang:record_date',          'rules' => 'required|trim'],
            'church_id'       => ['field' => 'church_id',       'label' => 'lang:church_name',          'rules' => 'is_numeric'],
            'giving_cat_id'   => ['field' => 'giving_cat_id',   'label' => 'lang:giving_category',      'rules' => 'is_numeric'],
            'member_id'       => ['field' => 'member_id',       'label' => 'lang:member_id',            'rules' => 'is_numeric'],
            'currency_id'     => ['field' => 'currency_id',     'label' => 'lang:currency_id',          'rules' => 'required|trim'],
            'giving_amount'   => ['field' => 'giving_amount',   'label' => 'lang:giving_amount',        'rules' => 'required|is_numeric'],
            'giving_citation' => ['field' => 'giving_citation', 'label' => 'lang:giving_citation',      'rules' => 'required|trim'],
            'created_by'      => ['field' => 'created_by',      'label' => 'lang:created_by',           'rules' => 'trim']
        ],

        'update' => [
            'record_id'       => ['field' => 'record_id',       'label' => 'lang:record',               'rules' => 'is_numeric'],
            'record_date'     => ['field' => 'record_date',     'label' =>'lang:record_date',           'rules' => 'required|trim'],
            'church_id'       => ['field' => 'church_id',       'label' => 'lang:church_name',          'rules' => 'required|is_numeric'],
            'giving_cat_id'   => ['field' => 'giving_cat_id',   'label' => 'lang:giving_category',      'rules' => 'required|is_numeric'],
            'member_id'       => ['field' => 'member_id',       'label' => 'lang:member_id',            'rules' => 'required|is_numeric'],
            'currency_id'     => ['field' => 'currency_id',     'label' => 'lang:currency_cid',         'rules' => 'required|trim'],
            'giving_amount'   => ['field' => 'giving_amount',   'label' => 'lang:giving_amount',        'rules' => 'required|is_numeric'],
            'giving_citation' => ['field' => 'giving_citation', 'label' => 'lang:giving_citation',      'rules' => 'required|trim'],
            'created_by'      => ['field' => 'created_by',      'label' => 'lang:created_by',           'rules' => 'trim']

        ]
    ];
}