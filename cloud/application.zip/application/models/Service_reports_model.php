<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * File       : Service_reports_model.php
 * @Auhor     : Folake Giwa
 * @email     : folakegiwa@loveworld360.com
 * @kingschat : +2348064710767
 * Date: 9/19/18
 * Time: 2:38 PM
 */

class Service_reports_model extends MY_Model {

    public $table = 'grow_service_reports';
    public $primary_key = 'service_id';

    public $protected = ['created_at'];

    public function __construct()
    {

        parent::__construct();
        $this->return_as = 'array';
    }

    public $rules = [
        'insert' => [
            'church_id'          =>     ['field' => 'church_id',         'label' => 'lang:church',            'rules' =>'is_numeric|required'],
            'service_date'       =>     ['field' => 'service_date',      'label' => 'lang:service_date',      'rules' =>'trim'],
            'service_type'       =>     ['field' => 'service_type',      'label' => 'lang:service_type',      'rules' => 'trim'],
            'attendance_kids'    =>     ['field' => 'attendance_kids',   'label' => 'lang:attendance_kids',   'rules' => 'trim'],
            'attendance_teens'   =>     ['field' => 'attendance_teens',  'label' => 'lang:attendance_teens',  'rules' => 'trim'],
            'attendance_adults'  =>     ['field' => 'attendance_adults', 'label' => 'lang:attendance_adults', 'rules' => 'trim'],
            'first_timers'       =>     ['field' => 'first_timers',      'label' => 'lang:first_timers',      'rules' => 'trim'],
            'new_converts'       =>     ['field' => 'new_converts',      'label' => 'lang:new_converts',      'rules' => 'trim'],
            'offering'           =>     ['field' => 'offering',          'label' => 'lang:offering',          'rules' => 'trim'],
            'tithe'              =>     ['field' => 'tithe',             'label' => 'lang:tithe',             'rules' => 'trim'],
            'seed'               =>     ['field' => 'seed',              'label' => 'lang:seed',              'rules' => 'trim'],
            'thanks_giving'      =>     ['field' => 'thanks_giving',     'label' => 'lang:thanks_giving',     'rules' => 'trim'],
            'week_number'        =>     ['field' => 'week_number',       'label' => 'lang:week_number',       'rules' => 'trim'],
            'thanksgiving'       =>     ['field' => 'thanksgiving',      'label' => 'lang:thanksgiving',      'rules' => 'trim'],
            'created_by'         =>     ['field' => 'created_by',        'label' => 'lang:created_by',        'rules' => 'trim']
        ],

        'update' => [
            'church_id'          =>     ['field' =>'church_id',         'label' => 'lang:church',            'rules' =>'is_numeric|required'],
            'service_date'       =>     ['field' =>'service_date',      'label' => 'lang:service_date',      'rules' =>'trim'],
            'service_type'       =>     ['field' =>'service_type',      'label' => 'lang:service_type',      'rules' => 'trim'],
            'attendance_kids'    =>     ['field' =>'attendance_kids',   'label' => 'lang:attendance_kids',   'rules' => 'trim'],
            'attendance_teens'   =>     ['field' =>'attendance_teens',  'label' => 'lang:attendance_teens',  'rules' => 'trim'],
            'attendance_adults'  =>     ['field' => 'attendance_adults','label' => 'lang:attendance_adults', 'rules' => 'trim'],
            'first_timers'       =>     ['field' =>'first_timers',      'label' => 'lang:first_timers',      'rules' => 'trim'],
            'new_converts'       =>     ['field' => 'new_converts',     'label' => 'lang:new_converts',      'rules' => 'trim'],
            'offering'           =>     ['field' => 'offering',         'label' => 'lang:offering',          'rules' => 'trim'],
            'tithe'              =>     ['field' => 'tithe',            'label' => 'lang:tithe',             'rules' => 'trim'],
            'seed'               =>     ['field' => 'seed',             'label' => 'lang:seed',              'rules' => 'trim'],
            'thanks_giving'      =>     ['field' => 'thanks_giving',    'label' => 'lang:thanks_giving',     'rules' => 'trim'],
            'week_number'        =>     ['field' => 'week_number',      'label' => 'lang:week_number',       'rules' => 'trim'],
            'thanksgiving'       =>     ['field' => 'thanksgiving',     'label' => 'lang:thanksgiving',      'rules' => 'trim'],
            'created_by'         =>     ['field' =>'created_by',        'label' => 'lang:created_by',        'rules' => 'trim']

        ]

    ];



}


